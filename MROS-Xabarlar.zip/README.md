# MROS Xabarlar — iOS 27 uslubidagi SMS ilova (Android)

Kotlin + Jetpack Compose. Haqiqiy Liquid Glass (Android 13+, AGSL shader):
- shaffof ("clear") shisha — orqadagi kontent ko'rinib turadi, ozgina xiralik va to'yingan ranglar
- chetlarda gumbaz shaklidagi linza: orqa fon sinib, kattalashib ko'rinadi
- rang ajralishi (chromatic aberration) — chetda R/G/B biroz siljiydi
- yorug'lik nuri (specular): yuqori-chap chetda yorqin chiziq, pastki-o'ngda kuchsiz aks
- "suyuq" tugmalar: bosganda kattalashadi, barmoq tomonga egiladi, barmoq ostida yorishadi,
  qo'yib yuborganda jele kabi tebranadi
- Android 12 da: xiralik + yarim shaffof rang; undan pastda oddiy shaffof fon

## Imkoniyatlar

**Suhbatlar ro'yxati**
- Katta "Xabarlar" sarlavhasi, aylantirganda kichrayadi
- Qadalgan suhbatlar (yuqorida katta avatarlar, 3 tadan)
- O'ngga surish → O'qildi / O'qilmagan, Qadash; chapga surish → O'chirish
- Bosib turish → kontekst menyusi (shisha panel)
- Pastda shisha qidiruv maydoni (ism, matn yoki raqam bo'yicha)
- "…" menyusi: Barcha xabarlar / O'qilmaganlar / Hammasini o'qilgan qilish / Sozlamalar

**Chat**
- iMessage pufaklari "dum" bilan, guruhlash, vaqt sarlavhalari (Bugun, Kecha, Dushanba…)
- Ko'k pufak rangi ekrandagi joyiga qarab gradient bo'lib o'zgaradi (iOS kabi)
- Faqat emoji bo'lsa (1–3 ta) — katta emoji, pufaksiz
- Chapga surish → har bir xabarning vaqti chiqadi
- O'ngga surish yoki tizim "orqaga" ishorasi → iOS kabi orqaga qaytish (predictive back)
- Bosib turish yoki ikki marta bosish → tapback (❤️ 👍 👎 😂 ‼️ ❓) + Nusxa olish / O'chirish / Qayta yuborish
- "Yuborilmoqda…" chizig'i, "Yuborildi", "Yetkazildi", "Yuborilmadi" (qizil ! — bosib qayta yuborish)
- Havolalar va telefon raqamlari bosiladigan
- Ikki SIM bo'lsa — maydon ichida "SIM 1 / SIM 2" tugmasi
- "+" → tezkor javoblar
- Tepada: avatar + ism (bosib kontaktni ochish), qo'ng'iroq tugmasi

**Bildirishnomalar**
- Bildirishnomaning o'zidan javob yozish, "O'qildi" tugmasi
- SMS tasdiqlash kodi bo'lsa — "Nusxalash: 123456" tugmasi

**Boshqa**
- Yangi xabar oynasi (iOS sheet kabi pastdan chiqadi), kontaktlardan tanlash yoki raqam yozish
- Sozlamalar: asosiy SMS ilova, yetkazilganlik hisoboti, SIM tanlash, mavzu (tizim/yorug'/qorong'i),
  pufak rangi (ko'k/yashil), Liquid Glass yoqish/o'chirish
- Qo'ng'iroqni rad etib "SMS bilan javob berish" ishlaydi

**Cheklovlar:** MMS yuklab olinmaydi va yuborilmaydi (eski MMS'lar matni va rasmi ko'rinadi).
Reaksiyalar faqat shu telefonda saqlanadi, qabul qiluvchiga yuborilmaydi.

## APK yig'ish (GitHub Actions)

### Telefondan (eng oson)
1. github.com da yangi repo oching (masalan `mros-xabarlar`).
2. **Add file → Upload files** → `MROS-Xabarlar.zip` faylini yuklang → **Commit**.
3. **Add file → Create new file** → nomiga aynan `.github/workflows/build.yml` deb yozing,
   ichiga shu loyihadagi `.github/workflows/build.yml` matnini qo'ying → **Commit**.
4. **Actions** bo'limiga o'ting → "APK yig'ish" ishini oching (5–8 daqiqa).
5. Tugagach pastdagi **Artifacts** dan `MROS-Xabarlar-APK` ni yuklab oling, ichida `MROS-Xabarlar.apk`.

Workflow repoda faqat zip bo'lsa uni o'zi ochadi.

### Kompyuterdan
Zip'ni ochib, barcha fayllarni (shu jumladan `.github` papkasini) repoga yuklang — Actions o'zi ishga tushadi.

## O'rnatish
1. APK'ni o'rnating (noma'lum manbalarga ruxsat bering).
2. Ilovani oching → **Davom etish** → "Xabarlar"ni **asosiy SMS ilova** qilib tanlang.
3. Kontaktlar, bildirishnoma va telefon ruxsatlarini bering.

Barcha versiyalar bitta kalit (`keystore/mros.jks`) bilan imzolanadi — yangi APK eskisining ustiga o'rnatiladi.
Bu kalit faqat shaxsiy foydalanish uchun; ilovani Play Market'ga chiqarmoqchi bo'lsangiz, yangi kalit yarating.

## Loyiha tuzilishi
```
app/src/main/java/uz/mros/messages/
  MainActivity.kt, MessagesApp.kt
  data/     SmsRepo (SMS/MMS bazasi), Contacts, Prefs, Photos, Models
  sms/      SmsSender, Receivers (kiruvchi SMS, hisobotlar, bildirishnoma tugmalari), Notifier, HeadlessSmsSendService
  ui/glass/ Glass.kt — Liquid Glass effekti
  ui/nav/   Nav.kt — iOS push/pop animatsiyalari, orqaga surish
  ui/screens/ Suhbatlar, Chat, Yangi xabar, Sozlamalar, Kirish
  ui/components/ ikonkalar, tugmalar, menyular, xabar maydoni
```

Talablar: Android 8.0+ (minSdk 26). Blur — Android 12+, refraction — Android 13+.
