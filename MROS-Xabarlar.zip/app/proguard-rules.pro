# Minify o'chirilgan. Kerak bo'lsa qoidalar shu yerga yoziladi.
