package uz.mros.messages

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.provider.Telephony
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Modifier
import kotlinx.coroutines.delay
import uz.mros.messages.data.Updater
import uz.mros.messages.ui.components.WhatsNew
import uz.mros.messages.ui.components.WhatsNewSheet
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import uz.mros.messages.data.Prefs
import uz.mros.messages.data.SmsRepo
import uz.mros.messages.sms.Notifier
import uz.mros.messages.ui.AppViewModel
import uz.mros.messages.ui.nav.NavHostView
import uz.mros.messages.ui.screens.OnboardingScreen
import uz.mros.messages.ui.theme.MrosTheme
import uz.mros.messages.util.Fmt

class MainActivity : ComponentActivity() {
    companion object {
        const val ACTION_OPEN_THREAD = "uz.mros.messages.action.OPEN_THREAD"
    }

    private val vm: AppViewModel by viewModels()

    private val roleLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        requestRuntimePermissions()
    }

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.refreshPermissions()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        vm.refreshPermissions()
        if (savedInstanceState == null) handleIntent(intent)
        Updater.autoCheck()

        setContent {
            val theme by Prefs.theme.collectAsState()
            val dark = when (theme) {
                1 -> false
                2 -> true
                else -> isSystemInDarkTheme()
            }
            MrosTheme(dark) {
                // yangilangandan keyin — "Yangi nima bor" (qanday ishlatishni tushuntiradi)
                LaunchedEffect(vm.canRead) {
                    if (vm.canRead && Prefs.seenWhatsNew.value < WhatsNew.REVISION) {
                        delay(600)
                        vm.whatsNewVisible = true
                    }
                }
                Box(Modifier.fillMaxSize()) {
                    if (vm.canRead) {
                        NavHostView(vm, onRequestDefault = { requestDefaultSms() })
                    } else {
                        OnboardingScreen(onContinue = { startSetup() }, onOpenSettings = { openAppSettings() })
                    }
                    WhatsNewSheet(vm.whatsNewVisible) {
                        vm.whatsNewVisible = false
                        Prefs.setSeenWhatsNew(WhatsNew.REVISION)
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        Notifier.appVisible = true
        vm.refreshPermissions()
    }

    override fun onPause() {
        super.onPause()
        Notifier.appVisible = false
    }

    private fun handleIntent(intent: Intent?) {
        if (intent == null) return
        when (intent.action) {
            ACTION_OPEN_THREAD -> {
                val t = intent.getLongExtra(Notifier.EXTRA_THREAD, -1L)
                if (t > 0) vm.openThread(t)
            }
            Intent.ACTION_SENDTO, Intent.ACTION_VIEW, Intent.ACTION_SEND -> {
                val addresses = Fmt.addressesFromUri(intent.data)
                val body = intent.getStringExtra("sms_body")
                    ?: intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                    ?: Fmt.bodyFromUri(intent.data)
                if (addresses.isNotEmpty()) vm.openAddresses(addresses, body) else vm.openNewMessage(body)
            }
        }
    }

    private fun startSetup() {
        if (!SmsRepo.isDefault(this)) requestDefaultSms() else requestRuntimePermissions()
    }

    private fun requestDefaultSms() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_SMS) && !rm.isRoleHeld(RoleManager.ROLE_SMS)) {
                    roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_SMS))
                    return
                }
            } else {
                @Suppress("DEPRECATION")
                val i = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                    .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
                roleLauncher.launch(i)
                return
            }
        } catch (_: Exception) {
        }
        requestRuntimePermissions()
    }

    private fun requestRuntimePermissions() {
        val perms = mutableListOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_PHONE_STATE,
        )
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            permLauncher.launch(missing.toTypedArray())
        } else {
            vm.refreshPermissions()
        }
    }

    private fun openAppSettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
            )
        } catch (_: Exception) {
        }
    }
}
