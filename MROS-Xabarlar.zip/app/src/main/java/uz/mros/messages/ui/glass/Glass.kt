package uz.mros.messages.ui.glass

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import uz.mros.messages.data.Prefs
import uz.mros.messages.ui.theme.LocalIos
import kotlin.math.max
import kotlin.math.min

/**
 * Liquid Glass uchun "orqa fon" manbasi.
 * Ekran kontenti [backdropSource] orqali GraphicsLayer'ga yoziladi,
 * [Glass] panellari esa shu qatlamni xiralashtirib (blur), to'yintirib
 * va chetlarida sindirib (refraction, Android 13+) chizadi.
 *
 * Muhim: [Glass] hech qachon o'zi foydalanayotgan [backdropSource] ichida bo'lmasligi kerak.
 */
@Stable
class Backdrop internal constructor(internal val layer: GraphicsLayer) {
    internal var coords: LayoutCoordinates? = null
    internal var version by mutableIntStateOf(0)
    private var counter = 0

    internal fun bump() {
        counter++
        version = counter // faqat yozish — o'qish yo'q, shuning uchun sikl bo'lmaydi
    }
}

@Composable
fun rememberBackdrop(): Backdrop {
    val layer = rememberGraphicsLayer()
    return remember(layer) { Backdrop(layer) }
}

fun Modifier.backdropSource(backdrop: Backdrop): Modifier = this
    .onGloballyPositioned { backdrop.coords = it }
    .drawWithContent {
        backdrop.layer.record { this@drawWithContent.drawContent() }
        drawLayer(backdrop.layer)
        backdrop.bump()
    }

private class CoordsHolder {
    var coords: LayoutCoordinates? = null
}

private fun cornerOf(shape: Shape, size: IntSize, density: Density): Float =
    if (shape is CornerBasedShape) {
        shape.topStart.toPx(Size(size.width.toFloat(), size.height.toFloat()), density)
    } else {
        0f
    }

/**
 * Shisha panel. [backdrop] null bo'lsa yoki Android 12 dan past bo'lsa — yarim shaffof oddiy fon.
 */
@Composable
fun Glass(
    backdrop: Backdrop?,
    shape: Shape,
    modifier: Modifier = Modifier,
    tint: Color = Color.Unspecified,
    blur: Dp = 16.dp,
    lens: Float = 1f,
    shadow: Dp = 8.dp,
    rim: Boolean = true,
    content: @Composable BoxScope.() -> Unit = {},
) {
    val ios = LocalIos.current
    val glassOn by Prefs.glass.collectAsState()
    val live = backdrop != null && glassOn && Build.VERSION.SDK_INT >= 31
    val holder = remember { CoordsHolder() }
    var size by remember { mutableStateOf(IntSize.Zero) }
    val density = LocalDensity.current
    val outerShape = shape
    val liveTint = if (tint == Color.Unspecified) ios.glassTint else tint
    val solidTint = if (tint == Color.Unspecified) ios.glassSolid else tint.copy(alpha = max(tint.alpha, 0.9f))
    val shadowMod = if (shadow > 0.dp) {
        Modifier.shadow(
            elevation = shadow,
            shape = outerShape,
            clip = false,
            ambientColor = Color.Black.copy(alpha = 0.10f),
            spotColor = Color.Black.copy(alpha = 0.18f),
        )
    } else {
        Modifier
    }

    Box(
        modifier
            .then(shadowMod)
            .clip(outerShape)
            .onGloballyPositioned { holder.coords = it }
            .onSizeChanged { size = it }
    ) {
        if (live && backdrop != null && size.width > 0 && size.height > 0) {
            val effect = remember(size, blur, lens, outerShape, density) {
                val corner = cornerOf(outerShape, size, density)
                GlassFx.create(
                    blurPx = with(density) { blur.toPx() },
                    w = size.width.toFloat(),
                    h = size.height.toFloat(),
                    corner = corner,
                    lensPx = lens * with(density) { 10.dp.toPx() },
                )
            }
            Box(
                Modifier
                    .matchParentSize()
                    .graphicsLayer {
                        renderEffect = effect
                        clip = true
                        this.shape = outerShape
                    }
                    .drawBehind {
                        val v = backdrop.version
                        val src = backdrop.coords
                        val me = holder.coords
                        if (v >= 0 && src != null && me != null && src.isAttached && me.isAttached) {
                            val off = src.localPositionOf(me, Offset.Zero)
                            translate(-off.x, -off.y) {
                                drawLayer(backdrop.layer)
                            }
                        }
                    }
            )
        }
        Box(Modifier.matchParentSize().background(if (live) liveTint else solidTint))
        if (rim) {
            Box(
                Modifier
                    .matchParentSize()
                    .border(
                        width = 0.8.dp,
                        brush = Brush.linearGradient(
                            listOf(ios.glassRim, ios.glassRim.copy(alpha = 0.05f), ios.glassRim.copy(alpha = 0.45f))
                        ),
                        shape = outerShape,
                    )
            )
        }
        content()
    }
}

@RequiresApi(31)
private object GlassFx {
    fun create(blurPx: Float, w: Float, h: Float, corner: Float, lensPx: Float): RenderEffect {
        val r = blurPx.coerceAtLeast(0.5f)
        val blur = android.graphics.RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP)
        val matrix = ColorMatrix().apply { setSaturation(1.5f) }
        val vivid = android.graphics.RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(matrix), blur)
        if (lensPx > 0f && w > 2f && h > 2f && Build.VERSION.SDK_INT >= 33) {
            val lens = LensFx.create(w, h, corner, lensPx)
            if (lens != null) {
                return android.graphics.RenderEffect.createChainEffect(lens, vivid).asComposeRenderEffect()
            }
        }
        return vivid.asComposeRenderEffect()
    }
}

/** Chetlarda yorug'likni sindiruvchi AGSL shader (Android 13+). Xato bo'lsa — o'chadi. */
@RequiresApi(33)
private object LensFx {
    @Volatile
    private var failed = false

    private const val SRC = """
uniform shader content;
uniform float2 uSize;
uniform float uRadius;
uniform float uEdge;
uniform float uStrength;

float sdRoundRect(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + float2(r, r);
    return length(max(q, float2(0.0, 0.0))) + min(max(q.x, q.y), 0.0) - r;
}

half4 main(float2 coord) {
    float2 halfSize = uSize * 0.5;
    float2 p = coord - halfSize;
    float r = min(uRadius, min(halfSize.x, halfSize.y));
    float d = sdRoundRect(p, halfSize, r);
    float t = clamp(1.0 + d / uEdge, 0.0, 1.0);
    float dx = sdRoundRect(p + float2(1.0, 0.0), halfSize, r) - sdRoundRect(p - float2(1.0, 0.0), halfSize, r);
    float dy = sdRoundRect(p + float2(0.0, 1.0), halfSize, r) - sdRoundRect(p - float2(0.0, 1.0), halfSize, r);
    float2 n = float2(dx, dy);
    n = n / max(length(n), 0.0001);
    float k = t * t;
    float2 uv = coord - n * (k * uStrength);
    half4 c = content.eval(uv);
    return c;
}
"""

    fun create(w: Float, h: Float, corner: Float, strength: Float): android.graphics.RenderEffect? {
        if (failed) return null
        return try {
            val shader = RuntimeShader(SRC)
            val edge = min(min(w, h) * 0.5f, max(corner, 12f) * 1.15f).coerceAtLeast(1f)
            shader.setFloatUniform("uSize", w, h)
            shader.setFloatUniform("uRadius", corner)
            shader.setFloatUniform("uEdge", edge)
            shader.setFloatUniform("uStrength", strength)
            android.graphics.RenderEffect.createRuntimeShaderEffect(shader, "content")
        } catch (t: Throwable) {
            failed = true
            null
        }
    }
}
