package uz.mros.messages.ui.glass

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import uz.mros.messages.data.Prefs
import uz.mros.messages.ui.theme.LocalIos
import kotlin.math.max
import kotlin.math.min

/**
 * Liquid Glass uchun "orqa fon" manbasi.
 * Ekran kontenti [backdropSource] orqali GraphicsLayer'ga yoziladi, [Glass] esa shu
 * qatlamni o'zining ostidagi qismidan olib, linza kabi sindirib chizadi.
 *
 * Muhim: [Glass] hech qachon o'zi foydalanayotgan [backdropSource] ichida bo'lmasligi kerak.
 */
@Stable
class Backdrop internal constructor(internal val layer: GraphicsLayer) {
    internal var coords: LayoutCoordinates? = null
    internal var version by mutableIntStateOf(0)
    private var counter = 0

    internal fun bump() {
        counter++
        version = counter // faqat yozish — o'qish yo'q, shuning uchun sikl bo'lmaydi
    }
}

@Composable
fun rememberBackdrop(): Backdrop {
    val layer = rememberGraphicsLayer()
    return remember(layer) { Backdrop(layer) }
}

fun Modifier.backdropSource(backdrop: Backdrop): Modifier = this
    .onGloballyPositioned { backdrop.coords = it }
    .drawWithContent {
        backdrop.layer.record { this@drawWithContent.drawContent() }
        drawLayer(backdrop.layer)
        backdrop.bump()
    }

/** Barmoq bosilgandagi holat: shisha "suyuq" kabi kattalashadi va barmoq ostida yorishadi. */
@Stable
class GlassTouch {
    var pos by mutableStateOf(Offset.Unspecified)
    val amount = Animatable(0f)

    suspend fun press(down: Boolean) {
        if (down) {
            amount.animateTo(1f, spring(dampingRatio = 0.62f, stiffness = 520f))
        } else {
            // past so'nish — qo'yib yuborganda "jele" kabi tebranadi
            amount.animateTo(0f, spring(dampingRatio = 0.32f, stiffness = 260f))
        }
    }
}

private class CoordsHolder {
    var coords: LayoutCoordinates? = null
}

private fun cornerOf(shape: Shape, w: Float, h: Float, density: Density): Float =
    if (shape is CornerBasedShape) shape.topStart.toPx(Size(w, h), density) else 0f

/**
 * Shisha panel.
 * - Android 13+: haqiqiy Liquid Glass (linza sinishi, rang ajralishi, yorug'lik nuri, barmoq yorug'i)
 * - Android 12: xiralik + yarim shaffof rang
 * - Undan past yoki [backdrop] null: oddiy yarim shaffof fon
 *
 * @param blur orqa fonning xiraligi (iOS "clear" shisha uchun kichik)
 * @param lens linza kuchi (0 = sinishsiz)
 */
@Composable
fun Glass(
    backdrop: Backdrop?,
    shape: Shape,
    modifier: Modifier = Modifier,
    tint: Color = Color.Unspecified,
    blur: Dp = 5.dp,
    lens: Float = 1f,
    shadow: Dp = 10.dp,
    rim: Boolean = true,
    touch: GlassTouch? = null,
    content: @Composable BoxScope.() -> Unit = {},
) {
    val ios = LocalIos.current
    val glassOn by Prefs.glass.collectAsState()
    val live = backdrop != null && glassOn && Build.VERSION.SDK_INT >= 31
    val liquid = remember { if (Build.VERSION.SDK_INT >= 33) LiquidShader.tryCreate() else null }
    val useShader = live && liquid != null && lens > 0f
    val holder = remember { CoordsHolder() }
    val outerShape = shape
    val liveTint = if (tint == Color.Unspecified) ios.glassTint else tint
    val solidTint = if (tint == Color.Unspecified) ios.glassSolid else tint.copy(alpha = max(tint.alpha, 0.9f))
    val specular = if (ios.dark) 0.62f else 0.9f
    val shade = if (ios.dark) 0f else 0.07f

    val shadowMod = if (shadow > 0.dp) {
        Modifier.shadow(
            elevation = shadow,
            shape = outerShape,
            clip = false,
            ambientColor = Color.Black.copy(alpha = 0.07f),
            spotColor = Color.Black.copy(alpha = 0.16f),
        )
    } else {
        Modifier
    }

    Box(
        modifier
            .then(shadowMod)
            .clip(outerShape)
            .onGloballyPositioned { holder.coords = it }
    ) {
        if (live && backdrop != null) {
            Box(
                Modifier
                    .matchParentSize()
                    .graphicsLayer {
                        val w = size.width
                        val h = size.height
                        val blurPx = blur.toPx()
                        val base = GlassFx.base(blurPx)
                        var fx: android.graphics.RenderEffect = base
                        if (useShader && liquid != null && w > 2f && h > 2f) {
                            val corner = cornerOf(outerShape, w, h, this)
                            val bezel = min(min(w, h) * 0.5f, min(max(corner, 8.dp.toPx()) * 0.95f, 24.dp.toPx()))
                            val refract = lens * min(bezel * 0.7f, 18.dp.toPx())
                            val amt = (touch?.amount?.value ?: 0f).coerceIn(0f, 1f)
                            val tp = touch?.pos ?: Offset.Unspecified
                            val tx = if (tp.isSpecified) tp.x else w / 2f
                            val ty = if (tp.isSpecified) tp.y else h / 2f
                            val made = liquid.effect(
                                input = base,
                                w = w,
                                h = h,
                                corner = corner,
                                bezel = bezel,
                                refract = refract * (1f + 0.25f * amt),
                                chroma = 0.16f,
                                rimW = 1.4.dp.toPx(),
                                spec = specular,
                                shade = shade,
                                tint = liveTint,
                                tx = tx,
                                ty = ty,
                                tAmt = amt,
                            )
                            if (made != null) fx = made
                        }
                        renderEffect = fx.asComposeRenderEffect()
                        clip = true
                        this.shape = outerShape
                    }
                    .drawBehind {
                        val v = backdrop.version
                        val src = backdrop.coords
                        val me = holder.coords
                        if (v >= 0 && src != null && me != null && src.isAttached && me.isAttached) {
                            val off = src.localPositionOf(me, Offset.Zero)
                            translate(-off.x, -off.y) {
                                drawLayer(backdrop.layer)
                            }
                        }
                    }
            )
        }
        if (!useShader) {
            Box(Modifier.matchParentSize().background(if (live) liveTint else solidTint))
            if (rim) {
                Box(
                    Modifier
                        .matchParentSize()
                        .border(
                            width = 0.8.dp,
                            brush = Brush.linearGradient(
                                listOf(ios.glassRim, ios.glassRim.copy(alpha = 0.05f), ios.glassRim.copy(alpha = 0.45f))
                            ),
                            shape = outerShape,
                        )
                )
            }
        }
        content()
    }
}

@RequiresApi(31)
private object GlassFx {
    fun base(blurPx: Float): android.graphics.RenderEffect {
        val r = blurPx.coerceAtLeast(0.5f)
        val blur = android.graphics.RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP)
        val matrix = ColorMatrix().apply { setSaturation(1.35f) }
        return android.graphics.RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(matrix), blur)
    }
}

/**
 * Liquid Glass AGSL shaderi (Android 13+).
 * Chetda "gumbaz" profili bo'yicha fonni ichkariga sindiradi (linza), R/G/B kanallarni
 * biroz ajratadi, yorug'lik tushgan chetda nur chizig'i, qarama-qarshi chetda kuchsizroq aks,
 * barmoq ostida yumshoq yorug'lik. Kompilyatsiya xatosi bo'lsa — o'chadi, oddiy blur qoladi.
 */
@RequiresApi(33)
internal class LiquidShader private constructor() {
    private val shader = RuntimeShader(SRC)

    fun effect(
        input: android.graphics.RenderEffect,
        w: Float,
        h: Float,
        corner: Float,
        bezel: Float,
        refract: Float,
        chroma: Float,
        rimW: Float,
        spec: Float,
        shade: Float,
        tint: Color,
        tx: Float,
        ty: Float,
        tAmt: Float,
    ): android.graphics.RenderEffect? {
        if (broken) return null
        return try {
            shader.setFloatUniform("uSize", w, h)
            shader.setFloatUniform("uRadius", corner)
            shader.setFloatUniform("uBezel", max(bezel, 1f))
            shader.setFloatUniform("uRefract", refract)
            shader.setFloatUniform("uChroma", chroma)
            shader.setFloatUniform("uRimW", max(rimW, 0.5f))
            shader.setFloatUniform("uSpec", spec)
            shader.setFloatUniform("uShade", shade)
            shader.setFloatUniform("uTint", tint.red, tint.green, tint.blue, tint.alpha)
            shader.setFloatUniform("uTouch", tx, ty, tAmt)
            val lensFx = android.graphics.RenderEffect.createRuntimeShaderEffect(shader, "content")
            android.graphics.RenderEffect.createChainEffect(lensFx, input)
        } catch (t: Throwable) {
            broken = true
            null
        }
    }

    companion object {
        @Volatile
        private var broken = false

        fun tryCreate(): LiquidShader? {
            if (broken) return null
            return try {
                LiquidShader()
            } catch (t: Throwable) {
                broken = true
                null
            }
        }

        private const val SRC = """
uniform shader content;
uniform float2 uSize;
uniform float uRadius;
uniform float uBezel;
uniform float uRefract;
uniform float uChroma;
uniform float uRimW;
uniform float uSpec;
uniform float uShade;
uniform float4 uTint;
uniform float3 uTouch;

float sdRoundRect(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + float2(r, r);
    return length(max(q, float2(0.0, 0.0))) + min(max(q.x, q.y), 0.0) - r;
}

half4 main(float2 coord) {
    float2 hs = uSize * 0.5;
    float2 p = coord - hs;
    float r = min(uRadius, min(hs.x, hs.y));
    float d = sdRoundRect(p, hs, r);
    float inside = max(-d, 0.0);

    float e = 0.75;
    float2 g = float2(
        sdRoundRect(p + float2(e, 0.0), hs, r) - sdRoundRect(p - float2(e, 0.0), hs, r),
        sdRoundRect(p + float2(0.0, e), hs, r) - sdRoundRect(p - float2(0.0, e), hs, r)
    );
    float2 n = g / max(length(g), 0.0001);

    float x = clamp(1.0 - inside / uBezel, 0.0, 1.0);
    float profile = 1.0 - sqrt(max(1.0 - x * x, 0.0));
    float2 disp = -n * (profile * uRefract);

    float2 lo = float2(0.5, 0.5);
    float2 hi = uSize - float2(0.5, 0.5);
    float2 pg = clamp(coord + disp, lo, hi);
    float2 pr = clamp(coord + disp * (1.0 + uChroma), lo, hi);
    float2 pb = clamp(coord + disp * (1.0 - uChroma), lo, hi);
    float3 col = float3(float(content.eval(pr).r), float(content.eval(pg).g), float(content.eval(pb).b));

    col = mix(col, uTint.rgb, uTint.a);

    float2 L = normalize(float2(-0.55, -0.83));
    float facing = max(dot(n, L), 0.0);
    float back = max(dot(n, -L), 0.0);
    float spec = facing * facing + 0.45 * back * back;

    float rimLine = 1.0 - smoothstep(0.0, uRimW, inside);
    float rimGlow = 1.0 - smoothstep(0.0, uBezel, inside);

    float2 tv = coord - uTouch.xy;
    float tr = max(min(uSize.x, uSize.y) * 0.6, 1.0);
    float touch = uTouch.z * exp(-dot(tv, tv) / (tr * tr));

    float hl = uSpec * (rimLine * (0.25 + 0.75 * spec) + rimGlow * 0.22 * spec) + touch * (0.16 + 0.5 * rimLine);
    col = col + float3(hl, hl, hl);
    col = col - float3(uShade, uShade, uShade) * (rimGlow * back);
    col = clamp(col, 0.0, 1.0);
    return half4(half3(col), 1.0);
}
"""
    }
}
