package uz.mros.messages.data

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import java.util.concurrent.ConcurrentHashMap

object Contacts {
    private val cache = ConcurrentHashMap<String, ContactInfo>()
    private val empty = ContactInfo(null, null, null)

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun clearCache() = cache.clear()

    fun lookup(ctx: Context, address: String): ContactInfo {
        if (address.isBlank()) return empty
        cache[address]?.let { return it }
        var info = empty
        if (hasPermission(ctx) && address.any { it.isDigit() }) {
            try {
                val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address))
                ctx.contentResolver.query(
                    uri,
                    arrayOf("_id", "lookup", "display_name", "photo_thumb_uri"),
                    null, null, null
                )?.use { c ->
                    if (c.moveToFirst()) {
                        val id = c.getLong(0)
                        val lookupKey = c.getString(1)
                        val contactUri = if (lookupKey != null) ContactsContract.Contacts.getLookupUri(id, lookupKey) else null
                        info = ContactInfo(c.getString(2), c.getString(3), contactUri)
                    }
                }
            } catch (_: Exception) {
            }
        }
        cache[address] = info
        return info
    }

    fun all(ctx: Context): List<PhoneContact> {
        if (!hasPermission(ctx)) return emptyList()
        val out = ArrayList<PhoneContact>()
        val seen = HashSet<String>()
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf("display_name", "data1", "data2", "data3", "photo_thumb_uri"),
                null, null, "display_name COLLATE NOCASE ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(0) ?: continue
                    val number = c.getString(1) ?: continue
                    val norm = name + "|" + number.filter { it.isDigit() }.takeLast(9)
                    if (!seen.add(norm)) continue
                    val label = try {
                        ContactsContract.CommonDataKinds.Phone.getTypeLabel(ctx.resources, c.getInt(2), c.getString(3)).toString()
                    } catch (_: Exception) {
                        ""
                    }
                    out += PhoneContact(name, number, label, c.getString(4))
                }
            }
        } catch (_: Exception) {
        }
        return out
    }
}
