package uz.mros.messages.ui.theme

import android.app.Activity
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat

/** iOS tizim ranglari. */
@Immutable
data class IosPalette(
    val dark: Boolean,
    val bg: Color,
    val groupedBg: Color,
    val cell: Color,
    val card: Color,
    val label: Color,
    val secondary: Color,
    val tertiary: Color,
    val separator: Color,
    val fill: Color,
    val switchOff: Color,
    val blue: Color,
    val green: Color,
    val red: Color,
    val orange: Color,
    val yellow: Color,
    val indigo: Color,
    val purple: Color,
    val gray: Color,
    val received: Color,
    val receivedText: Color,
    val glassTint: Color,
    val glassField: Color,
    val glassSolid: Color,
    val menuTint: Color,
    val glassRim: Color,
    val pressed: Color,
)

val LightPalette = IosPalette(
    dark = false,
    bg = Color(0xFFFFFFFF),
    groupedBg = Color(0xFFF2F2F7),
    cell = Color(0xFFFFFFFF),
    card = Color(0xFFF2F2F7),
    label = Color(0xFF000000),
    secondary = Color(0x993C3C43),
    tertiary = Color(0x4D3C3C43),
    separator = Color(0x4A3C3C43),
    fill = Color(0x1F767680),
    switchOff = Color(0xFFE9E9EB),
    blue = Color(0xFF007AFF),
    green = Color(0xFF34C759),
    red = Color(0xFFFF3B30),
    orange = Color(0xFFFF9500),
    yellow = Color(0xFFFFCC00),
    indigo = Color(0xFF5856D6),
    purple = Color(0xFFAF52DE),
    gray = Color(0xFF8E8E93),
    received = Color(0xFFE9E9EB),
    receivedText = Color(0xFF000000),
    glassTint = Color(0x24FFFFFF),
    glassField = Color(0x59FFFFFF),
    glassSolid = Color(0xF2F7F7F9),
    menuTint = Color(0xA8FFFFFF),
    glassRim = Color(0xCCFFFFFF),
    pressed = Color(0xFFE5E5EA),
)

val DarkPalette = IosPalette(
    dark = true,
    bg = Color(0xFF000000),
    groupedBg = Color(0xFF000000),
    cell = Color(0xFF1C1C1E),
    card = Color(0xFF1C1C1E),
    label = Color(0xFFFFFFFF),
    secondary = Color(0x99EBEBF5),
    tertiary = Color(0x4DEBEBF5),
    separator = Color(0x99545458),
    fill = Color(0x3D767680),
    switchOff = Color(0xFF39393D),
    blue = Color(0xFF0A84FF),
    green = Color(0xFF30D158),
    red = Color(0xFFFF453A),
    orange = Color(0xFFFF9F0A),
    yellow = Color(0xFFFFD60A),
    indigo = Color(0xFF5E5CE6),
    purple = Color(0xFFBF5AF2),
    gray = Color(0xFF8E8E93),
    received = Color(0xFF262629),
    receivedText = Color(0xFFFFFFFF),
    glassTint = Color(0x2E1C1C1E),
    glassField = Color(0x4D1C1C1E),
    glassSolid = Color(0xF21C1C1E),
    menuTint = Color(0x9E2C2C2E),
    glassRim = Color(0x4DFFFFFF),
    pressed = Color(0xFF2C2C2E),
)

val LocalIos = staticCompositionLocalOf { LightPalette }

object IosType {
    val largeTitle = TextStyle(fontSize = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.2.sp, lineHeight = 41.sp)
    val title2 = TextStyle(fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.26).sp, lineHeight = 28.sp)
    val title3 = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.45).sp, lineHeight = 25.sp)
    val headline = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.43).sp, lineHeight = 22.sp)
    val body = TextStyle(fontSize = 17.sp, letterSpacing = (-0.43).sp, lineHeight = 22.sp)
    val callout = TextStyle(fontSize = 16.sp, letterSpacing = (-0.31).sp, lineHeight = 21.sp)
    val subhead = TextStyle(fontSize = 15.sp, letterSpacing = (-0.23).sp, lineHeight = 20.sp)
    val footnote = TextStyle(fontSize = 13.sp, letterSpacing = (-0.08).sp, lineHeight = 18.sp)
    val caption = TextStyle(fontSize = 12.sp, lineHeight = 16.sp)
    val caption2 = TextStyle(fontSize = 11.sp, letterSpacing = 0.06.sp, lineHeight = 13.sp)
}

@Composable
fun MrosTheme(dark: Boolean, content: @Composable () -> Unit) {
    val palette = if (dark) DarkPalette else LightPalette
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val c = WindowCompat.getInsetsController(window, view)
                c.isAppearanceLightStatusBars = !dark
                c.isAppearanceLightNavigationBars = !dark
                window.decorView.setBackgroundColor(if (dark) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
            }
        }
    }
    val scheme = if (dark) {
        darkColorScheme(primary = palette.blue, background = palette.bg, surface = palette.bg, onBackground = palette.label, onSurface = palette.label)
    } else {
        lightColorScheme(primary = palette.blue, background = palette.bg, surface = palette.bg, onBackground = palette.label, onSurface = palette.label)
    }
    CompositionLocalProvider(LocalIos provides palette) {
        MaterialTheme(colorScheme = scheme) {
            CompositionLocalProvider(
                LocalContentColor provides palette.label,
                LocalTextStyle provides IosType.body,
            ) {
                content()
            }
        }
    }
}
