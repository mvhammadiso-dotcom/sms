package uz.mros.messages.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import uz.mros.messages.BuildConfig
import uz.mros.messages.sms.Notifier
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class ReleaseInfo(
    val tag: String,
    val build: Int,
    val name: String,
    val notes: String,
    val apkUrl: String,
    val size: Long,
)

sealed class UpdateState {
    data object Idle : UpdateState()
    data object Checking : UpdateState()
    data object UpToDate : UpdateState()
    data class Available(val release: ReleaseInfo) : UpdateState()
    data class Downloading(val release: ReleaseInfo, val progress: Float) : UpdateState()
    data class Ready(val release: ReleaseInfo, val file: File) : UpdateState()
    data class Failed(val message: String) : UpdateState()
}

/**
 * Ilova ichidan yangilanish: GitHub Releases'dagi eng so'nggi APK.
 * Repo nomi va versiya raqami GitHub Actions'dan BuildConfig orqali keladi.
 */
object Updater {
    const val CHANNEL_URL = "https://t.me/mrosapp"
    const val CREATOR_URL = "https://t.me/mvhammadiso"
    const val CREATOR = "mvhammadiso"
    const val APP_NAME = "MROS SMS"

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow<UpdateState>(UpdateState.Idle)
    val state: StateFlow<UpdateState> = _state

    val currentBuild: Int get() = BuildConfig.VERSION_CODE
    val currentVersion: String get() = BuildConfig.VERSION_NAME
    private val repo: String get() = BuildConfig.UPDATE_REPO

    /** Ilova ochilganda — 6 soatda bir marta, jim tekshiradi. */
    fun autoCheck(ctx: Context? = null) {
        if (System.currentTimeMillis() - Prefs.lastUpdateCheck.value < 6L * 60L * 60L * 1000L) return
        check(silent = true, notifyCtx = ctx?.applicationContext)
    }

    fun check(silent: Boolean = false, notifyCtx: Context? = null) {
        val s = _state.value
        if (s is UpdateState.Checking || s is UpdateState.Downloading) return
        if (repo.isBlank()) {
            if (!silent) _state.value = UpdateState.Failed("Bu nusxa GitHub'da yig'ilmagan — yangilanish manzili yo'q")
            return
        }
        if (!silent) _state.value = UpdateState.Checking
        scope.launch {
            val result = fetchLatest()
            Prefs.setLastUpdateCheck(System.currentTimeMillis())
            if (!silent || result is UpdateState.Available) _state.value = result
            if (silent && notifyCtx != null && result is UpdateState.Available) {
                Notifier.showUpdate(notifyCtx, result.release.tag.removePrefix("v"))
            }
        }
    }

    private fun fetchLatest(): UpdateState {
        var conn: HttpURLConnection? = null
        return try {
            val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
            conn = c
            c.connectTimeout = 15000
            c.readTimeout = 15000
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("User-Agent", "MROS-SMS")
            val code = c.responseCode
            if (code == 404) {
                UpdateState.Failed("Release topilmadi. GitHub repo public (ochiq) bo'lishi kerak.")
            } else if (code != 200) {
                UpdateState.Failed("GitHub javobi: $code")
            } else {
                val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val tag = json.optString("tag_name")
                val build = tag.substringAfterLast('.').filter { it.isDigit() }.toIntOrNull() ?: 0
                var url = ""
                var size = 0L
                val assets = json.optJSONArray("assets")
                if (assets != null) {
                    for (i in 0 until assets.length()) {
                        val a = assets.getJSONObject(i)
                        if (a.optString("name").endsWith(".apk", ignoreCase = true)) {
                            url = a.optString("browser_download_url")
                            size = a.optLong("size")
                            break
                        }
                    }
                }
                val rel = ReleaseInfo(tag, build, json.optString("name", tag), json.optString("body", ""), url, size)
                if (build > currentBuild && url.isNotEmpty()) UpdateState.Available(rel) else UpdateState.UpToDate
            }
        } catch (e: Exception) {
            UpdateState.Failed("Internetni tekshiring (${e.javaClass.simpleName})")
        } finally {
            conn?.disconnect()
        }
    }

    fun download(ctx: Context, rel: ReleaseInfo) {
        if (_state.value is UpdateState.Downloading) return
        val app = ctx.applicationContext
        _state.value = UpdateState.Downloading(rel, 0f)
        scope.launch {
            try {
                val dir = File(app.cacheDir, "updates")
                dir.mkdirs()
                dir.listFiles()?.forEach { it.delete() }
                val file = File(dir, "MROS-SMS-${rel.build}.apk")
                val c = URL(rel.apkUrl).openConnection() as HttpURLConnection
                c.instanceFollowRedirects = true
                c.connectTimeout = 20000
                c.readTimeout = 30000
                c.setRequestProperty("User-Agent", "MROS-SMS")
                val total = if (c.contentLengthLong > 0) c.contentLengthLong else rel.size
                c.inputStream.use { input ->
                    file.outputStream().use { out ->
                        val buf = ByteArray(64 * 1024)
                        var done = 0L
                        var last = 0L
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0 && done - last > 96 * 1024) {
                                last = done
                                _state.value = UpdateState.Downloading(rel, (done.toFloat() / total).coerceIn(0f, 1f))
                            }
                        }
                    }
                }
                c.disconnect()
                _state.value = UpdateState.Ready(rel, file)
                withContext(Dispatchers.Main) { install(app, file) }
            } catch (e: Exception) {
                _state.value = UpdateState.Failed("Yuklab bo'lmadi (${e.javaClass.simpleName})")
            }
        }
    }

    /** false — avval "noma'lum manbalardan o'rnatish" ruxsati kerak (sozlamalar ochildi). */
    fun install(ctx: Context, file: File): Boolean {
        val app = ctx.applicationContext
        if (Build.VERSION.SDK_INT >= 26 && !app.packageManager.canRequestPackageInstalls()) {
            try {
                app.startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + app.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
            return false
        }
        return try {
            val uri = FileProvider.getUriForFile(app, app.packageName + ".fileprovider", file)
            app.startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(uri, "application/vnd.android.package-archive")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            true
        } catch (e: Exception) {
            _state.value = UpdateState.Failed("O'rnatib bo'lmadi (${e.javaClass.simpleName})")
            false
        }
    }
}
