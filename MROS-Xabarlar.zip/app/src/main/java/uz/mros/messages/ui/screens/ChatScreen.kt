package uz.mros.messages.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.mros.messages.data.ContactInfo
import uz.mros.messages.data.Contacts
import uz.mros.messages.data.Message
import uz.mros.messages.data.Prefs
import uz.mros.messages.data.SmsRepo
import uz.mros.messages.sms.Notifier
import uz.mros.messages.sms.SmsSender
import uz.mros.messages.ui.AppViewModel
import uz.mros.messages.ui.components.Avatar
import uz.mros.messages.ui.components.ChatInput
import uz.mros.messages.ui.components.GlassIconButton
import uz.mros.messages.ui.components.Hairline
import uz.mros.messages.ui.components.IosIcons
import uz.mros.messages.ui.components.MenuItem
import uz.mros.messages.ui.components.MenuRow
import uz.mros.messages.ui.glass.Glass
import uz.mros.messages.ui.glass.backdropSource
import uz.mros.messages.ui.glass.rememberBackdrop
import uz.mros.messages.ui.nav.LeftDragHandler
import uz.mros.messages.ui.nav.Nav
import uz.mros.messages.ui.nav.Screen
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos
import uz.mros.messages.util.Fmt

private val QuickReplies = listOf(
    "Hozir bandman, keyinroq yozaman",
    "Yo'ldaman, tez orada yetib boraman",
    "Qo'ng'iroq qila olmayman, yozing",
    "Ha 👍",
    "Yo'q",
    "Rahmat! 🙏",
)

/** Bitta suhbat xabarlarini yuklaydi va yuboradi. */
@Stable
class ChatController(private val app: Context, initialThread: Long, val addresses: List<String>) {
    var threadId by mutableLongStateOf(initialThread)
        private set
    var messages by mutableStateOf<List<Message>>(emptyList())
        private set
    var limit by mutableIntStateOf(300)
        private set
    var hasMore by mutableStateOf(false)
        private set
    var loaded by mutableStateOf(false)
        private set
    private var lastMarked = ""

    suspend fun load() {
        val t = threadId
        if (t <= 0) {
            messages = emptyList()
            loaded = true
            return
        }
        val lim = limit
        val list = withContext(Dispatchers.IO) { SmsRepo.loadMessages(app, t, lim + 1) }
        hasMore = list.size > lim
        messages = if (list.size > lim) list.take(lim) else list
        loaded = true
        val newestUnread = list.firstOrNull { !it.outgoing && !it.read }
        if (newestUnread != null && newestUnread.key != lastMarked) {
            lastMarked = newestUnread.key
            withContext(Dispatchers.IO) {
                SmsRepo.markThreadRead(app, t)
                Notifier.cancel(app, t)
            }
        }
    }

    suspend fun loadMore() {
        if (!hasMore) return
        limit += 300
        load()
    }

    fun send(text: String, subId: Int, scope: CoroutineScope) {
        scope.launch {
            val t = withContext(Dispatchers.IO) {
                var id = threadId
                if (id <= 0) id = SmsRepo.threadIdFor(app, addresses)
                addresses.forEach { SmsSender.send(app, it, text, subId, id) }
                id
            }
            if (t > 0 && threadId <= 0) threadId = t
            SmsRepo.notifyChanged()
        }
    }
}

private fun copyText(ctx: Context, text: String) {
    try {
        val cm = ctx.getSystemService(ClipboardManager::class.java)
        cm?.setPrimaryClip(ClipData.newPlainText("xabar", text))
        if (Build.VERSION.SDK_INT < 33) Toast.makeText(ctx, "Nusxalandi", Toast.LENGTH_SHORT).show()
    } catch (_: Exception) {
    }
}

private fun digitsKey(s: String): String = s.filter { it.isDigit() }.takeLast(9)

@Composable
fun ChatScreen(screen: Screen.Chat, vm: AppViewModel, nav: Nav, isTop: Boolean) {
    val ios = LocalIos.current
    val ctx = LocalContext.current
    val app = ctx.applicationContext
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val conf = LocalConfiguration.current
    val backdrop = rememberBackdrop()
    val listState = rememberLazyListState()
    val controller = remember(screen.key) { ChatController(app, screen.threadId, screen.addresses) }

    val green by Prefs.bubbleGreen.collectAsState()
    val reactions by Prefs.reactions.collectAsState()
    val simPref by Prefs.simSubId.collectAsState()

    var text by rememberSaveable(screen.key) { mutableStateOf(screen.draft) }
    var bubbleMenu by remember { mutableStateOf<BubbleMenu?>(null) }
    var quickOpen by remember { mutableStateOf(false) }
    var inputH by remember { mutableIntStateOf(0) }
    val reveal = remember { Animatable(0f) }
    val revealMax = with(density) { 64.dp.toPx() }
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val maxBubbleWidth = (conf.screenWidthDp * 0.76f).dp

    LaunchedEffect(controller) {
        SmsRepo.version.collectLatest { controller.load() }
    }

    val threadId = controller.threadId
    DisposableEffect(threadId, isTop) {
        if (isTop && threadId > 0) {
            Notifier.openThreadId = threadId
            Notifier.cancel(app, threadId)
        }
        onDispose {
            if (Notifier.openThreadId == threadId) Notifier.openThreadId = -1L
        }
    }

    // chapga surish — vaqtlarni ko'rsatish
    DisposableEffect(isTop) {
        val handler: LeftDragHandler? = if (isTop) {
            object : LeftDragHandler {
                override fun drag(dx: Float) {
                    scope.launch { reveal.snapTo((reveal.value - dx).coerceIn(0f, revealMax)) }
                }

                override fun end() {
                    scope.launch { reveal.animateTo(0f, spring(dampingRatio = 0.8f, stiffness = 380f)) }
                }
            }
        } else {
            null
        }
        if (handler != null) nav.leftHandler = handler
        onDispose {
            if (handler != null && nav.leftHandler === handler) nav.leftHandler = null
        }
    }

    val infos by produceState(screen.addresses.map { ContactInfo(null, null, null) }, screen.addresses) {
        value = withContext(Dispatchers.IO) { screen.addresses.map { Contacts.lookup(app, it) } }
    }
    val names = screen.addresses.mapIndexed { i, a -> infos.getOrNull(i)?.name ?: Fmt.prettyPhone(a) }
    val title = if (names.isEmpty()) "Yangi xabar" else names.joinToString(", ")
    val isGroup = screen.addresses.size > 1
    val canReply = screen.addresses.isNotEmpty() && screen.addresses.all { Fmt.canReplyTo(it) }
    val canCall = screen.addresses.size == 1 && Fmt.canReplyTo(screen.addresses[0])

    val chatItems = remember(controller.messages, isGroup, names) {
        buildChatItems(controller.messages, isGroup) { addr ->
            val k = digitsKey(addr)
            val idx = screen.addresses.indexOfFirst { digitsKey(it) == k }
            if (idx >= 0) names[idx] else Fmt.prettyPhone(addr)
        }
    }

    // SIM tanlash
    val sims = vm.sims
    val effectiveSub = remember(sims, simPref) {
        if (simPref >= 0 && sims.any { it.subId == simPref }) {
            simPref
        } else {
            val d = SmsRepo.defaultSmsSubId()
            if (d >= 0 && (sims.isEmpty() || sims.any { it.subId == d })) d else sims.firstOrNull()?.subId ?: -1
        }
    }
    val simLabel: String? = if (sims.size > 1) {
        val s = sims.firstOrNull { it.subId == effectiveSub }
        if (s != null) "SIM ${s.slot + 1}" else null
    } else {
        null
    }
    val onSim: () -> Unit = {
        if (sims.size > 1) {
            val idx = sims.indexOfFirst { it.subId == effectiveSub }
            val next = sims[(idx + 1).mod(sims.size)]
            Prefs.setSim(next.subId)
            Toast.makeText(ctx, "${next.label} (SIM ${next.slot + 1}) orqali yuboriladi", Toast.LENGTH_SHORT).show()
        }
    }

    val send: () -> Unit = send@{
        val t = text.trim()
        if (t.isEmpty()) return@send
        if (!SmsRepo.canSend(ctx)) {
            Toast.makeText(ctx, "SMS yuborish uchun ruxsat kerak", Toast.LENGTH_SHORT).show()
            return@send
        }
        text = ""
        quickOpen = false
        controller.send(t, effectiveSub, scope)
        scope.launch {
            delay(80)
            listState.animateScrollToItem(0)
        }
    }

    val retry: (Message) -> Unit = { m ->
        scope.launch(Dispatchers.IO) { SmsSender.resend(app, m, effectiveSub) }
    }

    val openContact: () -> Unit = {
        if (!isGroup && screen.addresses.isNotEmpty()) {
            val cu = infos.firstOrNull()?.contactUri
            try {
                if (cu != null) {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, cu))
                } else {
                    ctx.startActivity(
                        Intent(Intent.ACTION_INSERT_OR_EDIT)
                            .setType(ContactsContract.Contacts.CONTENT_ITEM_TYPE)
                            .putExtra(ContactsContract.Intents.Insert.PHONE, screen.addresses[0])
                    )
                }
            } catch (_: Exception) {
                Toast.makeText(ctx, "Kontaktlar ilovasi topilmadi", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // yangi xabar kelganda pastga tushish
    val newestKey = controller.messages.firstOrNull()?.key
    LaunchedEffect(newestKey) {
        if (newestKey != null && listState.firstVisibleItemIndex <= 2) listState.animateScrollToItem(0)
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            reverseLayout = true,
            modifier = Modifier
                .fillMaxSize()
                .backdropSource(backdrop)
                .background(ios.bg),
            contentPadding = PaddingValues(
                top = statusTop + 110.dp,
                bottom = with(density) { inputH.toDp() } + 8.dp,
            ),
        ) {
            items(chatItems, key = { it.key }, contentType = { it.type }) { item ->
                when (item) {
                    is ChatItem.Msg -> MessageRow(
                        item = item,
                        green = green,
                        reaction = reactions[item.msg.key],
                        maxBubbleWidth = maxBubbleWidth,
                        reveal = { reveal.value },
                        revealMax = revealMax,
                        onMenu = { it2, r -> bubbleMenu = BubbleMenu(it2, r) },
                        onRetry = retry,
                    )
                    is ChatItem.Header -> TimeHeader(item.date)
                    is ChatItem.Status -> StatusRow(item, if (green) ios.green else ios.blue) { reveal.value }
                    is ChatItem.Sender -> SenderRow(item.name)
                }
            }
            if (controller.hasMore) {
                item(key = "more-${controller.limit}") {
                    LaunchedEffect(Unit) { controller.loadMore() }
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(36.dp)
                    )
                }
            }
        }

        // yuqori panel: orqaga, avatar + ism, qo'ng'iroq
        Box(
            Modifier
                .fillMaxWidth()
                .height(statusTop + 116.dp)
                .background(
                    Brush.verticalGradient(
                        0f to ios.bg,
                        0.6f to ios.bg.copy(alpha = 0.8f),
                        1f to ios.bg.copy(alpha = 0f),
                    )
                )
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = statusTop + 4.dp, start = 12.dp, end = 12.dp),
            verticalAlignment = Alignment.Top,
        ) {
            GlassIconButton(
                icon = IosIcons.ChevronLeft,
                backdrop = backdrop,
                onClick = { nav.pop() },
                iconSize = 19.dp,
                contentDescription = "Orqaga",
            )
            Column(
                Modifier.weight(1f),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Avatar(
                    name = if (isGroup) null else infos.firstOrNull()?.name,
                    photoUri = if (isGroup) null else infos.firstOrNull()?.photoUri,
                    size = 54.dp,
                    modifier = Modifier.clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = openContact,
                    ),
                )
                Spacer(Modifier.height(5.dp))
                Glass(
                    backdrop = backdrop,
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .widthIn(max = 240.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = openContact,
                        ),
                    shadow = 4.dp,
                ) {
                    Row(
                        Modifier.padding(start = 12.dp, end = 9.dp, top = 5.dp, bottom = 5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = title,
                            style = IosType.footnote.copy(fontWeight = FontWeight.SemiBold),
                            color = ios.label,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f, fill = false),
                        )
                        Spacer(Modifier.width(3.dp))
                        Icon(IosIcons.ChevronRight, null, tint = ios.secondary, modifier = Modifier.size(9.dp))
                    }
                }
            }
            if (canCall) {
                GlassIconButton(
                    icon = IosIcons.Phone,
                    backdrop = backdrop,
                    iconSize = 18.dp,
                    contentDescription = "Qo'ng'iroq",
                    onClick = {
                        try {
                            ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + screen.addresses[0])))
                        } catch (_: Exception) {
                        }
                    },
                )
            } else {
                Spacer(Modifier.size(44.dp))
            }
        }

        // tezkor javoblar
        if (quickOpen && canReply) {
            Glass(
                backdrop = backdrop,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(start = 10.dp, end = 60.dp, bottom = with(density) { inputH.toDp() } + 2.dp),
                tint = ios.menuTint,
                blur = 22.dp,
                shadow = 14.dp,
            ) {
                Column(Modifier.padding(vertical = 4.dp)) {
                    QuickReplies.forEachIndexed { i, q ->
                        MenuRow(MenuItem(q) {}, reserveCheck = false) {
                            text = if (text.isBlank()) q else "$text $q"
                            quickOpen = false
                        }
                        if (i < QuickReplies.lastIndex) Hairline()
                    }
                }
            }
        }

        // pastki panel
        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .onSizeChanged { inputH = it.height }
                .imePadding()
                .navigationBarsPadding()
        ) {
            if (canReply) {
                ChatInput(
                    text = text,
                    onText = { text = it },
                    backdrop = backdrop,
                    sendColor = if (green) ios.green else ios.blue,
                    simLabel = simLabel,
                    onSim = onSim,
                    onPlus = { quickOpen = !quickOpen },
                    onSend = send,
                )
            } else {
                Text(
                    text = "Bu jo'natuvchiga javob yuborib bo'lmaydi",
                    style = IosType.footnote,
                    color = ios.secondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 18.dp),
                )
            }
        }

        BubbleMenuOverlay(
            state = bubbleMenu,
            backdrop = backdrop,
            green = green,
            reactions = reactions,
            maxBubbleWidth = maxBubbleWidth,
            canDelete = vm.isDefault,
            onReact = { m, e -> Prefs.setReaction(m.key, e) },
            onCopy = { s -> copyText(ctx, s) },
            onRetry = retry,
            onDelete = { m -> scope.launch(Dispatchers.IO) { SmsRepo.deleteMessage(app, m) } },
            onDismiss = { bubbleMenu = null },
        )
    }
}
