package uz.mros.messages.util

import android.net.Uri
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

object Fmt {
    const val LINK_TAG = "link"

    private val weekdays = mapOf(
        DayOfWeek.MONDAY to "Dushanba",
        DayOfWeek.TUESDAY to "Seshanba",
        DayOfWeek.WEDNESDAY to "Chorshanba",
        DayOfWeek.THURSDAY to "Payshanba",
        DayOfWeek.FRIDAY to "Juma",
        DayOfWeek.SATURDAY to "Shanba",
        DayOfWeek.SUNDAY to "Yakshanba",
    )
    private val months = arrayOf(
        "yanvar", "fevral", "mart", "aprel", "may", "iyun",
        "iyul", "avgust", "sentabr", "oktabr", "noyabr", "dekabr"
    )
    private val hm: DateTimeFormatter = DateTimeFormatter.ofPattern("HH:mm", Locale.US)

    private fun zdt(ms: Long): ZonedDateTime = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())

    /** Suhbatlar ro'yxati uchun: 14:32 / Kecha / Dushanba / 12.11.26 */
    fun listTime(ms: Long): String {
        val d = zdt(ms)
        val date = d.toLocalDate()
        val today = LocalDate.now()
        return when {
            date == today -> d.format(hm)
            date == today.minusDays(1) -> "Kecha"
            date.isAfter(today.minusDays(7)) && date.isBefore(today) -> weekdays[d.dayOfWeek] ?: ""
            else -> String.format(Locale.US, "%02d.%02d.%02d", date.dayOfMonth, date.monthValue, date.year % 100)
        }
    }

    /** Chat ichidagi sarlavha: Bugun / Kecha / Dushanba / 12-noyabr / 12-noyabr 2025 */
    fun dayLabel(ms: Long): String {
        val d = zdt(ms)
        val date = d.toLocalDate()
        val today = LocalDate.now()
        return when {
            date == today -> "Bugun"
            date == today.minusDays(1) -> "Kecha"
            date.isAfter(today.minusDays(7)) && date.isBefore(today) -> weekdays[d.dayOfWeek] ?: ""
            date.year == today.year -> "${date.dayOfMonth}-${months[date.monthValue - 1]}"
            else -> "${date.dayOfMonth}-${months[date.monthValue - 1]} ${date.year}"
        }
    }

    fun time(ms: Long): String = zdt(ms).format(hm)

    fun prettyPhone(raw: String): String {
        if (raw.isBlank()) return "Noma'lum"
        if (raw.any { it.isLetter() }) return raw
        val digits = raw.filter { it.isDigit() }
        if (digits.length == 12 && digits.startsWith("998")) {
            return "+998 ${digits.substring(3, 5)} ${digits.substring(5, 8)} ${digits.substring(8, 10)} ${digits.substring(10, 12)}"
        }
        if (digits.length == 9 && !raw.startsWith("+")) {
            return "${digits.substring(0, 2)} ${digits.substring(2, 5)} ${digits.substring(5, 7)} ${digits.substring(7, 9)}"
        }
        return raw
    }

    fun initials(name: String?): String? {
        if (name.isNullOrBlank()) return null
        val parts = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() && it[0].isLetter() }
        if (parts.isEmpty()) return null
        return parts.take(2).joinToString("") { it.substring(0, 1).uppercase() }
    }

    fun canReplyTo(address: String): Boolean =
        address.isNotBlank() && address.none { it.isLetter() } && address.count { it.isDigit() } >= 3

    fun addressesFromUri(uri: Uri?): List<String> {
        if (uri == null) return emptyList()
        val ssp = uri.schemeSpecificPart ?: return emptyList()
        return ssp.substringBefore('?')
            .split(',', ';')
            .map { it.trim() }
            .filter { it.isNotEmpty() }
    }

    fun bodyFromUri(uri: Uri?): String? {
        val ssp = uri?.schemeSpecificPart ?: return null
        val q = ssp.substringAfter('?', "")
        if (q.isEmpty()) return null
        val p = q.split('&').firstOrNull { it.startsWith("body=") } ?: return null
        return Uri.decode(p.substringAfter("body="))
    }

    // ---------------------------------------------------------------- tasdiqlash kodlari

    private val codeKeywords = Regex(
        "(kod|code|parol|пароль|код|otp|tasdiq|verification|подтвер|password|pin)",
        RegexOption.IGNORE_CASE
    )
    private val codeRegex = Regex("(?<!\\d)(\\d{4,8})(?!\\d)")

    fun extractCode(text: String): String? {
        if (!codeKeywords.containsMatchIn(text)) return null
        return codeRegex.find(text)?.groupValues?.getOrNull(1)
    }

    // ---------------------------------------------------------------- emoji

    private fun isEmojiCp(cp: Int): Boolean =
        cp in 0x1F000..0x1FAFF || cp in 0x2600..0x27BF || cp in 0x2B00..0x2BFF ||
            cp == 0xFE0F || cp == 0x200D || cp in 0xE0020..0xE007F || cp == 0x20E3 ||
            cp in 0x2190..0x21FF || cp in 0x2300..0x23FF || cp in 0x25A0..0x25FF ||
            cp == 0x00A9 || cp == 0x00AE || cp == 0x203C || cp == 0x2049 || cp == 0x2122 ||
            cp == 0x2139 || cp == 0x3030 || cp == 0x303D || cp == 0x3297 || cp == 0x3299 || cp == 0x24C2

    /** Matn faqat emojidan iborat bo'lsa — nechta emoji, aks holda 0. */
    fun emojiCount(text: String): Int {
        val t = text.trim()
        if (t.isEmpty() || t.length > 48) return 0
        var i = 0
        while (i < t.length) {
            val cp = t.codePointAt(i)
            if (!isEmojiCp(cp)) return 0
            i += Character.charCount(cp)
        }
        val bi = android.icu.text.BreakIterator.getCharacterInstance()
        bi.setText(t)
        var count = 0
        while (bi.next() != android.icu.text.BreakIterator.DONE) count++
        return count
    }

    // ---------------------------------------------------------------- havolalar

    private val urlRegex = Regex(
        "(https?://[^\\s]+|www\\.[^\\s]+|\\b[a-z0-9-]+\\.(uz|com|ru|org|net|io|me|app|info)(/[^\\s]*)?)",
        RegexOption.IGNORE_CASE
    )
    private val phoneRegex = Regex("(\\+?\\d[\\d\\- ()]{5,}\\d)")
    private const val TRAILING = ".,!?)]}»\"':;"

    fun linkify(text: String, linkColor: Color, underline: Boolean): AnnotatedString = buildAnnotatedString {
        append(text)
        val taken = ArrayList<IntRange>()
        val style = SpanStyle(color = linkColor, textDecoration = if (underline) TextDecoration.Underline else null)
        for (m in urlRegex.findAll(text)) {
            val s = m.range.first
            var e = m.range.last + 1
            while (e > s && TRAILING.indexOf(text[e - 1]) >= 0) e--
            if (e - s < 4) continue
            val raw = text.substring(s, e)
            val url = if (raw.startsWith("http", ignoreCase = true)) raw else "https://$raw"
            addStringAnnotation(LINK_TAG, url, s, e)
            addStyle(style, s, e)
            taken.add(s until e)
        }
        for (m in phoneRegex.findAll(text)) {
            val s = m.range.first
            val e = m.range.last + 1
            if (taken.any { s in it || (e - 1) in it }) continue
            val digits = m.value.count { it.isDigit() }
            if (digits < 7 || digits > 13) continue
            val number = m.value.filter { it.isDigit() || it == '+' }
            addStringAnnotation(LINK_TAG, "tel:$number", s, e)
            addStyle(style, s, e)
        }
    }
}
