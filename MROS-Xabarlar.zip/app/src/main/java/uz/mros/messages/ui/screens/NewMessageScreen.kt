package uz.mros.messages.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.mros.messages.data.PhoneContact
import uz.mros.messages.data.Prefs
import uz.mros.messages.data.SmsRepo
import uz.mros.messages.sms.SmsSender
import uz.mros.messages.ui.AppViewModel
import uz.mros.messages.ui.components.Avatar
import uz.mros.messages.ui.components.ChatInput
import uz.mros.messages.ui.components.GlassIconButton
import uz.mros.messages.ui.components.Hairline
import uz.mros.messages.ui.components.IosIcons
import uz.mros.messages.ui.glass.backdropSource
import uz.mros.messages.ui.glass.rememberBackdrop
import uz.mros.messages.ui.nav.Nav
import uz.mros.messages.ui.nav.Screen
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos
import uz.mros.messages.util.Fmt

private data class Recipient(val name: String?, val number: String)

@Composable
fun NewMessageScreen(screen: Screen.NewMessage, vm: AppViewModel, nav: Nav) {
    val ios = LocalIos.current
    val ctx = LocalContext.current
    val app = ctx.applicationContext
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val backdrop = rememberBackdrop()
    val toFocus = remember { FocusRequester() }
    val green = Prefs.bubbleGreen.value

    var recipients by remember { mutableStateOf<List<Recipient>>(emptyList()) }
    var query by remember { mutableStateOf("") }
    var text by rememberSaveable { mutableStateOf(screen.draft) }
    var inputH by remember { mutableIntStateOf(0) }
    var sending by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.loadContacts()
        delay(350)
        try {
            toFocus.requestFocus()
        } catch (_: Exception) {
        }
    }

    val contacts = vm.contacts
    val filtered = remember(contacts, query) {
        val q = query.trim()
        val qd = q.filter { it.isDigit() }
        if (q.isEmpty()) {
            contacts
        } else {
            contacts.filter { c ->
                c.name.contains(q, ignoreCase = true) ||
                    (qd.length >= 2 && c.number.filter { ch -> ch.isDigit() }.contains(qd))
            }
        }
    }
    val rawNumberOk = query.count { it.isDigit() } >= 3 && query.none { it.isLetter() }

    fun addRecipient(r: Recipient) {
        if (recipients.none { it.number == r.number }) recipients = recipients + r
        query = ""
    }

    fun addRaw() {
        if (rawNumberOk) addRecipient(Recipient(null, query.trim()))
    }

    val send: () -> Unit = send@{
        if (sending) return@send
        var rs = recipients
        if (rs.isEmpty() && rawNumberOk) rs = listOf(Recipient(null, query.trim()))
        val t = text.trim()
        if (rs.isEmpty()) {
            Toast.makeText(ctx, "Qabul qiluvchini tanlang", Toast.LENGTH_SHORT).show()
            return@send
        }
        if (t.isEmpty()) return@send
        if (!SmsRepo.canSend(ctx)) {
            Toast.makeText(ctx, "SMS yuborish uchun ruxsat kerak", Toast.LENGTH_SHORT).show()
            return@send
        }
        sending = true
        val addrs = rs.map { it.number }
        scope.launch {
            val thread = withContext(Dispatchers.IO) {
                val id = SmsRepo.threadIdFor(app, addrs)
                val sub = SmsSender.effectiveSubId(app)
                addrs.forEach { SmsSender.send(app, it, t, sub, id) }
                id
            }
            SmsRepo.notifyChanged()
            nav.replace(Screen.Chat(thread, addrs))
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // sarlavha
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(60.dp)
                    .padding(horizontal = 12.dp)
            ) {
                GlassIconButton(
                    icon = IosIcons.Xmark,
                    backdrop = null,
                    onClick = { nav.pop() },
                    iconSize = 17.dp,
                    contentDescription = "Yopish",
                    modifier = Modifier.align(Alignment.CenterStart),
                )
                Text(
                    "Yangi xabar",
                    style = IosType.headline,
                    color = ios.label,
                    modifier = Modifier.align(Alignment.Center),
                )
            }
            // Kimga:
            Row(
                Modifier
                    .fillMaxWidth()
                    .heightIn(min = 48.dp)
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Kimga:", style = IosType.body, color = ios.secondary)
                Spacer(Modifier.width(8.dp))
                Row(
                    Modifier
                        .weight(1f)
                        .horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                    recipients.forEach { r ->
                        Box(
                            Modifier
                                .background(ios.blue.copy(alpha = 0.14f), RoundedCornerShape(50))
                                .clickable { recipients = recipients - r }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(r.name ?: Fmt.prettyPhone(r.number), style = IosType.body, color = ios.blue, maxLines = 1)
                        }
                    }
                    Box(Modifier.widthIn(min = 140.dp)) {
                        if (query.isEmpty() && recipients.isEmpty()) {
                            Text("Ism yoki raqam", style = IosType.body, color = ios.tertiary)
                        }
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = IosType.body.copy(color = ios.label),
                            cursorBrush = SolidColor(ios.blue),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { addRaw() }),
                            modifier = Modifier
                                .widthIn(min = 140.dp)
                                .focusRequester(toFocus),
                        )
                    }
                }
                if (rawNumberOk) {
                    Box(
                        Modifier
                            .size(30.dp)
                            .background(ios.blue, CircleShape)
                            .clickable { addRaw() },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(IosIcons.Plus, "Qo'shish", tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }
            Hairline()
            LazyColumn(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .backdropSource(backdrop)
                    .background(ios.bg),
                contentPadding = PaddingValues(bottom = with(density) { inputH.toDp() } + 8.dp),
            ) {
                if (rawNumberOk) {
                    item(key = "raw") {
                        ContactRow(name = "“${query.trim()}” raqamiga yozish", sub = null, photo = null) { addRaw() }
                    }
                }
                if (contacts.isEmpty()) {
                    item(key = "noc") {
                        Text(
                            "Kontaktlar yo'q yoki ruxsat berilmagan. Raqamni qo'lda kiriting.",
                            style = IosType.footnote,
                            color = ios.secondary,
                            modifier = Modifier.padding(20.dp),
                        )
                    }
                }
                items(filtered, key = { it.name + "|" + it.number }) { c: PhoneContact ->
                    ContactRow(
                        name = c.name,
                        sub = (if (c.label.isNotEmpty()) c.label + "  " else "") + c.number,
                        photo = c.photoUri,
                    ) { addRecipient(Recipient(c.name, c.number)) }
                }
            }
        }

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .onSizeChanged { inputH = it.height }
                .imePadding()
                .navigationBarsPadding()
        ) {
            ChatInput(
                text = text,
                onText = { text = it },
                backdrop = backdrop,
                sendColor = if (green) ios.green else ios.blue,
                simLabel = null,
                onSim = {},
                onPlus = {},
                onSend = send,
            )
        }
    }
}

@Composable
private fun ContactRow(name: String, sub: String?, photo: String?, onClick: () -> Unit) {
    val ios = LocalIos.current
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Avatar(if (sub == null) null else name, photo, 40.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(name, style = IosType.body, color = ios.label, maxLines = 1)
                if (sub != null) Text(sub, style = IosType.footnote, color = ios.secondary, maxLines = 1)
            }
        }
        Hairline(Modifier.padding(start = 68.dp))
    }
}
