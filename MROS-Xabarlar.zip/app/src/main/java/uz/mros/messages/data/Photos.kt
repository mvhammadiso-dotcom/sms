package uz.mros.messages.data

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object Photos {
    private val cache = LruCache<String, ImageBitmap>(80)

    suspend fun load(ctx: Context, uri: String, maxPx: Int): ImageBitmap? = withContext(Dispatchers.IO) {
        val k = "$uri@$maxPx"
        val hit = cache.get(k)
        if (hit != null) return@withContext hit
        try {
            val u = Uri.parse(uri)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= maxPx && bounds.outHeight / (sample * 2) >= maxPx) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, opts) }
            val img = bmp?.asImageBitmap()
            if (img != null) cache.put(k, img)
            img
        } catch (_: Exception) {
            null
        }
    }
}
