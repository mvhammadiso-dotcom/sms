package uz.mros.messages.ui.components

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import uz.mros.messages.data.Updater
import uz.mros.messages.ui.glass.GlassTouch
import uz.mros.messages.ui.theme.IosPalette
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos

/**
 * "Yangi nima bor" — yangilangandan keyin bir marta chiqadi.
 * Yangi funksiya qo'shilganda [REVISION] ni oshiring va ro'yxatni yangilang.
 */
object WhatsNew {
    const val REVISION = 3

    class Item(val icon: ImageVector, val color: (IosPalette) -> Color, val title: String, val howTo: String)

    val items: List<Item> = listOf(
        Item(IosIcons.Bell, { it.red }, "Yangi bildirishnomalar",
            "Ilova ochiq bo'lsa, xabar tepadan shisha banner bo'lib tushadi: bossangiz suhbat ochiladi, yuqoriga sursangiz yopiladi. " +
                "Kod kelsa — bannerdagi ko'k tugma bilan nusxalaysiz. Sozlamalar → Bildirishnomalar'da sinab ko'ring."),
        Item(IosIcons.Drop, { it.blue }, "Suvdek shisha",
            "Tugmalar oq va qora fonda ham suv tomchisidek ko'rinadi: yaltiraydi, chetlari nur sindiradi, bosganda to'lqinlanadi. " +
                "Kalitlarni (switch) bosib tursangiz — tugmacha shishaga aylanib cho'ziladi."),
        Item(IosIcons.Sparkles, { it.purple }, "Ekran effektlari",
            "Yuborish ↑ tugmasini bosib turing va Konfetti, Sharlar, Yuraklar, Mushaklar yoki Qor effektini tanlang. " +
                "“Tug'ilgan kuning bilan”, “Tabriklayman”, “Yangi yil”, “Seni sevaman” so'zlari effektni o'zi yoqadi."),
        Item(IosIcons.Search, { it.indigo }, "Xabarlar ichidan qidiruv",
            "Pastdagi qidiruvga so'z yozing — mos xabarlar chiqadi. Bossangiz, o'sha xabarga olib borib, uni yoritib ko'rsatadi."),
        Item(IosIcons.BellSlash, { it.purple }, "Ovozsiz suhbatlar",
            "Suhbatni chapga suring → “Ovozsiz”. Bu suhbatdan bildirishnoma kelmaydi. Qaytarish uchun yana suring."),
        Item(IosIcons.NoSign, { it.red }, "Raqamni bloklash",
            "Chat tepasidagi ism ustiga bosing → “Bloklash”. Bloklangan raqamlar ro'yxati Sozlamalar'da."),
        Item(IosIcons.Filter, { it.orange }, "Filtrlar",
            "Asosiy ekrandagi filtr tugmasi: Barcha, Ma'lum, Noma'lum jo'natuvchilar yoki O'qilmaganlar."),
        Item(IosIcons.Info, { it.gray }, "Xabar tafsilotlari",
            "Xabarni bosib turing → “Batafsil”: yuborilgan vaqti, holati va necha SMS bo'lgani."),
        Item(IosIcons.Refresh, { it.green }, "Ilova ichidan yangilanish",
            "⚙︎ Sozlamalar → Yangilanishlar. Yangi versiya chiqsa, shu yerdan yuklab o'rnatasiz."),
    )
}

@Composable
private fun StaggerIn(index: Int, visible: Boolean, content: @Composable () -> Unit) {
    val density = LocalDensity.current
    val a = remember { Animatable(0f) }
    LaunchedEffect(visible) {
        if (visible) {
            a.snapTo(0f)
            delay(180L + index * 70L)
            a.animateTo(1f, spring(dampingRatio = 0.75f, stiffness = 260f))
        }
    }
    Box(
        Modifier.graphicsLayer {
            alpha = a.value.coerceIn(0f, 1f)
            translationY = (1f - a.value) * with(density) { 28.dp.toPx() }
        }
    ) {
        content()
    }
}

@Composable
fun WhatsNewSheet(visible: Boolean, onClose: () -> Unit) {
    val ios = LocalIos.current
    val p by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = if (visible) spring(dampingRatio = 0.85f, stiffness = 280f) else tween(220),
        label = "whatsNew",
    )
    if (!visible && p <= 0.01f) return
    val latestClose by rememberUpdatedState(onClose)
    BackHandler(enabled = visible) { latestClose() }
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val h = constraints.maxHeight.toFloat()
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = p.coerceIn(0f, 1f) }
                .background(Color.Black.copy(alpha = 0.4f))
                .blockTouches()
        )
        Column(
            Modifier
                .fillMaxSize()
                .padding(top = statusTop + 18.dp)
                .graphicsLayer { translationY = h * (1f - p) }
                .clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
                .background(ios.bg)
                .blockTouches()
        ) {
            Column(
                Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 30.dp)
            ) {
                Spacer(Modifier.height(34.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { AppIconBadge(72.dp) }
                Spacer(Modifier.height(18.dp))
                Text(
                    "Yangi nima bor",
                    style = IosType.largeTitle,
                    color = ios.label,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "${Updater.APP_NAME} ${Updater.currentVersion}",
                    style = IosType.subhead,
                    color = ios.secondary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(26.dp))
                WhatsNew.items.forEachIndexed { i, item ->
                    StaggerIn(i, visible) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.Top,
                        ) {
                            Box(
                                Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(item.color(ios)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(item.icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
                            }
                            Spacer(Modifier.width(16.dp))
                            Column(Modifier.weight(1f)) {
                                Text(item.title, style = IosType.headline, color = ios.label)
                                Spacer(Modifier.height(2.dp))
                                Text(item.howTo, style = IosType.subhead, color = ios.secondary)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 24.dp, vertical = 16.dp)
            ) {
                LiquidButton(
                    text = "Davom etish",
                    color = ios.blue,
                    height = 54.dp,
                    modifier = Modifier.fillMaxWidth(),
                ) { latestClose() }
            }
        }
    }
}
