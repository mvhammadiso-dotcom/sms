package uz.mros.messages.sms

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.provider.Settings
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.app.RemoteInput
import androidx.core.content.ContextCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlin.math.min
import androidx.core.graphics.drawable.IconCompat
import uz.mros.messages.MainActivity
import uz.mros.messages.R
import uz.mros.messages.data.Contacts
import uz.mros.messages.data.Prefs
import uz.mros.messages.data.SmsRepo
import uz.mros.messages.util.Fmt

/** Ilova ochiq paytda ekran tepasidan tushadigan banner uchun. */
data class InAppMessage(
    val threadId: Long,
    val address: String,
    val title: String,
    val contactName: String?,
    val photoUri: String?,
    val body: String,
    val code: String?,
    val id: Long = System.nanoTime(),
)

object Notifier {
    const val CHANNEL_MESSAGES = "sms_v2"
    const val CHANNEL_OTHER = "other"
    const val CHANNEL_UPDATES = "updates"
    private const val OLD_CHANNEL = "messages"
    private const val GROUP = "uz.mros.messages.SMS"
    private const val SUMMARY_ID = 900_000_001
    private const val UPDATE_ID = 900_000_002
    const val ACTION_REPLY = "uz.mros.messages.action.REPLY"
    const val ACTION_MARK_READ = "uz.mros.messages.action.MARK_READ"
    const val ACTION_COPY_CODE = "uz.mros.messages.action.COPY_CODE"
    const val KEY_REPLY = "reply_text"
    const val EXTRA_THREAD = "thread_id"
    const val EXTRA_ADDRESS = "address"
    const val EXTRA_CODE = "code"

    /** Ilova ekranda va shu suhbat ochiq bo'lsa bildirishnoma chiqmaydi. */
    @Volatile
    var appVisible = false

    @Volatile
    var openThreadId = -1L

    /** Ilova ochiq bo'lsa — tizim banneri o'rniga ilova ichidagi shisha banner. */
    private val _inApp = MutableSharedFlow<InAppMessage>(extraBufferCapacity = 8)
    val inApp: SharedFlow<InAppMessage> = _inApp

    private val mutableFlag: Int = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
    private const val IMMUTABLE = PendingIntent.FLAG_IMMUTABLE
    private const val UPDATE = PendingIntent.FLAG_UPDATE_CURRENT

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        try {
            nm.deleteNotificationChannel(OLD_CHANNEL)
        } catch (_: Exception) {
        }
        val messages = NotificationChannel(CHANNEL_MESSAGES, "Xabarlar", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Yangi SMS xabarlar"
            enableVibration(true)
            vibrationPattern = longArrayOf(0, 60, 90, 60) // iOS kabi qisqa qo'sh titrash
            enableLights(true)
            lightColor = 0xFF34C759.toInt()
            setShowBadge(true)
            lockscreenVisibility = Notification.VISIBILITY_PRIVATE
        }
        val other = NotificationChannel(CHANNEL_OTHER, "Boshqa", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Yuborilmagan xabarlar va MMS"
        }
        val updates = NotificationChannel(CHANNEL_UPDATES, "Yangilanishlar", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Ilovaning yangi versiyalari"
        }
        nm.createNotificationChannel(messages)
        nm.createNotificationChannel(other)
        nm.createNotificationChannel(updates)
    }

    fun notificationId(threadId: Long, address: String = ""): Int =
        if (threadId > 0) (threadId % 800_000_000L).toInt() + 1 else (address.hashCode() and 0x1fffffff) + 1

    private fun canNotify(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    private fun loadBitmap(ctx: Context, uri: String?): Bitmap? {
        if (uri == null) return null
        return try {
            ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) {
            null
        }
    }

    /** iOS kabi dumaloq avatar: rasm, bosh harflar yoki odam silueti. */
    private fun avatarBitmap(ctx: Context, name: String?, photoUri: String?): Bitmap {
        val size = 192
        val f = size.toFloat()
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val photo = loadBitmap(ctx, photoUri)
        if (photo != null && photo.width > 0 && photo.height > 0) {
            val shader = BitmapShader(photo, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val scale = f / min(photo.width, photo.height)
            val m = Matrix()
            m.setScale(scale, scale)
            m.postTranslate((f - photo.width * scale) / 2f, (f - photo.height * scale) / 2f)
            shader.setLocalMatrix(m)
            paint.shader = shader
            c.drawCircle(f / 2f, f / 2f, f / 2f, paint)
            return out
        }
        paint.shader = LinearGradient(0f, 0f, 0f, f, 0xFFA9AEBB.toInt(), 0xFF858A95.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(f / 2f, f / 2f, f / 2f, paint)
        paint.shader = null
        paint.color = 0xFFFFFFFF.toInt()
        val initials = Fmt.initials(name)
        if (initials != null) {
            paint.textSize = f * 0.4f
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            c.drawText(initials, f / 2f, f / 2f - (paint.descent() + paint.ascent()) / 2f, paint)
        } else {
            val clip = Path()
            clip.addCircle(f / 2f, f / 2f, f / 2f, Path.Direction.CW)
            c.save()
            c.clipPath(clip)
            c.drawCircle(f / 2f, f * 0.4f, f * 0.17f, paint)
            c.drawOval(RectF(f * 0.2f, f * 0.64f, f * 0.8f, f * 1.2f), paint)
            c.restore()
        }
        return out
    }

    private fun openIntent(ctx: Context, threadId: Long, requestCode: Int): PendingIntent {
        val open = Intent(ctx, MainActivity::class.java)
            .setAction(MainActivity.ACTION_OPEN_THREAD)
            .putExtra(EXTRA_THREAD, threadId)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, requestCode, open, UPDATE or IMMUTABLE)
    }

    private fun launchIntent(ctx: Context, requestCode: Int): PendingIntent {
        val open = Intent(ctx, MainActivity::class.java)
            .setAction(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return PendingIntent.getActivity(ctx, requestCode, open, UPDATE or IMMUTABLE)
    }

    /**
     * Suhbat yorlig'i: bildirishnoma Android'ning "Suhbatlar" bo'limida katta avatar bilan chiqadi,
     * ilova ikonkasini bosib tursangiz ham oxirgi suhbatlar ko'rinadi.
     */
    private fun pushShortcut(ctx: Context, threadId: Long, name: String, person: Person, icon: IconCompat): String? {
        if (threadId <= 0) return null
        val id = "thread_$threadId"
        return try {
            val intent = Intent(ctx, MainActivity::class.java)
                .setAction(MainActivity.ACTION_OPEN_THREAD)
                .putExtra(EXTRA_THREAD, threadId)
            val sc = ShortcutInfoCompat.Builder(ctx, id)
                .setShortLabel(name.take(24).ifBlank { "Suhbat" })
                .setLongLived(true)
                .setIcon(icon)
                .setPerson(person)
                .setIntent(intent)
                .setCategories(setOf("android.shortcut.conversation"))
                .build()
            ShortcutManagerCompat.pushDynamicShortcut(ctx, sc)
            id
        } catch (_: Exception) {
            null
        }
    }

    private fun postSummary(ctx: Context) {
        val n = NotificationCompat.Builder(ctx, CHANNEL_MESSAGES)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF34C759.toInt())
            .setStyle(NotificationCompat.InboxStyle().setSummaryText("Xabarlar"))
            .setGroup(GROUP)
            .setGroupSummary(true)
            .setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_CHILDREN)
            .setContentIntent(launchIntent(ctx, SUMMARY_ID))
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(SUMMARY_ID, n)
        } catch (_: SecurityException) {
        }
    }

    fun showIncoming(ctx: Context, threadId: Long, address: String, body: String) {
        if (appVisible && threadId > 0 && openThreadId == threadId) return
        if (threadId > 0 && Prefs.isMuted(threadId)) return // "Ovozsiz" suhbat

        val info = Contacts.lookup(ctx, address)
        val name = info.name ?: Fmt.prettyPhone(address)
        val code = Fmt.extractCode(body)
        val inForeground = appVisible

        // ilova ochiq — tepadan shisha banner tushadi, tizim bildirishnomasi esa ovozsiz qoladi
        if (inForeground) {
            _inApp.tryEmit(InAppMessage(threadId, address, name, info.name, info.photoUri, body, code))
        }
        if (!canNotify(ctx)) return

        val preview = Prefs.notifPreview.value
        val hidden = "Yangi xabar"
        val avatar = avatarBitmap(ctx, info.name, info.photoUri)
        val icon = IconCompat.createWithBitmap(avatar)
        val sender = Person.Builder().setName(name).setKey(address).setIcon(icon).setImportant(info.name != null).build()
        val me = Person.Builder().setName("Siz").build()

        val style = NotificationCompat.MessagingStyle(me).setGroupConversation(false)
        val unread = if (threadId > 0) SmsRepo.recentUnread(ctx, threadId, 8) else emptyList()
        if (unread.isEmpty()) {
            style.addMessage(if (preview) body else hidden, System.currentTimeMillis(), sender)
        } else if (preview) {
            unread.forEach { style.addMessage(it.first, it.second, sender) }
        } else {
            style.addMessage(if (unread.size > 1) "${unread.size} ta yangi xabar" else hidden, unread.last().second, sender)
        }

        val id = notificationId(threadId, address)
        val shortcutId = pushShortcut(ctx, threadId, name, sender, icon)

        val builder = NotificationCompat.Builder(ctx, CHANNEL_MESSAGES)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF34C759.toInt())
            .setLargeIcon(avatar)
            .setStyle(style)
            .setContentTitle(name)
            .setContentText(if (preview) body else hidden)
            .setContentIntent(openIntent(ctx, threadId, id))
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setGroup(GROUP)
            .setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_CHILDREN)
            .setNumber(if (unread.isEmpty()) 1 else unread.size)
            .setWhen(System.currentTimeMillis())
            .setShowWhen(true)
            .setLights(0xFF34C759.toInt(), 600, 2400)
            .setSilent(inForeground)
            .addPerson(sender)
        if (shortcutId != null) builder.setShortcutId(shortcutId)

        // qulflangan ekranda matn ko'rinmaydi
        builder.setPublicVersion(
            NotificationCompat.Builder(ctx, CHANNEL_MESSAGES)
                .setSmallIcon(R.drawable.ic_notification)
                .setColor(0xFF34C759.toInt())
                .setContentTitle(name)
                .setContentText(hidden)
                .build()
        )

        // 1) tasdiqlash kodi bo'lsa — birinchi tugma
        if (code != null) {
            val copyIntent = Intent(ctx, NotificationActionReceiver::class.java)
                .setAction(ACTION_COPY_CODE)
                .putExtra(EXTRA_CODE, code)
                .putExtra(EXTRA_THREAD, threadId)
            val copyPi = PendingIntent.getBroadcast(ctx, id, copyIntent, UPDATE or IMMUTABLE)
            val label = if (preview) "Nusxalash: $code" else "Kodni nusxalash"
            builder.addAction(NotificationCompat.Action.Builder(R.drawable.ic_notification, label, copyPi).build())
        }

        // 2) javob — faqat oddiy raqamlarga (bank/operator nomlariga javob yozib bo'lmaydi)
        if (Fmt.canReplyTo(address)) {
            val replyIntent = Intent(ctx, NotificationActionReceiver::class.java)
                .setAction(ACTION_REPLY)
                .putExtra(EXTRA_THREAD, threadId)
                .putExtra(EXTRA_ADDRESS, address)
            val replyPi = PendingIntent.getBroadcast(ctx, id, replyIntent, UPDATE or mutableFlag)
            val remoteInput = RemoteInput.Builder(KEY_REPLY).setLabel("Javob yozing…").build()
            builder.addAction(
                NotificationCompat.Action.Builder(R.drawable.ic_notification, "Javob", replyPi)
                    .addRemoteInput(remoteInput)
                    .setAllowGeneratedReplies(true)
                    .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
                    .setShowsUserInterface(false)
                    .build()
            )
        }

        // 3) o'qildi
        val readIntent = Intent(ctx, NotificationActionReceiver::class.java)
            .setAction(ACTION_MARK_READ)
            .putExtra(EXTRA_THREAD, threadId)
        val readPi = PendingIntent.getBroadcast(ctx, id, readIntent, UPDATE or IMMUTABLE)
        builder.addAction(
            NotificationCompat.Action.Builder(R.drawable.ic_notification, "O'qildi", readPi)
                .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MARK_AS_READ)
                .setShowsUserInterface(false)
                .build()
        )

        try {
            NotificationManagerCompat.from(ctx).notify(id, builder.build())
            postSummary(ctx)
        } catch (_: SecurityException) {
        }
    }

    fun showFailed(ctx: Context, threadId: Long) {
        if (!canNotify(ctx)) return
        val id = notificationId(threadId) + 7
        val n = NotificationCompat.Builder(ctx, CHANNEL_OTHER)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFFFF3B30.toInt())
            .setContentTitle("Xabar yuborilmadi")
            .setContentText("Qayta yuborish uchun bosing, keyin qizil ! belgisini bosing")
            .setContentIntent(openIntent(ctx, threadId, id))
            .setCategory(NotificationCompat.CATEGORY_ERROR)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    fun showMmsInfo(ctx: Context) {
        if (!canNotify(ctx)) return
        val n = NotificationCompat.Builder(ctx, CHANNEL_OTHER)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF34C759.toInt())
            .setContentTitle("MMS xabar keldi")
            .setContentText("MROS SMS hozircha MMS yuklab olmaydi")
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(424242, n)
        } catch (_: SecurityException) {
        }
    }

    /** Yangi versiya chiqqanda (fon tekshiruvi topsa). */
    fun showUpdate(ctx: Context, version: String) {
        if (!canNotify(ctx)) return
        val n = NotificationCompat.Builder(ctx, CHANNEL_UPDATES)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF34C759.toInt())
            .setContentTitle("MROS SMS $version tayyor")
            .setContentText("O'rnatish: Sozlamalar → Yangilanishlar")
            .setContentIntent(launchIntent(ctx, UPDATE_ID))
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(UPDATE_ID, n)
        } catch (_: SecurityException) {
        }
    }

    fun cancel(ctx: Context, threadId: Long) {
        if (threadId <= 0) return
        val id = notificationId(threadId)
        try {
            NotificationManagerCompat.from(ctx).cancel(id)
            // oxirgi suhbat bildirishnomasi ketsa — guruh sarlavhasi ham ketadi
            val nm = ctx.getSystemService(NotificationManager::class.java)
            val left = nm?.activeNotifications?.count {
                it.id != id && it.id != SUMMARY_ID && it.notification.group == GROUP
            } ?: 0
            if (left == 0) NotificationManagerCompat.from(ctx).cancel(SUMMARY_ID)
        } catch (_: Exception) {
        }
    }

    fun openChannelSettings(ctx: Context) {
        try {
            ctx.startActivity(
                Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    .putExtra(Settings.EXTRA_CHANNEL_ID, CHANNEL_MESSAGES)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (_: Exception) {
            }
        }
    }
}
