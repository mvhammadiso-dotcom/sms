package uz.mros.messages.sms

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.Person
import androidx.core.app.RemoteInput
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.IconCompat
import uz.mros.messages.MainActivity
import uz.mros.messages.R
import uz.mros.messages.data.Contacts
import uz.mros.messages.data.SmsRepo
import uz.mros.messages.util.Fmt

object Notifier {
    const val CHANNEL_MESSAGES = "messages"
    const val CHANNEL_OTHER = "other"
    const val ACTION_REPLY = "uz.mros.messages.action.REPLY"
    const val ACTION_MARK_READ = "uz.mros.messages.action.MARK_READ"
    const val ACTION_COPY_CODE = "uz.mros.messages.action.COPY_CODE"
    const val KEY_REPLY = "reply_text"
    const val EXTRA_THREAD = "thread_id"
    const val EXTRA_ADDRESS = "address"
    const val EXTRA_CODE = "code"

    /** Ilova ekranda va shu suhbat ochiq bo'lsa bildirishnoma chiqmaydi. */
    @Volatile
    var appVisible = false

    @Volatile
    var openThreadId = -1L

    private val mutableFlag: Int = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
    private const val IMMUTABLE = PendingIntent.FLAG_IMMUTABLE
    private const val UPDATE = PendingIntent.FLAG_UPDATE_CURRENT

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        val messages = NotificationChannel(CHANNEL_MESSAGES, "Xabarlar", NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Yangi SMS xabarlar"
            enableVibration(true)
            setShowBadge(true)
        }
        val other = NotificationChannel(CHANNEL_OTHER, "Boshqa", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Yuborilmagan xabarlar va MMS"
        }
        nm.createNotificationChannel(messages)
        nm.createNotificationChannel(other)
    }

    fun notificationId(threadId: Long, address: String = ""): Int =
        if (threadId > 0) (threadId % 1_000_000_000L).toInt() + 1 else (address.hashCode() and 0x7fffffff)

    private fun canNotify(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(ctx).areNotificationsEnabled()
    }

    private fun loadBitmap(ctx: Context, uri: String?): Bitmap? {
        if (uri == null) return null
        return try {
            ctx.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) {
            null
        }
    }

    private fun openIntent(ctx: Context, threadId: Long, requestCode: Int): PendingIntent {
        val open = Intent(ctx, MainActivity::class.java)
            .setAction(MainActivity.ACTION_OPEN_THREAD)
            .putExtra(EXTRA_THREAD, threadId)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, requestCode, open, UPDATE or IMMUTABLE)
    }

    fun showIncoming(ctx: Context, threadId: Long, address: String, body: String) {
        if (appVisible && threadId > 0 && openThreadId == threadId) return
        if (!canNotify(ctx)) return

        val info = Contacts.lookup(ctx, address)
        val name = info.name ?: Fmt.prettyPhone(address)
        val senderBuilder = Person.Builder().setName(name).setKey(address)
        loadBitmap(ctx, info.photoUri)?.let { senderBuilder.setIcon(IconCompat.createWithBitmap(it)) }
        val sender = senderBuilder.build()
        val me = Person.Builder().setName("Siz").build()

        val style = NotificationCompat.MessagingStyle(me)
        val unread = if (threadId > 0) SmsRepo.recentUnread(ctx, threadId, 6) else emptyList()
        if (unread.isEmpty()) {
            style.addMessage(body, System.currentTimeMillis(), sender)
        } else {
            unread.forEach { style.addMessage(it.first, it.second, sender) }
        }

        val id = notificationId(threadId, address)

        val replyIntent = Intent(ctx, NotificationActionReceiver::class.java)
            .setAction(ACTION_REPLY)
            .putExtra(EXTRA_THREAD, threadId)
            .putExtra(EXTRA_ADDRESS, address)
        val replyPi = PendingIntent.getBroadcast(ctx, id, replyIntent, UPDATE or mutableFlag)
        val remoteInput = RemoteInput.Builder(KEY_REPLY).setLabel("Javob yozing…").build()
        val replyAction = NotificationCompat.Action.Builder(R.drawable.ic_notification, "Javob", replyPi)
            .addRemoteInput(remoteInput)
            .setAllowGeneratedReplies(true)
            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
            .setShowsUserInterface(false)
            .build()

        val readIntent = Intent(ctx, NotificationActionReceiver::class.java)
            .setAction(ACTION_MARK_READ)
            .putExtra(EXTRA_THREAD, threadId)
        val readPi = PendingIntent.getBroadcast(ctx, id, readIntent, UPDATE or IMMUTABLE)
        val readAction = NotificationCompat.Action.Builder(R.drawable.ic_notification, "O'qildi", readPi)
            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MARK_AS_READ)
            .setShowsUserInterface(false)
            .build()

        val builder = NotificationCompat.Builder(ctx, CHANNEL_MESSAGES)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF34C759.toInt())
            .setStyle(style)
            .setContentTitle(name)
            .setContentText(body)
            .setContentIntent(openIntent(ctx, threadId, id))
            .setAutoCancel(true)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(replyAction)
            .addAction(readAction)

        val code = Fmt.extractCode(body)
        if (code != null) {
            val copyIntent = Intent(ctx, NotificationActionReceiver::class.java)
                .setAction(ACTION_COPY_CODE)
                .putExtra(EXTRA_CODE, code)
                .putExtra(EXTRA_THREAD, threadId)
            val copyPi = PendingIntent.getBroadcast(ctx, id, copyIntent, UPDATE or IMMUTABLE)
            builder.addAction(NotificationCompat.Action.Builder(R.drawable.ic_notification, "Nusxalash: $code", copyPi).build())
        }

        try {
            NotificationManagerCompat.from(ctx).notify(id, builder.build())
        } catch (_: SecurityException) {
        }
    }

    fun showFailed(ctx: Context, threadId: Long) {
        if (!canNotify(ctx)) return
        val id = notificationId(threadId) + 7
        val n = NotificationCompat.Builder(ctx, CHANNEL_OTHER)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFFFF3B30.toInt())
            .setContentTitle("Xabar yuborilmadi")
            .setContentText("Qayta yuborish uchun suhbatni oching")
            .setContentIntent(openIntent(ctx, threadId, id))
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    fun showMmsInfo(ctx: Context) {
        if (!canNotify(ctx)) return
        val n = NotificationCompat.Builder(ctx, CHANNEL_OTHER)
            .setSmallIcon(R.drawable.ic_notification)
            .setColor(0xFF34C759.toInt())
            .setContentTitle("MMS xabar keldi")
            .setContentText("MROS Xabarlar hozircha MMS yuklab olmaydi")
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(424242, n)
        } catch (_: SecurityException) {
        }
    }

    fun cancel(ctx: Context, threadId: Long) {
        if (threadId <= 0) return
        try {
            NotificationManagerCompat.from(ctx).cancel(notificationId(threadId))
        } catch (_: Exception) {
        }
    }
}
