package uz.mros.messages.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.mros.messages.data.Contacts
import uz.mros.messages.data.ConversationUi
import uz.mros.messages.data.PhoneContact
import uz.mros.messages.data.Sim
import uz.mros.messages.data.SmsRepo
import uz.mros.messages.ui.nav.Screen
import uz.mros.messages.util.Fmt

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Application get() = getApplication()

    /** Navigatsiya steki (oxirgisi — ekrandagi). */
    val stack = mutableStateListOf<Screen>(Screen.Conversations)

    var conversations by mutableStateOf<List<ConversationUi>>(emptyList())
        private set
    var loaded by mutableStateOf(false)
        private set
    var canRead by mutableStateOf(false)
        private set
    var isDefault by mutableStateOf(false)
        private set
    var sims by mutableStateOf<List<Sim>>(emptyList())
        private set
    var contacts by mutableStateOf<List<PhoneContact>>(emptyList())
        private set

    /** "Yangi nima bor" oynasi */
    var whatsNewVisible by mutableStateOf(false)

    init {
        viewModelScope.launch {
            SmsRepo.version.collectLatest {
                delay(120)
                reloadNow()
            }
        }
    }

    fun refreshPermissions() {
        canRead = SmsRepo.canRead(ctx)
        isDefault = SmsRepo.isDefault(ctx)
        sims = SmsRepo.sims(ctx)
        if (canRead) SmsRepo.startObserving(ctx)
        Contacts.clearCache()
        SmsRepo.notifyChanged()
    }

    private suspend fun reloadNow() {
        if (!SmsRepo.canRead(ctx)) {
            conversations = emptyList()
            loaded = true
            return
        }
        val list = withContext(Dispatchers.IO) {
            SmsRepo.loadConversations(ctx).map { c ->
                val infos = c.addresses.map { Contacts.lookup(ctx, it) }
                val names = c.addresses.mapIndexed { i, a -> infos[i].name ?: Fmt.prettyPhone(a) }
                val title = if (names.isEmpty()) "Noma'lum" else names.joinToString(", ")
                ConversationUi(
                    conv = c,
                    title = title,
                    photoUri = if (infos.size == 1) infos[0].photoUri else null,
                    contactName = if (infos.size == 1) infos[0].name else null,
                )
            }
        }
        conversations = list
        loaded = true
    }

    fun loadContacts() {
        viewModelScope.launch {
            contacts = withContext(Dispatchers.IO) { Contacts.all(ctx) }
        }
    }

    // ---------------------------------------------------------------- navigatsiya

    fun push(s: Screen) {
        if (stack.lastOrNull()?.key == s.key) return
        stack.add(s)
    }

    fun popNow() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    fun replaceTop(s: Screen) {
        stack[stack.lastIndex] = s
    }

    private fun resetTo(s: Screen) {
        while (stack.size > 1) stack.removeAt(stack.lastIndex)
        if (s != Screen.Conversations) stack.add(s)
    }

    fun openThread(threadId: Long) {
        viewModelScope.launch {
            val addrs = withContext(Dispatchers.IO) { SmsRepo.threadAddresses(ctx, threadId) }
            resetTo(Screen.Chat(threadId, addrs))
        }
    }

    fun openAddresses(addresses: List<String>, body: String?) {
        viewModelScope.launch {
            val t = withContext(Dispatchers.IO) { SmsRepo.threadIdFor(ctx, addresses) }
            resetTo(Screen.Chat(t, addresses, body ?: ""))
        }
    }

    fun openNewMessage(body: String?) {
        resetTo(Screen.NewMessage(body ?: ""))
    }
}
