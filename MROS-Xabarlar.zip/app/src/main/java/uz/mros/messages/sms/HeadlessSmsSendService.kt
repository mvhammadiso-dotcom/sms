package uz.mros.messages.sms

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.telephony.TelephonyManager
import uz.mros.messages.util.Fmt
import kotlin.concurrent.thread

/** Qo'ng'iroq ekranidagi "SMS bilan javob berish" uchun. */
class HeadlessSmsSendService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null && intent.action == TelephonyManager.ACTION_RESPOND_VIA_MESSAGE) {
            val text = intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                ?: intent.getStringExtra(Intent.EXTRA_TEXT)
            val recipients = Fmt.addressesFromUri(intent.data)
            if (!text.isNullOrBlank() && recipients.isNotEmpty()) {
                val app = applicationContext
                thread {
                    try {
                        val sub = SmsSender.effectiveSubId(app)
                        recipients.forEach { SmsSender.send(app, it, text, sub, -1L) }
                    } finally {
                        stopSelf(startId)
                    }
                }
                return START_NOT_STICKY
            }
        }
        stopSelf(startId)
        return START_NOT_STICKY
    }
}
