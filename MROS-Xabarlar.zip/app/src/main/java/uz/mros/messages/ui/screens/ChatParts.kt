package uz.mros.messages.ui.screens

import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.mros.messages.data.Message
import uz.mros.messages.data.Photos
import uz.mros.messages.ui.components.GlassMenuPanel
import uz.mros.messages.ui.components.IosIcons
import uz.mros.messages.ui.components.MenuItem
import uz.mros.messages.ui.glass.Backdrop
import uz.mros.messages.ui.glass.Glass
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos
import uz.mros.messages.util.Fmt
import kotlin.math.min
import kotlin.math.roundToInt

val TailWidth: Dp = 7.dp

/** iMessage pufagi: yumaloq to'rtburchak + pastki burchakda "dum". */
class BubbleShape(private val outgoing: Boolean, private val tail: Boolean) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val tw = with(density) { TailWidth.toPx() }
        val one = with(density) { 1.dp.toPx() }
        val w = size.width
        val h = size.height
        val r = min(with(density) { 18.dp.toPx() }, h / 2f)
        val bodyL = if (outgoing) 0f else tw
        val bodyR = if (outgoing) w - tw else w
        val body = Path()
        body.addRoundRect(RoundRect(bodyL, 0f, bodyR, h, CornerRadius(r, r)))
        if (!tail || w <= tw * 2 || h <= 2f) return Outline.Generic(body)

        // "chiquvchi" koordinatalarda chizamiz, kiruvchi uchun ko'zguda aks ettiramiz
        val rt = w - tw
        fun mx(x: Float): Float = if (outgoing) x else w - x
        val t = Path()
        t.moveTo(mx(rt), h - r)
        t.cubicTo(mx(rt), h - r * 0.3f, mx(rt + tw * 0.25f), h - one * 0.8f, mx(w), h)
        t.cubicTo(mx(w - tw * 1.1f), h - one * 0.2f, mx(rt - r * 0.25f), h - one * 2.5f, mx(rt - r * 0.85f), h)
        t.lineTo(mx(rt - r * 0.85f), h - r)
        t.close()

        val result = Path()
        result.op(body, t, PathOperation.Union)
        return Outline.Generic(result)
    }
}

sealed class ChatItem {
    abstract val key: String
    abstract val type: Int

    data class Msg(val msg: Message, val tail: Boolean, val topGap: Dp) : ChatItem() {
        override val key: String get() = msg.key
        override val type: Int get() = 0
    }

    data class Header(val date: Long, val forKey: String) : ChatItem() {
        override val key: String get() = "h$forKey"
        override val type: Int get() = 1
    }

    data class Status(val text: String, val error: Boolean, val sending: Boolean, val forKey: String) : ChatItem() {
        override val key: String get() = "st$forKey"
        override val type: Int get() = 2
    }

    data class Sender(val name: String, val forKey: String) : ChatItem() {
        override val key: String get() = "sn$forKey"
        override val type: Int get() = 3
    }
}

/**
 * [msgs] — eng yangisi birinchi. Natija reverseLayout LazyColumn uchun
 * (0-element — ekranning eng pastida).
 */
fun buildChatItems(msgs: List<Message>, isGroup: Boolean, nameOf: (String) -> String): List<ChatItem> {
    val out = ArrayList<ChatItem>(msgs.size + 16)
    val latestOut = msgs.indexOfFirst { it.outgoing }
    val hour = 60L * 60L * 1000L
    for (i in msgs.indices) {
        val m = msgs[i]
        val newer = if (i > 0) msgs[i - 1] else null
        val older = if (i + 1 < msgs.size) msgs[i + 1] else null
        val headerAbove = older == null || m.date - older.date > hour
        val newerHasHeader = newer != null && newer.date - m.date > hour
        val sameAsNewer = newer != null && newer.outgoing == m.outgoing &&
            (m.outgoing || !isGroup || newer.address == m.address)
        val tail = !sameAsNewer || newerHasHeader
        val sameAsOlder = older != null && !headerAbove && older.outgoing == m.outgoing &&
            (m.outgoing || !isGroup || older.address == m.address)

        if (m.outgoing) {
            if (m.failed) {
                out.add(ChatItem.Status("Yuborilmadi", error = true, sending = false, forKey = m.key))
            } else if (i == latestOut) {
                val text = when {
                    m.pending -> "Yuborilmoqda…"
                    m.delivered -> "Yetkazildi"
                    else -> "Yuborildi"
                }
                out.add(ChatItem.Status(text, error = false, sending = m.pending, forKey = m.key))
            }
        }
        out.add(ChatItem.Msg(m, tail, if (sameAsOlder) 2.dp else 10.dp))
        if (isGroup && !m.outgoing && !sameAsOlder) out.add(ChatItem.Sender(nameOf(m.address), m.key))
        if (headerAbove) out.add(ChatItem.Header(m.date, m.key))
    }
    return out
}

private class BubbleCoords {
    var outer: LayoutCoordinates? = null
    var text: LayoutCoordinates? = null
}

/** Chiquvchi pufak rangi ekrandagi o'rniga qarab o'zgaradi (iOS kabi). */
@Composable
fun BubbleSurface(shape: Shape, out: Boolean, green: Boolean, content: @Composable BoxScope.() -> Unit) {
    val ios = LocalIos.current
    val density = LocalDensity.current
    val conf = LocalConfiguration.current
    val screenH = with(density) { conf.screenHeightDp.dp.toPx() }
    val colors = if (green) {
        listOf(Color(0xFF5FE07A), Color(0xFF28B84A))
    } else {
        listOf(Color(0xFF45ABFF), Color(0xFF0A6CF0))
    }
    val received = ios.received
    var y by remember { mutableFloatStateOf(0f) }
    Box(
        Modifier
            .then(if (out) Modifier.onGloballyPositioned { y = it.positionInRoot().y } else Modifier)
            .drawWithCache {
                val outline = shape.createOutline(size, layoutDirection, this)
                onDrawBehind {
                    if (out) {
                        drawOutline(outline, Brush.verticalGradient(colors, startY = -y, endY = screenH - y))
                    } else {
                        drawOutline(outline, received)
                    }
                }
            }
            .padding(
                start = if (out) 12.dp else 12.dp + TailWidth,
                end = if (out) 12.dp + TailWidth else 12.dp,
                top = 7.dp,
                bottom = 7.dp,
            ),
        content = content,
    )
}

@Composable
private fun MmsImage(uri: Uri) {
    val ctx = LocalContext.current
    val ios = LocalIos.current
    val bmp by produceState<ImageBitmap?>(null, uri) {
        value = Photos.load(ctx, uri.toString(), 900)
    }
    val b = bmp
    if (b != null) {
        Image(
            bitmap = b,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .widthIn(max = 240.dp)
                .aspectRatio((b.width.toFloat() / b.height.coerceAtLeast(1)).coerceIn(0.5f, 2f))
                .clip(RoundedCornerShape(18.dp)),
        )
    } else {
        Box(
            Modifier
                .size(width = 200.dp, height = 150.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(ios.fill)
        )
    }
}

@Composable
fun BubbleContent(
    item: ChatItem.Msg,
    green: Boolean,
    reaction: String?,
    maxWidth: Dp,
    interactive: Boolean,
    onMenu: (ChatItem.Msg, Rect) -> Unit,
) {
    val ios = LocalIos.current
    val m = item.msg
    val out = m.outgoing
    val uriHandler = LocalUriHandler.current
    val haptic = LocalHapticFeedback.current
    val coords = remember { BubbleCoords() }
    var layout by remember { mutableStateOf<TextLayoutResult?>(null) }
    val emojiN = remember(m.body, m.images) { if (m.images.isEmpty()) Fmt.emojiCount(m.body) else 0 }
    val big = emojiN in 1..3
    val textColor = if (out) Color.White else ios.receivedText
    val linkColor = if (out) Color.White else ios.blue
    val annotated = remember(m.body, linkColor) { Fmt.linkify(m.body, linkColor, underline = true) }
    val shape = remember(out, item.tail) { BubbleShape(out, item.tail) }

    val gestures = if (interactive) {
        Modifier.pointerInput(m.key) {
            detectTapGestures(
                onLongPress = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    val c = coords.outer
                    if (c != null && c.isAttached) onMenu(item, c.boundsInRoot())
                },
                onDoubleTap = {
                    val c = coords.outer
                    if (c != null && c.isAttached) onMenu(item, c.boundsInRoot())
                },
                onTap = tap@{ pos ->
                    val l = layout ?: return@tap
                    val o = coords.outer ?: return@tap
                    val t = coords.text ?: return@tap
                    if (!o.isAttached || !t.isAttached) return@tap
                    val local = t.localPositionOf(o, pos)
                    if (local.x < 0f || local.y < 0f || local.x > l.size.width || local.y > l.size.height) return@tap
                    val off = l.getOffsetForPosition(local)
                    val link = annotated.getStringAnnotations(Fmt.LINK_TAG, off, off).firstOrNull() ?: return@tap
                    try {
                        uriHandler.openUri(link.item)
                    } catch (_: Exception) {
                    }
                },
            )
        }
    } else {
        Modifier
    }

    Box(
        Modifier
            .widthIn(max = maxWidth)
            .onGloballyPositioned { coords.outer = it }
            .then(gestures)
    ) {
        Column(horizontalAlignment = if (out) Alignment.End else Alignment.Start) {
            m.images.forEach { uri ->
                MmsImage(uri)
                Spacer(Modifier.height(3.dp))
            }
            if (m.body.isNotEmpty()) {
                if (big) {
                    Text(
                        text = m.body,
                        fontSize = 46.sp,
                        lineHeight = 54.sp,
                        onTextLayout = { layout = it },
                        modifier = Modifier
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                            .onGloballyPositioned { coords.text = it },
                    )
                } else {
                    BubbleSurface(shape, out, green) {
                        Text(
                            text = annotated,
                            style = IosType.body,
                            color = textColor,
                            onTextLayout = { layout = it },
                            modifier = Modifier.onGloballyPositioned { coords.text = it },
                        )
                    }
                }
            } else if (m.images.isEmpty()) {
                BubbleSurface(shape, out, green) {
                    Text(
                        text = if (m.isMms) "MMS xabar" else "(bo'sh xabar)",
                        style = IosType.body.copy(fontStyle = FontStyle.Italic),
                        color = textColor.copy(alpha = 0.75f),
                    )
                }
            }
        }
        if (reaction != null) {
            Box(
                Modifier
                    .align(if (out) Alignment.TopStart else Alignment.TopEnd)
                    .offset(x = if (out) (-12).dp else 12.dp, y = (-15).dp)
                    .size(30.dp)
                    .shadow(3.dp, CircleShape)
                    .background(if (out) ios.received else ios.blue, CircleShape),
                contentAlignment = Alignment.Center,
            ) {
                Text(reaction, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun FailedBadge(onClick: () -> Unit) {
    val ios = LocalIos.current
    Box(
        Modifier
            .size(24.dp)
            .background(ios.red, CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text("!", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
fun MessageRow(
    item: ChatItem.Msg,
    green: Boolean,
    reaction: String?,
    maxBubbleWidth: Dp,
    reveal: () -> Float,
    revealMax: Float,
    onMenu: (ChatItem.Msg, Rect) -> Unit,
    onRetry: (Message) -> Unit,
) {
    val ios = LocalIos.current
    val m = item.msg
    val out = m.outgoing
    Box(
        Modifier
            .fillMaxWidth()
            .padding(top = item.topGap + (if (reaction != null) 12.dp else 0.dp))
    ) {
        Text(
            text = Fmt.time(m.date),
            style = IosType.caption,
            color = ios.secondary,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 14.dp)
                .graphicsLayer {
                    val r = reveal()
                    alpha = (r / revealMax).coerceIn(0f, 1f)
                    translationX = (revealMax - r) * 0.5f
                },
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = if (out) 48.dp else 8.dp, end = if (out) 8.dp else 48.dp)
                .graphicsLayer {
                    if (out) translationX = -reveal()
                },
            horizontalArrangement = if (out) Arrangement.End else Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (out && m.failed) {
                FailedBadge { onRetry(m) }
                Spacer(Modifier.width(8.dp))
            }
            BubbleContent(item, green, reaction, maxBubbleWidth, interactive = true, onMenu = onMenu)
        }
    }
}

@Composable
fun TimeHeader(ms: Long) {
    val ios = LocalIos.current
    val text = remember(ms) {
        buildAnnotatedString {
            withStyle(SpanStyle(fontWeight = FontWeight.SemiBold)) { append(Fmt.dayLabel(ms)) }
            append(" ")
            append(Fmt.time(ms))
        }
    }
    Text(
        text = text,
        style = IosType.caption,
        color = ios.secondary,
        textAlign = TextAlign.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 16.dp, bottom = 4.dp),
    )
}

@Composable
fun SenderRow(name: String) {
    val ios = LocalIos.current
    Text(
        text = name,
        style = IosType.caption,
        color = ios.secondary,
        modifier = Modifier.padding(start = 24.dp, top = 8.dp, bottom = 1.dp),
    )
}

@Composable
private fun SendingBar(color: Color) {
    val ios = LocalIos.current
    val transition = rememberInfiniteTransition(label = "sending")
    val p by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "p",
    )
    Box(
        Modifier
            .padding(bottom = 3.dp)
            .width(72.dp)
            .height(3.dp)
            .clip(RoundedCornerShape(50))
            .background(ios.fill)
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.12f + 0.88f * p)
                .clip(RoundedCornerShape(50))
                .background(color)
        )
    }
}

@Composable
fun StatusRow(item: ChatItem.Status, sendColor: Color, reveal: () -> Float) {
    val ios = LocalIos.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(end = 18.dp, top = 3.dp)
            .graphicsLayer { translationX = -reveal() },
        horizontalAlignment = Alignment.End,
    ) {
        if (item.sending) SendingBar(sendColor)
        Text(
            text = item.text,
            style = IosType.caption2.copy(fontWeight = FontWeight.Medium),
            color = if (item.error) ios.red else ios.secondary,
        )
    }
}

// ---------------------------------------------------------------- tapback + menyu

data class BubbleMenu(val item: ChatItem.Msg, val anchor: Rect)

private val Tapbacks = listOf("❤️", "👍", "👎", "😂", "‼️", "❓")

@Composable
private fun TapbackBar(selected: String?, backdrop: Backdrop?, modifier: Modifier, onPick: (String) -> Unit) {
    val ios = LocalIos.current
    Glass(
        backdrop = backdrop,
        shape = RoundedCornerShape(50),
        modifier = modifier.height(50.dp),
        tint = ios.menuTint,
        blur = 22.dp,
        shadow = 14.dp,
    ) {
        Row(
            Modifier
                .align(Alignment.Center)
                .padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Tapbacks.forEach { e ->
                val sel = e == selected
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(if (sel) ios.blue else Color.Transparent)
                        .clickable { onPick(e) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(e, fontSize = 21.sp)
                }
            }
        }
    }
}

@Composable
fun BubbleMenuOverlay(
    state: BubbleMenu?,
    backdrop: Backdrop?,
    green: Boolean,
    reactions: Map<String, String>,
    maxBubbleWidth: Dp,
    canDelete: Boolean,
    onReact: (Message, String) -> Unit,
    onCopy: (String) -> Unit,
    onRetry: (Message) -> Unit,
    onDelete: (Message) -> Unit,
    onDismiss: () -> Unit,
) {
    val ios = LocalIos.current
    val holder = remember { arrayOfNulls<BubbleMenu>(1) }
    if (state != null) holder[0] = state
    val progress by animateFloatAsState(
        targetValue = if (state != null) 1f else 0f,
        animationSpec = tween(if (state != null) 240 else 160),
        label = "bubbleMenu",
    )
    val s = holder[0] ?: return
    if (state == null && progress <= 0.01f) return

    val m = s.item.msg
    val out = m.outgoing
    val code = remember(m.body) { Fmt.extractCode(m.body) }
    val items = buildList<MenuItem> {
        if (m.body.isNotEmpty()) add(MenuItem("Nusxa olish", IosIcons.Copy) { onCopy(m.body) })
        if (code != null) add(MenuItem("Kodni nusxalash · $code", IosIcons.Copy) { onCopy(code) })
        if (m.failed) add(MenuItem("Qayta yuborish", IosIcons.Retry) { onRetry(m) })
        if (canDelete) add(MenuItem("O'chirish", IosIcons.Trash, destructive = true) { onDelete(m) })
    }

    val density = LocalDensity.current
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    var origin by remember { mutableStateOf(Offset.Zero) }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { origin = it.positionInRoot() }
    ) {
        val maxH = constraints.maxHeight.toFloat()
        Glass(
            backdrop = backdrop,
            shape = RectangleShape,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = progress },
            tint = ios.bg.copy(alpha = if (ios.dark) 0.5f else 0.4f),
            blur = 20.dp,
            lens = 0f,
            shadow = 0.dp,
            rim = false,
        )
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) { detectTapGestures { onDismiss() } }
        )

        val a = s.anchor.translate(-origin.x, -origin.y)
        val tapH = with(density) { 50.dp.toPx() }
        val gap = with(density) { 10.dp.toPx() }
        val menuH = with(density) { 48.dp.toPx() } * items.size
        val topSafe = with(density) { (topInset + 8.dp).toPx() }
        val bottomSafe = with(density) { (bottomInset + 8.dp).toPx() }
        val total = tapH + gap + a.height + gap + menuH
        val maxY = maxH - bottomSafe - total
        val wanted = a.top - tapH - gap
        val y0 = if (maxY < topSafe) topSafe else wanted.coerceIn(topSafe, maxY)

        Column(
            Modifier
                .fillMaxWidth()
                .offset { IntOffset(0, y0.roundToInt()) }
                .padding(start = if (out) 48.dp else 8.dp, end = if (out) 8.dp else 48.dp)
                .graphicsLayer { alpha = progress },
            horizontalAlignment = if (out) Alignment.End else Alignment.Start,
        ) {
            TapbackBar(
                selected = reactions[m.key],
                backdrop = backdrop,
                modifier = Modifier.graphicsLayer {
                    val sc = 0.6f + 0.4f * progress
                    scaleX = sc
                    scaleY = sc
                    transformOrigin = TransformOrigin(if (out) 1f else 0f, 1f)
                },
            ) { e ->
                onReact(m, e)
                onDismiss()
            }
            Spacer(Modifier.height(10.dp))
            Box(Modifier.heightIn(max = 420.dp)) {
                BubbleContent(s.item, green, reactions[m.key], maxBubbleWidth, interactive = false, onMenu = { _, _ -> })
            }
            Spacer(Modifier.height(10.dp))
            if (items.isNotEmpty()) {
                GlassMenuPanel(
                    items = items,
                    backdrop = backdrop,
                    modifier = Modifier
                        .width(250.dp)
                        .graphicsLayer {
                            val sc = 0.8f + 0.2f * progress
                            scaleX = sc
                            scaleY = sc
                            transformOrigin = TransformOrigin(if (out) 1f else 0f, 0f)
                        },
                ) { item ->
                    onDismiss()
                    item.onClick()
                }
            }
        }
    }
}
