package uz.mros.messages.ui.nav

import androidx.activity.compose.PredictiveBackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import uz.mros.messages.ui.AppViewModel
import uz.mros.messages.ui.components.blockTouches
import uz.mros.messages.ui.screens.ChatScreen
import uz.mros.messages.ui.screens.ConversationsScreen
import uz.mros.messages.ui.screens.NewMessageScreen
import uz.mros.messages.ui.screens.SettingsScreen
import uz.mros.messages.ui.theme.LocalIos
import kotlin.coroutines.cancellation.CancellationException

sealed class Screen {
    abstract val key: String
    open val modal: Boolean get() = false

    data object Conversations : Screen() {
        override val key: String get() = "list"
    }

    data class Chat(val threadId: Long, val addresses: List<String>, val draft: String = "") : Screen() {
        override val key: String get() = "chat-$threadId-" + addresses.joinToString(",")
    }

    data class NewMessage(val draft: String = "") : Screen() {
        override val key: String get() = "new"
        override val modal: Boolean get() = true
    }

    data object Settings : Screen() {
        override val key: String get() = "settings"
    }
}

/** Chap tomonga surish (chatda vaqtni ko'rsatish) uchun. */
interface LeftDragHandler {
    fun drag(dx: Float)
    fun end()
}

/** iOS uslubidagi push/pop animatsiyasi va orqaga surish. */
@Stable
class Nav(private val vm: AppViewModel, private val scope: CoroutineScope) {
    val anim = Animatable(0f)
    private var dragging by mutableStateOf(false)
    private var dragValue by mutableFloatStateOf(0f)
    private var busy = false
    var width: Float = 1f
    var leftHandler: LeftDragHandler? = null

    val canPop: Boolean get() = vm.stack.size > 1

    /** 0 = yuqori ekran to'liq ko'rinadi, 1 = to'liq yopilgan. */
    val fraction: Float get() = if (dragging) dragValue else anim.value

    fun push(s: Screen) = vm.push(s)

    fun replace(s: Screen) = vm.replaceTop(s)

    fun pop() {
        if (!canPop || busy || dragging) return
        busy = true
        scope.launch {
            anim.animateTo(1f, tween(320, easing = FastOutSlowInEasing))
            finishPop()
        }
    }

    private suspend fun finishPop() {
        vm.popNow()
        anim.snapTo(0f)
        busy = false
    }

    fun dragStart(): Boolean {
        if (!canPop || busy) return false
        dragValue = anim.value
        dragging = true
        return true
    }

    fun setDrag(v: Float) {
        if (dragging) dragValue = v.coerceIn(0f, 1f)
    }

    fun dragBy(dx: Float) {
        if (dragging) dragValue = (dragValue + dx / width).coerceIn(0f, 1f)
    }

    fun dragEnd(velocity: Float) {
        if (!dragging) return
        val start = dragValue
        busy = true
        scope.launch {
            anim.snapTo(start)
            dragging = false
            if (start > 0.35f || velocity > 900f) {
                val ms = ((1f - start) * 320f).toInt().coerceAtLeast(120)
                anim.animateTo(1f, tween(ms, easing = LinearOutSlowInEasing))
                finishPop()
            } else {
                anim.animateTo(0f, spring(dampingRatio = 1f, stiffness = 500f))
                busy = false
            }
        }
    }

    fun cancelDrag() {
        if (!dragging) return
        val start = dragValue
        busy = true
        scope.launch {
            anim.snapTo(start)
            dragging = false
            anim.animateTo(0f, spring(dampingRatio = 1f, stiffness = 500f))
            busy = false
        }
    }
}

private fun Modifier.swipeBack(nav: Nav): Modifier = this.pointerInput(nav) {
    var mode = 0 // 0 = aniqlanmagan, 1 = orqaga, -1 = chapga (handler), 2 = e'tiborsiz
    var acc = 0f
    val tracker = VelocityTracker()
    detectHorizontalDragGestures(
        onDragStart = {
            mode = 0
            acc = 0f
            tracker.resetTracking()
        },
        onDragEnd = {
            val v = tracker.calculateVelocity().x
            when (mode) {
                1 -> nav.dragEnd(v)
                -1 -> nav.leftHandler?.end()
            }
            mode = 0
        },
        onDragCancel = {
            when (mode) {
                1 -> nav.cancelDrag()
                -1 -> nav.leftHandler?.end()
            }
            mode = 0
        },
        onHorizontalDrag = { change, dx ->
            if (mode == 0) {
                mode = when {
                    dx > 0f && nav.canPop && nav.dragStart() -> 1
                    dx < 0f && nav.leftHandler != null -> -1
                    else -> 2
                }
            }
            acc += dx
            tracker.addPosition(change.uptimeMillis, Offset(acc, 0f))
            when (mode) {
                1 -> {
                    change.consume()
                    nav.dragBy(dx)
                }
                -1 -> {
                    change.consume()
                    nav.leftHandler?.drag(dx)
                }
            }
        },
    )
}

@Composable
fun NavHostView(vm: AppViewModel, onRequestDefault: () -> Unit) {
    val ios = LocalIos.current
    val scope = rememberCoroutineScope()
    val nav = remember(vm, scope) { Nav(vm, scope) }
    val stack = vm.stack
    var animatedSize by remember { mutableIntStateOf(stack.size) }
    val needsEnter = stack.size > animatedSize

    LaunchedEffect(stack.size) {
        if (stack.size > animatedSize) {
            nav.anim.snapTo(1f)
            animatedSize = stack.size
            nav.anim.animateTo(0f, spring(dampingRatio = 1f, stiffness = 380f))
        } else {
            animatedSize = stack.size
        }
    }

    PredictiveBackHandler(enabled = stack.size > 1) { progress ->
        val started = nav.dragStart()
        try {
            progress.collect { e -> if (started) nav.setDrag(e.progress) }
            if (started) nav.dragEnd(100_000f) else nav.pop()
        } catch (e: CancellationException) {
            if (started) nav.cancelDrag()
            throw e
        }
    }

    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()
        nav.width = w
        val frac: () -> Float = { if (needsEnter) 1f else nav.fraction }
        val topIdx = stack.lastIndex
        val topModal = stack[topIdx].modal

        for (i in stack.indices) {
            val s = stack[i]
            key(s.key) {
                val role = when (i) {
                    topIdx -> 0
                    topIdx - 1 -> 1
                    else -> 2
                }
                val layer = when (role) {
                    0 -> Modifier
                        .fillMaxSize()
                        .then(if (!topModal) Modifier.swipeBack(nav) else Modifier)
                        .graphicsLayer {
                            val f = frac()
                            if (topModal) translationY = h * f else translationX = w * f
                        }
                        .drawBehind {
                            val f = frac()
                            if (!topModal && f > 0f && f < 1f) {
                                val sw = 36.dp.toPx()
                                drawRect(
                                    brush = Brush.horizontalGradient(
                                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.18f)),
                                        startX = -sw,
                                        endX = 0f,
                                    ),
                                    topLeft = Offset(-sw, 0f),
                                    size = Size(sw, size.height),
                                )
                            }
                        }

                    1 -> Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            val f = frac()
                            alpha = if (topModal || f > 0f) 1f else 0f
                            if (topModal) {
                                val sc = 0.93f + 0.07f * f
                                scaleX = sc
                                scaleY = sc
                                clip = true
                                shape = RoundedCornerShape(18.dp)
                            } else {
                                translationX = -0.3f * w * (1f - f)
                            }
                        }

                    else -> Modifier
                        .fillMaxSize()
                        .graphicsLayer { alpha = 0f }
                }

                Box(layer.blockTouches()) {
                    if (role == 0 && topModal) {
                        Box(
                            Modifier
                                .fillMaxSize()
                                .padding(top = statusTop + 10.dp)
                                .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp))
                                .background(ios.bg)
                        ) {
                            ScreenContent(s, vm, nav, true, onRequestDefault)
                        }
                    } else {
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(if (s == Screen.Settings) ios.groupedBg else ios.bg)
                        ) {
                            ScreenContent(s, vm, nav, role == 0, onRequestDefault)
                        }
                        if (role == 1) {
                            Box(
                                Modifier
                                    .fillMaxSize()
                                    .graphicsLayer { alpha = 1f - frac() }
                                    .background(Color.Black.copy(alpha = if (topModal) 0.32f else 0.12f))
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScreenContent(s: Screen, vm: AppViewModel, nav: Nav, isTop: Boolean, onRequestDefault: () -> Unit) {
    when (s) {
        Screen.Conversations -> ConversationsScreen(vm, nav, onRequestDefault)
        is Screen.Chat -> ChatScreen(s, vm, nav, isTop)
        is Screen.NewMessage -> NewMessageScreen(s, vm, nav)
        Screen.Settings -> SettingsScreen(vm, nav, onRequestDefault)
    }
}
