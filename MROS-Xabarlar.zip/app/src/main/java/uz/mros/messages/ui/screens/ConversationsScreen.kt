package uz.mros.messages.ui.screens

import uz.mros.messages.ui.components.LiquidButton
import androidx.compose.ui.composed
import androidx.compose.foundation.lazy.itemsIndexed
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.mros.messages.data.Contacts
import uz.mros.messages.data.ConversationUi
import uz.mros.messages.data.SearchHit
import uz.mros.messages.data.UpdateState
import uz.mros.messages.data.Updater
import uz.mros.messages.data.Prefs
import uz.mros.messages.data.SmsRepo
import uz.mros.messages.sms.Notifier
import uz.mros.messages.ui.AppViewModel
import uz.mros.messages.ui.components.AlertState
import uz.mros.messages.ui.components.Avatar
import uz.mros.messages.ui.components.GlassIconButton
import uz.mros.messages.ui.components.Hairline
import uz.mros.messages.ui.components.IosAlert
import uz.mros.messages.ui.components.IosIcons
import uz.mros.messages.ui.components.MenuItem
import uz.mros.messages.ui.components.MenuOverlay
import uz.mros.messages.ui.components.MenuState
import uz.mros.messages.ui.glass.Glass
import uz.mros.messages.ui.glass.backdropSource
import uz.mros.messages.ui.glass.rememberBackdrop
import uz.mros.messages.ui.nav.Nav
import uz.mros.messages.ui.nav.Screen
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos
import uz.mros.messages.util.Fmt
import kotlin.math.abs
import kotlin.math.roundToInt

private class SwipeAction(val title: String, val icon: ImageVector, val color: Color, val action: () -> Unit)

/** Qator pastdan suzib, shaffofdan paydo bo'ladi — [index] bo'yicha kechikish bilan. */
private fun Modifier.introIn(index: Int, enabled: Boolean): Modifier = composed {
    val a = remember { Animatable(if (enabled && index < 14) 0f else 1f) }
    LaunchedEffect(Unit) {
        if (a.value < 1f) {
            delay(60L + index * 38L)
            a.animateTo(1f, spring(dampingRatio = 0.7f, stiffness = 240f))
        }
    }
    this.graphicsLayer {
        val v = a.value
        alpha = v.coerceIn(0f, 1f)
        translationY = (1f - v) * 40.dp.toPx()
        val sc = 0.96f + 0.04f * v
        scaleX = sc
        scaleY = sc
    }
}

private data class HitUi(val hit: SearchHit, val name: String, val contactName: String?, val photo: String?)

private fun snippet(body: String, q: String, hi: Color): AnnotatedString {
    val text = body.replace('\n', ' ')
    val idx = if (q.isBlank()) -1 else text.indexOf(q.trim(), ignoreCase = true)
    val start = if (idx > 40) idx - 30 else 0
    val shown = (if (start > 0) "…" else "") + text.substring(start)
    val shift = if (start > 0) 1 - start else 0
    return buildAnnotatedString {
        append(shown)
        if (idx >= 0) {
            val s0 = (idx + shift).coerceIn(0, shown.length)
            val e0 = (s0 + q.trim().length).coerceAtMost(shown.length)
            if (e0 > s0) addStyle(SpanStyle(color = hi, fontWeight = FontWeight.SemiBold), s0, e0)
        }
    }
}

private val FilterTitles = listOf("Xabarlar", "Ma'lum", "Noma'lum", "O'qilmaganlar")

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ConversationsScreen(vm: AppViewModel, nav: Nav, onRequestDefault: () -> Unit) {
    val ios = LocalIos.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val focusManager = LocalFocusManager.current
    val backdrop = rememberBackdrop()
    val listState = rememberLazyListState()
    val pinnedIds by Prefs.pinned.collectAsState()
    val mutedIds by Prefs.muted.collectAsState()
    val upd by Updater.state.collectAsState()
    val hasUpdate = upd is UpdateState.Available || upd is UpdateState.Ready

    var query by rememberSaveable { mutableStateOf("") }
    // 0 = barcha, 1 = ma'lum, 2 = noma'lum, 3 = o'qilmagan
    var filter by rememberSaveable { mutableStateOf(0) }
    var menu by remember { mutableStateOf<MenuState?>(null) }
    var alert by remember { mutableStateOf<AlertState?>(null) }
    var openSwipe by remember { mutableStateOf<Long?>(null) }
    var filterRect by remember { mutableStateOf(Rect.Zero) }
    var hits by remember { mutableStateOf<List<HitUi>>(emptyList()) }
    val searchFocus = remember { FocusRequester() }
    // ilova ochilganda qatorlar ketma-ket suzib chiqadi (bir marta)
    var introPlayed by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(vm.loaded) {
        if (vm.loaded && !introPlayed) {
            delay(900)
            introPlayed = true
        }
    }
    val searchInteraction = remember { MutableInteractionSource() }
    val keyboard = LocalSoftwareKeyboardController.current

    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val imeBottom = WindowInsets.ime.asPaddingValues().calculateBottomPadding()
    val listBottom = if (imeBottom > navBottom) imeBottom else navBottom

    // xabarlar ichidan qidiruv (kechiktirib)
    LaunchedEffect(query) {
        val q = query.trim()
        if (q.length < 2) {
            hits = emptyList()
            return@LaunchedEffect
        }
        delay(260)
        hits = withContext(Dispatchers.IO) {
            SmsRepo.searchMessages(ctx, q, 40).map { h ->
                val info = Contacts.lookup(ctx, h.address)
                HitUi(h, info.name ?: Fmt.prettyPhone(h.address), info.name, info.photoUri)
            }
        }
    }

    val all = vm.conversations
    val filtered = remember(all, query, filter) {
        val q = query.trim()
        val qd = q.filter { it.isDigit() }
        all.filter { c ->
            val pass = when (filter) {
                1 -> c.contactName != null
                2 -> c.contactName == null
                3 -> c.conv.unread > 0
                else -> true
            }
            pass && (
                q.isEmpty() ||
                    c.title.contains(q, ignoreCase = true) ||
                    c.conv.snippet.contains(q, ignoreCase = true) ||
                    (qd.length >= 3 && c.conv.addresses.any { a -> a.filter { ch -> ch.isDigit() }.contains(qd) })
                )
        }
    }
    val showPinned = query.isBlank() && filter == 0
    val pinned = if (showPinned) filtered.filter { it.threadId in pinnedIds } else emptyList()
    val pinnedSet = pinned.map { it.threadId }.toSet()
    val rest = filtered.filter { it.threadId !in pinnedSet }
    val title = FilterTitles.getOrElse(filter) { "Xabarlar" }

    val collapsed by remember {
        derivedStateOf {
            listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > with(density) { 36.dp.toPx() }
        }
    }
    val smallTitleAlpha by animateFloatAsState(if (collapsed) 1f else 0f, label = "title")

    fun needDefault(): Boolean {
        // holatni har safar jonli tekshiramiz (eski qiymatga ishonmaymiz)
        val def = SmsRepo.isDefault(ctx)
        if (def != vm.isDefault) vm.refreshPermissions()
        if (def) return false
        Toast.makeText(ctx, "Buning uchun Xabarlar asosiy SMS ilova bo'lishi kerak", Toast.LENGTH_SHORT).show()
        onRequestDefault()
        return true
    }

    fun open(c: ConversationUi) {
        focusManager.clearFocus()
        nav.push(Screen.Chat(c.threadId, c.conv.addresses))
    }

    fun openHit(h: HitUi) {
        focusManager.clearFocus()
        val addrs = all.firstOrNull { it.threadId == h.hit.threadId }?.conv?.addresses ?: listOf(h.hit.address)
        nav.push(Screen.Chat(h.hit.threadId, addrs, focusKey = h.hit.key))
    }

    fun toggleRead(c: ConversationUi) {
        if (needDefault()) return
        scope.launch {
            withContext(Dispatchers.IO) {
                if (c.conv.unread > 0) {
                    SmsRepo.markThreadRead(ctx, c.threadId)
                    Notifier.cancel(ctx, c.threadId)
                } else {
                    SmsRepo.markThreadUnread(ctx, c.threadId)
                }
            }
            SmsRepo.notifyChanged()
        }
    }

    fun toggleMute(c: ConversationUi) {
        val wasMuted = Prefs.isMuted(c.threadId)
        Prefs.toggleMute(c.threadId)
        if (!wasMuted) Notifier.cancel(ctx, c.threadId)
        Toast.makeText(ctx, if (wasMuted) "Ogohlantirishlar yoqildi" else "Ovozsiz: bildirishnoma kelmaydi", Toast.LENGTH_SHORT).show()
    }

    fun askDelete(c: ConversationUi) {
        if (needDefault()) return
        alert = AlertState(
            title = "Suhbatni o'chirasizmi?",
            message = "${c.title} bilan barcha xabarlar o'chiriladi. Buni qaytarib bo'lmaydi.",
            confirm = "O'chirish",
        ) {
            scope.launch {
                val n = withContext(Dispatchers.IO) { SmsRepo.deleteThread(ctx, c.threadId) }
                if (n > 0) {
                    Prefs.unpin(c.threadId)
                    Notifier.cancel(ctx, c.threadId)
                } else {
                    val why = SmsRepo.lastError
                    Toast.makeText(ctx, "O'chirib bo'lmadi" + (if (why != null) ": $why" else ""), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun rowMenu(c: ConversationUi, rect: Rect) {
        val isPinned = c.threadId in pinnedIds
        val isMuted = c.threadId in mutedIds
        menu = MenuState(
            anchor = rect,
            title = c.title,
            items = listOf(
                MenuItem(if (isPinned) "Qadashni olib tashlash" else "Qadash", IosIcons.Pin) { Prefs.togglePin(c.threadId) },
                MenuItem(
                    if (c.conv.unread > 0) "O'qilgan deb belgilash" else "O'qilmagan deb belgilash",
                    if (c.conv.unread > 0) IosIcons.CheckCircle else IosIcons.Dot
                ) { toggleRead(c) },
                MenuItem(
                    if (isMuted) "Ogohlantirishlarni ko'rsatish" else "Ogohlantirishlarni yashirish",
                    if (isMuted) IosIcons.Bell else IosIcons.BellSlash
                ) { toggleMute(c) },
                MenuItem("O'chirish", IosIcons.Trash, destructive = true) { askDelete(c) },
            ),
        )
    }

    fun filterMenu() {
        focusManager.clearFocus()
        menu = MenuState(
            anchor = filterRect,
            alignEnd = true,
            source = "filter",
            title = "Filtr",
            items = listOf(
                MenuItem("Barcha xabarlar", IosIcons.Bubble, checked = filter == 0) { filter = 0 },
                MenuItem("Ma'lum jo'natuvchilar", IosIcons.PersonFill, checked = filter == 1) { filter = 1 },
                MenuItem("Noma'lum jo'natuvchilar", IosIcons.Info, checked = filter == 2) { filter = 2 },
                MenuItem("O'qilmaganlar", IosIcons.Dot, checked = filter == 3) { filter = 3 },
                MenuItem("Hammasini o'qilgan qilish", IosIcons.CheckCircle) {
                    if (!needDefault()) {
                        scope.launch(Dispatchers.IO) { SmsRepo.markAllRead(ctx) }
                    }
                },
            ),
        )
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .backdropSource(backdrop)
                .background(ios.bg),
            contentPadding = PaddingValues(top = statusTop + 58.dp, bottom = listBottom + 96.dp),
        ) {
            item(key = "title") {
                Text(
                    text = title,
                    style = IosType.largeTitle,
                    color = ios.label,
                    modifier = Modifier.padding(start = 18.dp, top = 2.dp, bottom = 10.dp),
                )
            }
            if (!vm.isDefault) {
                item(key = "banner") { DefaultBanner(onRequestDefault) }
            }
            if (pinned.isNotEmpty()) {
                item(key = "pinned") {
                    PinnedGrid(pinned, onOpen = { open(it) }, onLongPress = { c, r -> rowMenu(c, r) })
                }
            }
            if (vm.loaded && filtered.isEmpty() && hits.isEmpty()) {
                item(key = "empty") { EmptyState(searching = query.isNotBlank() || filter != 0) }
            }
            itemsIndexed(rest, key = { _, it -> it.threadId }) { index, c ->
                Column(
                    Modifier
                        .animateItem()
                        .introIn(index, !introPlayed)
                ) {
                    ConversationRow(
                        c = c,
                        pinned = c.threadId in pinnedIds,
                        muted = c.threadId in mutedIds,
                        openSwipe = openSwipe,
                        onSwipeOpen = { openSwipe = it },
                        onClick = { open(c) },
                        onLongPress = { r -> rowMenu(c, r) },
                        onDelete = { askDelete(c) },
                        onTogglePin = { Prefs.togglePin(c.threadId) },
                        onToggleRead = { toggleRead(c) },
                        onToggleMute = { toggleMute(c) },
                    )
                    Hairline(Modifier.padding(start = 84.dp))
                }
            }
            if (hits.isNotEmpty()) {
                item(key = "hits-title") {
                    Text(
                        text = "XABARLAR · ${hits.size}",
                        style = IosType.footnote,
                        color = ios.secondary,
                        modifier = Modifier
                            .animateItem()
                            .padding(start = 18.dp, top = 22.dp, bottom = 6.dp),
                    )
                }
                items(hits, key = { "hit" + it.hit.id }) { h ->
                    Box(Modifier.animateItem()) {
                        SearchHitRow(h, query) { openHit(h) }
                    }
                }
            }
        }

        // yuqori chekka: yumshoq o'tish (scroll edge effect)
        Box(
            Modifier
                .fillMaxWidth()
                .height(statusTop + 60.dp)
                .background(
                    Brush.verticalGradient(
                        0f to ios.bg,
                        0.55f to ios.bg.copy(alpha = 0.82f),
                        1f to ios.bg.copy(alpha = 0f),
                    )
                )
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = statusTop + 6.dp, start = 16.dp, end = 16.dp)
                .height(48.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box {
                GlassIconButton(
                    icon = IosIcons.Gear,
                    backdrop = backdrop,
                    iconSize = 22.dp,
                    contentDescription = "Sozlamalar",
                    onClick = {
                        focusManager.clearFocus()
                        nav.push(Screen.Settings)
                    },
                )
                if (hasUpdate) {
                    Box(
                        Modifier
                            .align(Alignment.TopEnd)
                            .size(13.dp)
                            .background(ios.bg, CircleShape)
                            .padding(2.dp)
                            .background(ios.red, CircleShape)
                    )
                }
            }
            Text(
                text = title,
                style = IosType.headline,
                color = ios.label,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .weight(1f)
                    .alpha(smallTitleAlpha),
            )
            GlassIconButton(
                icon = IosIcons.Filter,
                backdrop = backdrop,
                contentDescription = "Filtr",
                onClick = { filterMenu() },
                modifier = Modifier
                    .onGloballyPositioned { filterRect = it.boundsInRoot() }
                    .alpha(if (menu?.source == "filter") 0f else 1f),
                tint = if (filter != 0) ios.blue else Color.Unspecified,
            )
            Spacer(Modifier.width(10.dp))
            GlassIconButton(
                icon = IosIcons.Compose,
                backdrop = backdrop,
                contentDescription = "Yangi xabar",
                onClick = {
                    focusManager.clearFocus()
                    nav.push(Screen.NewMessage())
                },
            )
        }
        // pastda: shisha qidiruv maydoni
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .imePadding()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Glass(
                backdrop = backdrop,
                shape = RoundedCornerShape(50),
                tint = ios.glassField,
                blur = 8.dp,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
                    .clickable(interactionSource = searchInteraction, indication = null) {
                        try {
                            searchFocus.requestFocus()
                        } catch (_: Exception) {
                        }
                        keyboard?.show()
                    },
            ) {
                Row(
                    Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(IosIcons.Search, null, tint = ios.secondary, modifier = Modifier.size(19.dp))
                    Spacer(Modifier.width(9.dp))
                    Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) {
                            Text("Qidiruv: ism, raqam yoki matn", style = IosType.body, color = ios.secondary, maxLines = 1)
                        }
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            singleLine = true,
                            textStyle = IosType.body.copy(color = ios.label),
                            cursorBrush = SolidColor(ios.blue),
                            modifier = Modifier
                                .fillMaxWidth()
                                .focusRequester(searchFocus),
                        )
                    }
                    if (query.isNotEmpty()) {
                        Box(
                            Modifier
                                .size(20.dp)
                                .background(ios.secondary, CircleShape)
                                .clickable { query = "" },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(IosIcons.Xmark, "Tozalash", tint = ios.bg, modifier = Modifier.size(12.dp))
                        }
                    }
                }
            }
        }

        MenuOverlay(menu, backdrop) { menu = null }
        IosAlert(alert, backdrop) { alert = null }
    }
}

@Composable
private fun SearchHitRow(h: HitUi, query: String, onClick: () -> Unit) {
    val ios = LocalIos.current
    val text = remember(h.hit.body, query, ios.blue) { snippet(h.hit.body, query, ios.blue) }
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.Top,
        ) {
            Avatar(h.contactName, h.photo, 40.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = h.name,
                        style = IosType.headline,
                        color = ios.label,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(Fmt.listTime(h.hit.date), style = IosType.subhead, color = ios.secondary, maxLines = 1)
                }
                Spacer(Modifier.height(2.dp))
                Text(text, style = IosType.subhead, color = ios.secondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
        Hairline(Modifier.padding(start = 68.dp))
    }
}

@Composable
private fun DefaultBanner(onRequestDefault: () -> Unit) {
    val ios = LocalIos.current
    Column(
        Modifier
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .fillMaxWidth()
            .background(ios.card, RoundedCornerShape(22.dp))
            .padding(16.dp)
    ) {
        Text("Asosiy SMS ilova emas", style = IosType.headline, color = ios.label)
        Spacer(Modifier.height(4.dp))
        Text(
            "SMS qabul qilish, o'qilgan deb belgilash va o'chirish uchun Xabarlar'ni asosiy SMS ilova qilib belgilang.",
            style = IosType.footnote,
            color = ios.secondary,
        )
        Spacer(Modifier.height(12.dp))
        LiquidButton(text = "Asosiy qilish", color = ios.blue, height = 42.dp, grow = 0.08f, onClick = onRequestDefault)
    }
}

@Composable
private fun EmptyState(searching: Boolean) {
    val ios = LocalIos.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 90.dp, start = 32.dp, end = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(if (searching) IosIcons.Search else IosIcons.Bubble, null, tint = ios.tertiary, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(14.dp))
        Text(if (searching) "Hech narsa topilmadi" else "Xabarlar yo'q", style = IosType.title3, color = ios.label)
        Spacer(Modifier.height(6.dp))
        Text(
            if (searching) "Boshqa so'z bilan qidirib ko'ring." else "Yangi xabar yozish uchun yuqoridagi ✎ tugmasini bosing.",
            style = IosType.subhead,
            color = ios.secondary,
            textAlign = TextAlign.Center,
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PinnedGrid(
    items: List<ConversationUi>,
    onOpen: (ConversationUi) -> Unit,
    onLongPress: (ConversationUi, Rect) -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        items.chunked(3).forEach { rowItems ->
            Row(Modifier.fillMaxWidth()) {
                rowItems.forEach { c ->
                    PinnedItem(c, Modifier.weight(1f), onOpen, onLongPress)
                }
                repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Spacer(Modifier.height(6.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PinnedItem(
    c: ConversationUi,
    modifier: Modifier,
    onOpen: (ConversationUi) -> Unit,
    onLongPress: (ConversationUi, Rect) -> Unit,
) {
    val ios = LocalIos.current
    var rect by remember { mutableStateOf(Rect.Zero) }
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(0.6f, 600f), label = "pin")
    Column(
        modifier
            .padding(vertical = 8.dp)
            .onGloballyPositioned { rect = it.boundsInRoot() }
            .combinedClickable(
                interactionSource = interaction,
                indication = null,
                onLongClick = { onLongPress(c, rect) },
                onClick = { onOpen(c) },
            ),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.size(84.dp), contentAlignment = Alignment.Center) {
            Avatar(
                c.contactName,
                c.photoUri,
                78.dp,
                Modifier.graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                },
            )
            if (c.conv.unread > 0) {
                Box(
                    Modifier
                        .align(Alignment.TopStart)
                        .size(16.dp)
                        .background(ios.bg, CircleShape)
                        .padding(2.5.dp)
                        .background(ios.blue, CircleShape)
                )
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(
            text = c.title,
            style = IosType.caption,
            color = ios.secondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ConversationRow(
    c: ConversationUi,
    pinned: Boolean,
    muted: Boolean,
    openSwipe: Long?,
    onSwipeOpen: (Long?) -> Unit,
    onClick: () -> Unit,
    onLongPress: (Rect) -> Unit,
    onDelete: () -> Unit,
    onTogglePin: () -> Unit,
    onToggleRead: () -> Unit,
    onToggleMute: () -> Unit,
) {
    val ios = LocalIos.current
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val offset = remember { Animatable(0f) }
    val actionW = with(density) { 80.dp.toPx() }
    var rowW by remember { mutableFloatStateOf(1f) }
    var bounds by remember { mutableStateOf(Rect.Zero) }
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val unread = c.conv.unread > 0

    LaunchedEffect(openSwipe) {
        if (openSwipe != c.threadId && offset.value != 0f) offset.animateTo(0f, spring(dampingRatio = 0.9f, stiffness = 600f))
    }

    val leading = listOf(
        SwipeAction(if (unread) "O'qildi" else "O'qilmagan", if (unread) IosIcons.CheckCircle else IosIcons.Dot, ios.blue) {
            onSwipeOpen(null); onToggleRead()
        },
        SwipeAction(if (pinned) "Olib tashlash" else "Qadash", IosIcons.Pin, ios.orange) {
            onSwipeOpen(null); onTogglePin()
        },
    )
    val trailing = listOf(
        SwipeAction(if (muted) "Ovozli" else "Ovozsiz", if (muted) IosIcons.Bell else IosIcons.BellSlash, ios.indigo) {
            onSwipeOpen(null); onToggleMute()
        },
        SwipeAction("O'chirish", IosIcons.Trash, ios.red) {
            onSwipeOpen(null); onDelete()
        },
    )

    suspend fun settle(v: Float) {
        val o = offset.value
        val full = rowW * 0.55f
        when {
            o > full -> {
                offset.animateTo(0f, spring(dampingRatio = 0.85f, stiffness = 500f))
                leading[0].action()
            }
            o < -full -> {
                offset.animateTo(0f, spring(dampingRatio = 0.85f, stiffness = 500f))
                trailing.last().action()
            }
            o > 0f -> {
                val target = if (o > leading.size * actionW * 0.4f || v > 900f) leading.size * actionW else 0f
                offset.animateTo(target, spring(dampingRatio = 0.85f, stiffness = 500f))
            }
            o < 0f -> {
                val target = if (-o > trailing.size * actionW * 0.4f || v < -900f) -trailing.size * actionW else 0f
                offset.animateTo(target, spring(dampingRatio = 0.85f, stiffness = 500f))
            }
        }
    }

    // Surish ishorasi tashqi Box'da — shunda ochilgan tugmalar (O'chirish, Qadash...) bosiladi
    Box(
        Modifier
            .fillMaxWidth()
            .clipToBounds()
            .onSizeChanged { rowW = it.width.toFloat() }
            .onGloballyPositioned { bounds = it.boundsInRoot() }
            .pointerInput(c.threadId) {
                val tracker = VelocityTracker()
                var acc = 0f
                detectHorizontalDragGestures(
                    onDragStart = {
                        tracker.resetTracking()
                        acc = 0f
                        onSwipeOpen(c.threadId)
                    },
                    onDragEnd = {
                        val v = tracker.calculateVelocity().x
                        scope.launch { settle(v) }
                    },
                    onDragCancel = {
                        scope.launch { offset.animateTo(0f) }
                    },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        acc += dx
                        tracker.addPosition(change.uptimeMillis, Offset(acc, 0f))
                        scope.launch {
                            val next = (offset.value + dx).coerceIn(-rowW, rowW)
                            offset.snapTo(next)
                        }
                    },
                )
            }
    ) {
        val o = offset.value
        if (o > 0.5f) SwipeActions(leading, o, start = true, modifier = Modifier.matchParentSize())
        if (o < -0.5f) SwipeActions(trailing, -o, start = false, modifier = Modifier.matchParentSize())

        Row(
            Modifier
                .fillMaxWidth()
                .offset { IntOffset(offset.value.roundToInt(), 0) }
                .background(if (pressed) ios.pressed else ios.bg)
                .combinedClickable(
                    interactionSource = interaction,
                    indication = null,
                    onLongClick = { onLongPress(bounds) },
                    onClick = {
                        if (abs(offset.value) > 1f) {
                            onSwipeOpen(null)
                            scope.launch { offset.animateTo(0f) }
                        } else {
                            onClick()
                        }
                    },
                ),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.width(24.dp), contentAlignment = Alignment.Center) {
                // o'qilmagan nuqta "pop" bo'lib paydo bo'ladi va yo'qoladi
                val dot by animateFloatAsState(
                    targetValue = if (unread) 1f else 0f,
                    animationSpec = spring(dampingRatio = 0.45f, stiffness = 500f),
                    label = "dot",
                )
                if (dot > 0.01f) {
                    Box(
                        Modifier
                            .size(10.dp)
                            .graphicsLayer {
                                scaleX = dot
                                scaleY = dot
                            }
                            .background(ios.blue, CircleShape)
                    )
                }
            }
            Avatar(c.contactName, c.photoUri, 48.dp)
            Spacer(Modifier.width(12.dp))
            Column(
                Modifier
                    .weight(1f)
                    .padding(top = 10.dp, bottom = 11.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = c.title,
                        style = IosType.headline,
                        color = ios.label,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f),
                    )
                    Spacer(Modifier.width(6.dp))
                    if (muted) {
                        Icon(IosIcons.BellSlash, "Ovozsiz", tint = ios.tertiary, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                    }
                    Text(Fmt.listTime(c.conv.date), style = IosType.subhead, color = ios.secondary, maxLines = 1)
                    Spacer(Modifier.width(4.dp))
                    Icon(IosIcons.ChevronRight, null, tint = ios.tertiary, modifier = Modifier.size(12.dp))
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    text = c.conv.snippet.replace('\n', ' '),
                    style = IosType.subhead,
                    color = ios.secondary,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                )
            }
            Spacer(Modifier.width(16.dp))
        }
    }
}

@Composable
private fun SwipeActions(actions: List<SwipeAction>, revealPx: Float, start: Boolean, modifier: Modifier) {
    val density = LocalDensity.current
    val w = with(density) { revealPx.toDp() }
    Box(modifier) {
        Row(
            Modifier
                .width(w)
                .fillMaxHeight()
                .align(if (start) Alignment.CenterStart else Alignment.CenterEnd),
            horizontalArrangement = Arrangement.Start,
        ) {
            actions.forEach { a ->
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(a.color)
                        .clickable { a.action() },
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(a.icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
                        Spacer(Modifier.height(3.dp))
                        Text(a.title, color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Clip)
                    }
                }
            }
        }
    }
}
