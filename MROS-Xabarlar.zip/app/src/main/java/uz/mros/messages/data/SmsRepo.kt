package uz.mros.messages.data

import android.Manifest
import android.app.role.RoleManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.database.ContentObserver
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Telephony
import android.telephony.SubscriptionManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

/** Tizim SMS/MMS bazasi bilan ishlash (content://sms, content://mms, content://mms-sms). */
object SmsRepo {
    private val _version = MutableStateFlow(0L)

    /** Har qanday o'zgarishda oshadi — UI qayta yuklaydi. */
    val version: StateFlow<Long> = _version
    private var observer: ContentObserver? = null

    private val SMS_URI: Uri = Uri.parse("content://sms")
    private val SMS_INBOX_URI: Uri = Uri.parse("content://sms/inbox")
    private val MMS_URI: Uri = Uri.parse("content://mms")
    private val THREADS_URI: Uri = Uri.parse("content://mms-sms/conversations?simple=true")
    private val CANONICAL_URI: Uri = Uri.parse("content://mms-sms/canonical-addresses")

    fun notifyChanged() {
        _version.update { it + 1 }
    }

    fun canRead(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

    fun canSend(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    /** Oxirgi yozish/o'chirish xatosi (foydalanuvchiga ko'rsatish uchun). */
    @Volatile
    var lastError: String? = null
        private set

    fun isDefault(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val rm = ctx.getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_SMS) && rm.isRoleHeld(RoleManager.ROLE_SMS)) return true
            } catch (_: Exception) {
            }
        }
        return try {
            Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName
        } catch (_: Exception) {
            false
        }
    }

    fun startObserving(ctx: Context) {
        if (observer != null || !canRead(ctx)) return
        val obs = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                notifyChanged()
            }
        }
        try {
            ctx.applicationContext.contentResolver.registerContentObserver(Uri.parse("content://mms-sms/"), true, obs)
            ctx.applicationContext.contentResolver.registerContentObserver(SMS_URI, true, obs)
            observer = obs
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- suhbatlar

    fun loadConversations(ctx: Context): List<Conversation> {
        if (!canRead(ctx)) return emptyList()
        val unread = unreadCounts(ctx)
        val threads = try {
            loadThreads(ctx, unread)
        } catch (_: Exception) {
            emptyList()
        }
        if (threads.isNotEmpty()) return threads
        return try {
            loadFromSms(ctx, unread)
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun canonicalAddresses(ctx: Context): Map<Long, String> {
        val map = HashMap<Long, String>()
        try {
            ctx.contentResolver.query(CANONICAL_URI, arrayOf("_id", "address"), null, null, null)?.use { c ->
                while (c.moveToNext()) map[c.getLong(0)] = c.getString(1) ?: ""
            }
        } catch (_: Exception) {
        }
        return map
    }

    private fun parseRecipients(ids: String?, addr: Map<Long, String>): List<String> =
        (ids ?: "").split(' ')
            .mapNotNull { it.trim().toLongOrNull() }
            .mapNotNull { addr[it] }
            .filter { it.isNotBlank() }

    private fun loadThreads(ctx: Context, unread: Map<Long, Int>): List<Conversation> {
        val addr = canonicalAddresses(ctx)
        val out = ArrayList<Conversation>()
        ctx.contentResolver.query(
            THREADS_URI,
            arrayOf("_id", "date", "message_count", "recipient_ids", "snippet"),
            null, null, "date DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                if (c.getInt(2) <= 0) continue
                val recipients = parseRecipients(c.getString(3), addr)
                out += Conversation(id, recipients, c.getString(4) ?: "", c.getLong(1), unread[id] ?: 0)
            }
        }
        return out
    }

    private fun loadFromSms(ctx: Context, unread: Map<Long, Int>): List<Conversation> {
        val map = LinkedHashMap<Long, Conversation>()
        ctx.contentResolver.query(
            SMS_URI, arrayOf("thread_id", "address", "body", "date"),
            "type != 3", null, "date DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val t = c.getLong(0)
                if (map.containsKey(t)) continue
                val a = c.getString(1)
                map[t] = Conversation(t, if (a.isNullOrBlank()) emptyList() else listOf(a), c.getString(2) ?: "", c.getLong(3), unread[t] ?: 0)
            }
        }
        return map.values.toList()
    }

    private fun unreadCounts(ctx: Context): Map<Long, Int> {
        val m = HashMap<Long, Int>()
        try {
            ctx.contentResolver.query(SMS_INBOX_URI, arrayOf("thread_id"), "read = 0", null, null)?.use { c ->
                while (c.moveToNext()) {
                    val t = c.getLong(0)
                    m[t] = (m[t] ?: 0) + 1
                }
            }
        } catch (_: Exception) {
        }
        try {
            ctx.contentResolver.query(Uri.parse("content://mms/inbox"), arrayOf("thread_id"), "read = 0", null, null)?.use { c ->
                while (c.moveToNext()) {
                    val t = c.getLong(0)
                    m[t] = (m[t] ?: 0) + 1
                }
            }
        } catch (_: Exception) {
        }
        return m
    }

    fun threadAddresses(ctx: Context, threadId: Long): List<String> {
        if (threadId <= 0) return emptyList()
        try {
            val addr = canonicalAddresses(ctx)
            ctx.contentResolver.query(THREADS_URI, arrayOf("_id", "recipient_ids"), "_id = ?", arrayOf(threadId.toString()), null)?.use { c ->
                if (c.moveToFirst()) {
                    val r = parseRecipients(c.getString(1), addr)
                    if (r.isNotEmpty()) return r
                }
            }
        } catch (_: Exception) {
        }
        try {
            ctx.contentResolver.query(SMS_URI, arrayOf("address"), "thread_id = ?", arrayOf(threadId.toString()), "date DESC")?.use { c ->
                if (c.moveToFirst()) {
                    val a = c.getString(0)
                    if (!a.isNullOrBlank()) return listOf(a)
                }
            }
        } catch (_: Exception) {
        }
        return emptyList()
    }

    fun threadIdFor(ctx: Context, addresses: List<String>): Long {
        if (addresses.isEmpty()) return -1L
        return try {
            if (addresses.size == 1) Telephony.Threads.getOrCreateThreadId(ctx, addresses[0])
            else Telephony.Threads.getOrCreateThreadId(ctx, addresses.toSet())
        } catch (_: Exception) {
            -1L
        }
    }

    fun threadIdOf(ctx: Context, uri: Uri): Long {
        try {
            ctx.contentResolver.query(uri, arrayOf("thread_id"), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getLong(0)
            }
        } catch (_: Exception) {
        }
        return -1L
    }

    // ---------------------------------------------------------------- xabarlar

    /** Eng yangisi birinchi. */
    fun loadMessages(ctx: Context, threadId: Long, limit: Int): List<Message> {
        if (threadId <= 0 || !canRead(ctx)) return emptyList()
        val list = ArrayList<Message>()
        try {
            ctx.contentResolver.query(
                SMS_URI,
                arrayOf("_id", "address", "body", "date", "type", "status", "read"),
                "thread_id = ? AND type != 3", arrayOf(threadId.toString()), "date DESC"
            )?.use { c ->
                var n = 0
                while (n < limit && c.moveToNext()) {
                    n++
                    list += Message(
                        id = c.getLong(0),
                        threadId = threadId,
                        address = c.getString(1) ?: "",
                        body = c.getString(2) ?: "",
                        date = c.getLong(3),
                        type = c.getInt(4),
                        status = c.getInt(5),
                        read = c.getInt(6) == 1,
                    )
                }
            }
        } catch (_: Exception) {
        }
        try {
            list += loadMms(ctx, threadId, limit)
        } catch (_: Exception) {
        }
        list.sortByDescending { it.date }
        return if (list.size > limit) ArrayList(list.subList(0, limit)) else list
    }

    private fun loadMms(ctx: Context, threadId: Long, limit: Int): List<Message> {
        val out = ArrayList<Message>()
        ctx.contentResolver.query(
            MMS_URI, arrayOf("_id", "date", "msg_box", "read"),
            "thread_id = ?", arrayOf(threadId.toString()), "date DESC"
        )?.use { c ->
            var n = 0
            while (n < limit && c.moveToNext()) {
                n++
                val id = c.getLong(0)
                val box = c.getInt(2)
                if (box == SmsType.DRAFT) continue
                val parts = mmsParts(ctx, id)
                out += Message(
                    id = id,
                    threadId = threadId,
                    address = if (box == SmsType.INBOX) mmsFrom(ctx, id) else "",
                    body = parts.first,
                    date = c.getLong(1) * 1000L,
                    type = box,
                    status = SmsStatus.NONE,
                    read = c.getInt(3) == 1,
                    isMms = true,
                    images = parts.second,
                )
            }
        }
        return out
    }

    private fun mmsParts(ctx: Context, mmsId: Long): Pair<String, List<Uri>> {
        val sb = StringBuilder()
        val images = ArrayList<Uri>()
        try {
            ctx.contentResolver.query(
                Uri.parse("content://mms/part"), arrayOf("_id", "ct", "text"),
                "mid = ?", arrayOf(mmsId.toString()), null
            )?.use { c ->
                while (c.moveToNext()) {
                    val partId = c.getLong(0)
                    val ct = c.getString(1) ?: ""
                    if (ct == "text/plain") {
                        val t = c.getString(2)
                        if (!t.isNullOrEmpty()) {
                            if (sb.isNotEmpty()) sb.append('\n')
                            sb.append(t)
                        }
                    } else if (ct.startsWith("image/")) {
                        images += Uri.parse("content://mms/part/$partId")
                    }
                }
            }
        } catch (_: Exception) {
        }
        return Pair(sb.toString(), images)
    }

    private fun mmsFrom(ctx: Context, mmsId: Long): String {
        try {
            ctx.contentResolver.query(Uri.parse("content://mms/$mmsId/addr"), arrayOf("address"), "type = 137", null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: ""
            }
        } catch (_: Exception) {
        }
        return ""
    }

    fun recentUnread(ctx: Context, threadId: Long, max: Int): List<Pair<String, Long>> {
        val out = ArrayList<Pair<String, Long>>()
        try {
            ctx.contentResolver.query(
                SMS_INBOX_URI, arrayOf("body", "date"),
                "thread_id = ? AND read = 0", arrayOf(threadId.toString()), "date DESC"
            )?.use { c ->
                while (out.size < max && c.moveToNext()) out += Pair(c.getString(0) ?: "", c.getLong(1))
            }
        } catch (_: Exception) {
        }
        return out.reversed()
    }

    // ---------------------------------------------------------------- yozish (faqat asosiy SMS ilova)

    private fun insertWithSub(ctx: Context, uri: Uri, v: ContentValues, subId: Int): Uri? {
        if (subId >= 0) {
            v.put("sub_id", subId)
            try {
                val r = ctx.contentResolver.insert(uri, v)
                if (r != null) return r
            } catch (_: Exception) {
            }
            v.remove("sub_id")
        }
        return try {
            ctx.contentResolver.insert(uri, v)
        } catch (_: Exception) {
            null
        }
    }

    fun insertIncoming(ctx: Context, address: String, body: String, dateSent: Long, subId: Int): Uri? {
        val v = ContentValues().apply {
            put("address", address)
            put("body", body)
            put("date", System.currentTimeMillis())
            put("date_sent", dateSent)
            put("read", 0)
            put("seen", 0)
            put("type", SmsType.INBOX)
        }
        return insertWithSub(ctx, SMS_INBOX_URI, v, subId)
    }

    fun insertOutgoing(ctx: Context, address: String, body: String, subId: Int, threadId: Long): Uri? {
        val v = ContentValues().apply {
            put("address", address)
            put("body", body)
            put("date", System.currentTimeMillis())
            put("read", 1)
            put("seen", 1)
            put("type", SmsType.OUTBOX)
            put("status", SmsStatus.NONE)
            if (threadId > 0) put("thread_id", threadId)
        }
        return insertWithSub(ctx, SMS_URI, v, subId)
    }

    fun updateType(ctx: Context, uri: Uri, type: Int) {
        try {
            ctx.contentResolver.update(uri, ContentValues().apply { put("type", type) }, null, null)
        } catch (_: Exception) {
        }
    }

    fun updateStatus(ctx: Context, uri: Uri, status: Int) {
        try {
            ctx.contentResolver.update(uri, ContentValues().apply { put("status", status) }, null, null)
        } catch (_: Exception) {
        }
    }

    fun markSent(ctx: Context, uri: Uri) {
        try {
            var t = -1
            ctx.contentResolver.query(uri, arrayOf("type"), null, null, null)?.use { c ->
                if (c.moveToFirst()) t = c.getInt(0)
            }
            if (t != SmsType.FAILED) updateType(ctx, uri, SmsType.SENT)
        } catch (_: Exception) {
        }
    }

    fun markThreadRead(ctx: Context, threadId: Long) {
        if (threadId <= 0) return
        val v = ContentValues().apply {
            put("read", 1)
            put("seen", 1)
        }
        try {
            ctx.contentResolver.update(SMS_URI, v, "thread_id = ? AND (read = 0 OR seen = 0)", arrayOf(threadId.toString()))
        } catch (_: Exception) {
        }
        try {
            ctx.contentResolver.update(MMS_URI, v, "thread_id = ? AND read = 0", arrayOf(threadId.toString()))
        } catch (_: Exception) {
        }
    }

    fun markThreadUnread(ctx: Context, threadId: Long) {
        try {
            var id = -1L
            ctx.contentResolver.query(SMS_INBOX_URI, arrayOf("_id"), "thread_id = ?", arrayOf(threadId.toString()), "date DESC")?.use { c ->
                if (c.moveToFirst()) id = c.getLong(0)
            }
            if (id > 0) ctx.contentResolver.update(Uri.parse("content://sms/$id"), ContentValues().apply { put("read", 0) }, null, null)
        } catch (_: Exception) {
        }
        notifyChanged()
    }

    fun markAllRead(ctx: Context) {
        val v = ContentValues().apply {
            put("read", 1)
            put("seen", 1)
        }
        try {
            ctx.contentResolver.update(SMS_URI, v, "read = 0 OR seen = 0", null)
        } catch (_: Exception) {
        }
        try {
            ctx.contentResolver.update(MMS_URI, v, "read = 0", null)
        } catch (_: Exception) {
        }
        notifyChanged()
    }

    private fun errText(e: Exception): String = e.message ?: e.javaClass.simpleName

    /** O'chirilgan qatorlar soni (0 bo'lsa — o'chmadi, sababi [lastError]da). */
    fun deleteThread(ctx: Context, threadId: Long): Int {
        var n = 0
        lastError = null
        try {
            n = ctx.contentResolver.delete(Uri.parse("content://mms-sms/conversations/$threadId"), null, null)
        } catch (e: Exception) {
            lastError = errText(e)
        }
        if (n <= 0) {
            try {
                n += ctx.contentResolver.delete(SMS_URI, "thread_id = ?", arrayOf(threadId.toString()))
            } catch (e: Exception) {
                lastError = errText(e)
            }
            try {
                n += ctx.contentResolver.delete(MMS_URI, "thread_id = ?", arrayOf(threadId.toString()))
            } catch (e: Exception) {
                if (lastError == null) lastError = errText(e)
            }
        }
        notifyChanged()
        return n
    }

    fun deleteMessage(ctx: Context, msg: Message): Int {
        var n = 0
        lastError = null
        try {
            n = ctx.contentResolver.delete(msg.uri, null, null)
        } catch (e: Exception) {
            lastError = errText(e)
        }
        notifyChanged()
        return n
    }

    // ---------------------------------------------------------------- SIM kartalar

    fun sims(ctx: Context): List<Sim> {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) return emptyList()
        return try {
            val sm = ctx.getSystemService(SubscriptionManager::class.java) ?: return emptyList()
            val list = sm.activeSubscriptionInfoList ?: return emptyList()
            list.map { info ->
                val name = info.displayName?.toString()?.trim().orEmpty()
                Sim(info.subscriptionId, if (name.isEmpty()) "SIM ${info.simSlotIndex + 1}" else name, info.simSlotIndex)
            }.sortedBy { it.slot }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun defaultSmsSubId(): Int = try {
        SubscriptionManager.getDefaultSmsSubscriptionId()
    } catch (_: Exception) {
        -1
    }
}
