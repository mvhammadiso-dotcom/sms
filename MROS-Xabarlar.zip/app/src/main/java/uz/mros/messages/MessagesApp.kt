package uz.mros.messages

import android.app.Application
import uz.mros.messages.data.Prefs
import uz.mros.messages.sms.Notifier

class MessagesApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Notifier.createChannels(this)
    }
}
