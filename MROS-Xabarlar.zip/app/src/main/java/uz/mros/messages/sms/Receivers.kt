package uz.mros.messages.sms

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Telephony
import android.telephony.SmsMessage
import android.util.Log
import android.widget.Toast
import androidx.core.app.RemoteInput
import uz.mros.messages.data.SmsRepo
import uz.mros.messages.data.SmsStatus
import uz.mros.messages.data.SmsType
import kotlin.concurrent.thread

/** Kiruvchi SMS — faqat asosiy SMS ilovaga yetkaziladi, bazaga o'zimiz yozamiz. */
class SmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        val app = context.applicationContext
        val pending = goAsync()
        thread {
            try {
                val raw: Array<SmsMessage?> = Telephony.Sms.Intents.getMessagesFromIntent(intent) ?: arrayOf()
                val msgs = raw.filterNotNull()
                if (msgs.isNotEmpty()) {
                    val first = msgs[0]
                    val address = first.displayOriginatingAddress ?: first.originatingAddress ?: ""
                    val body = msgs.joinToString("") { it.displayMessageBody ?: it.messageBody ?: "" }
                    val subId = intent.getIntExtra(
                        "android.telephony.extra.SUBSCRIPTION_INDEX",
                        intent.getIntExtra("subscription", -1)
                    )
                    val uri = SmsRepo.insertIncoming(app, address, body, first.timestampMillis, subId)
                    var threadId = if (uri != null) SmsRepo.threadIdOf(app, uri) else -1L
                    if (threadId <= 0) threadId = SmsRepo.threadIdFor(app, listOf(address))
                    SmsRepo.notifyChanged()
                    Notifier.showIncoming(app, threadId, address, body)
                }
            } catch (e: Exception) {
                Log.e("MrosSms", "Kiruvchi SMS xatosi", e)
            } finally {
                pending.finish()
            }
        }
    }
}

/** MMS hozircha yuklab olinmaydi — faqat xabardor qilamiz. */
class MmsDeliverReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Notifier.showMmsInfo(context.applicationContext)
        SmsRepo.notifyChanged()
    }
}

/** Yuborildi / yetkazildi hisobotlari. */
class SmsStatusReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val uriStr = intent.getStringExtra(SmsSender.EXTRA_URI)
        if (uriStr == null) {
            SmsRepo.notifyChanged()
            return
        }
        val uri = Uri.parse(uriStr)
        val part = intent.getIntExtra(SmsSender.EXTRA_PART, 0)
        val total = intent.getIntExtra(SmsSender.EXTRA_TOTAL, 1)
        when (intent.action) {
            SmsSender.ACTION_SENT -> {
                if (resultCode == Activity.RESULT_OK) {
                    if (part >= total - 1) SmsRepo.markSent(app, uri)
                } else {
                    SmsRepo.updateType(app, uri, SmsType.FAILED)
                    Notifier.showFailed(app, SmsRepo.threadIdOf(app, uri))
                }
            }
            SmsSender.ACTION_DELIVERED -> {
                var status = SmsStatus.COMPLETE
                val pdu = intent.getByteArrayExtra("pdu")
                val format = intent.getStringExtra("format")
                if (pdu != null) {
                    try {
                        val msg = SmsMessage.createFromPdu(pdu, format)
                        val s = msg?.status ?: 0
                        status = when {
                            s >= 0x40 -> SmsStatus.FAILED
                            s >= 0x20 -> SmsStatus.PENDING
                            else -> SmsStatus.COMPLETE
                        }
                    } catch (_: Exception) {
                    }
                }
                if (part >= total - 1 || status != SmsStatus.COMPLETE) SmsRepo.updateStatus(app, uri, status)
            }
        }
        SmsRepo.notifyChanged()
    }
}

/** Bildirishnomadagi tugmalar: javob, o'qildi, kodni nusxalash. */
class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val threadId = intent.getLongExtra(Notifier.EXTRA_THREAD, -1L)
        when (intent.action) {
            Notifier.ACTION_REPLY -> {
                val text = RemoteInput.getResultsFromIntent(intent)
                    ?.getCharSequence(Notifier.KEY_REPLY)?.toString()?.trim()
                val address = intent.getStringExtra(Notifier.EXTRA_ADDRESS)
                if (text.isNullOrEmpty() || address.isNullOrEmpty()) return
                val pending = goAsync()
                thread {
                    try {
                        SmsSender.send(app, address, text, SmsSender.effectiveSubId(app), threadId)
                        SmsRepo.markThreadRead(app, threadId)
                    } catch (e: Exception) {
                        Log.e("MrosSms", "Javob xatosi", e)
                    } finally {
                        Notifier.cancel(app, threadId)
                        SmsRepo.notifyChanged()
                        pending.finish()
                    }
                }
            }
            Notifier.ACTION_MARK_READ -> {
                val pending = goAsync()
                thread {
                    try {
                        SmsRepo.markThreadRead(app, threadId)
                    } finally {
                        Notifier.cancel(app, threadId)
                        SmsRepo.notifyChanged()
                        pending.finish()
                    }
                }
            }
            Notifier.ACTION_COPY_CODE -> {
                val code = intent.getStringExtra(Notifier.EXTRA_CODE) ?: return
                try {
                    val cm = app.getSystemService(ClipboardManager::class.java)
                    cm?.setPrimaryClip(ClipData.newPlainText("kod", code))
                    if (Build.VERSION.SDK_INT < 33) Toast.makeText(app, "Kod nusxalandi: $code", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {
                }
            }
        }
    }
}
