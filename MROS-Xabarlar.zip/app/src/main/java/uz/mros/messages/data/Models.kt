package uz.mros.messages.data

import android.net.Uri

/** Telephony.TextBasedSmsColumns qiymatlari */
object SmsType {
    const val INBOX = 1
    const val SENT = 2
    const val DRAFT = 3
    const val OUTBOX = 4
    const val FAILED = 5
    const val QUEUED = 6
}

object SmsStatus {
    const val NONE = -1
    const val COMPLETE = 0
    const val PENDING = 32
    const val FAILED = 64
}

data class Conversation(
    val threadId: Long,
    val addresses: List<String>,
    val snippet: String,
    val date: Long,
    val unread: Int,
)

data class ConversationUi(
    val conv: Conversation,
    val title: String,
    val photoUri: String?,
    val contactName: String?,
) {
    val threadId: Long get() = conv.threadId
}

data class Message(
    val id: Long,
    val threadId: Long,
    val address: String,
    val body: String,
    val date: Long,
    val type: Int,
    val status: Int,
    val read: Boolean,
    val isMms: Boolean = false,
    val images: List<Uri> = emptyList(),
) {
    val key: String get() = if (isMms) "mm$id" else "s$id"
    val outgoing: Boolean get() = type != SmsType.INBOX
    val failed: Boolean get() = type == SmsType.FAILED
    val pending: Boolean get() = type == SmsType.OUTBOX || type == SmsType.QUEUED
    val delivered: Boolean get() = status == SmsStatus.COMPLETE
    val uri: Uri get() = Uri.parse(if (isMms) "content://mms/$id" else "content://sms/$id")
}

data class ContactInfo(val name: String?, val photoUri: String?, val contactUri: Uri?)

data class PhoneContact(val name: String, val number: String, val label: String, val photoUri: String?)

data class Sim(val subId: Int, val label: String, val slot: Int)
