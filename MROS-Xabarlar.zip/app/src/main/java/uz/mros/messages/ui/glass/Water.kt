package uz.mros.messages.ui.glass

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.addOutline
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.lerp
import kotlin.math.max
import kotlin.math.min

/**
 * "Suv tomchisi" qatlami — shader ishlamaydigan joylarda (Android 12 va past, rangli tugmalar).
 * [tint] berilsa — tugma shu rangdagi suvdek to'ldiriladi (yuqorisi och, pasti to'q).
 * Yuqorida yaltiroq aks, pastda yorug'lik to'planishi (kaustika), chetida nur,
 * oq fonda ingichka to'q chet, bosilganda to'lqin halqasi.
 */
fun Modifier.waterSheen(
    shape: Shape,
    dark: Boolean,
    tint: Color = Color.Unspecified,
    touch: GlassTouch? = null,
): Modifier = this.drawWithCache {
    val outline = shape.createOutline(size, layoutDirection, this)
    val path = Path().apply { addOutline(outline) }
    val w = size.width
    val h = size.height
    val mn = max(min(w, h), 1f)
    val colored = tint != Color.Unspecified
    val fill = if (colored) {
        Brush.verticalGradient(
            0f to lerp(tint, Color.White, 0.22f),
            0.55f to tint,
            1f to lerp(tint, Color.Black, 0.14f),
        )
    } else {
        null
    }
    val topAlpha = when {
        colored -> 0.42f
        dark -> 0.20f
        else -> 0.60f
    }
    val sheen = Brush.verticalGradient(
        0f to Color.White.copy(alpha = topAlpha),
        1f to Color.White.copy(alpha = 0f),
        startY = 0f,
        endY = h * 0.55f,
    )
    val blobCenter = Offset(min(w * 0.30f, mn * 0.42f), h * 0.22f)
    val blob = Brush.radialGradient(
        0f to Color.White.copy(alpha = if (dark && !colored) 0.30f else 0.55f),
        1f to Color.White.copy(alpha = 0f),
        center = blobCenter,
        radius = mn * 0.32f,
    )
    val caustic = Brush.radialGradient(
        0f to Color.White.copy(alpha = if (colored) 0.34f else if (dark) 0.16f else 0.28f),
        1f to Color.White.copy(alpha = 0f),
        center = Offset(w * 0.62f, h * 1.02f),
        radius = max(w * 0.55f, mn * 0.6f),
    )
    val rim = Brush.linearGradient(
        0f to Color.White.copy(alpha = if (dark) 0.55f else 0.95f),
        0.45f to Color.White.copy(alpha = 0.06f),
        1f to Color.White.copy(alpha = if (dark) 0.35f else 0.6f),
        start = Offset.Zero,
        end = Offset(w, h),
    )
    val edge = Color.Black.copy(alpha = if (dark) 0f else if (colored) 0.10f else 0.07f)
    val rimW = 1.1f * density
    onDrawWithContent {
        clipPath(path) {
            if (fill != null) drawRect(fill)
        }
        drawContent()
        clipPath(path) {
            drawRect(sheen, size = Size(w, h * 0.55f))
            drawRect(blob)
            drawRect(caustic)
            if (touch != null) {
                val a = touch.amount.value.coerceIn(0f, 1f)
                val tp = touch.pos
                if (a > 0.01f && tp.isSpecified) {
                    drawRect(
                        Brush.radialGradient(
                            0f to Color.White.copy(alpha = 0.32f * a),
                            1f to Color.White.copy(alpha = 0f),
                            center = tp,
                            radius = mn * 0.9f,
                        )
                    )
                }
                val rph = touch.ripple.value
                val rp = touch.ripplePos
                if (rph < 0.999f && rp.isSpecified) {
                    val fade = 1f - rph
                    drawCircle(
                        color = Color.White.copy(alpha = 0.42f * fade),
                        radius = rph * max(w, h) * 1.1f,
                        center = rp,
                        style = Stroke(width = 9f * density * fade + 1f),
                    )
                }
            }
        }
        if (edge.alpha > 0f) drawPath(path, edge, style = Stroke(width = rimW * 2.2f))
        drawPath(path, rim, style = Stroke(width = rimW))
    }
}
