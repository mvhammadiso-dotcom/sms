package uz.mros.messages.data

import android.content.ContentValues
import android.content.Context
import android.provider.BlockedNumberContract

/** Tizimning bloklangan raqamlar ro'yxati (faqat asosiy SMS ilova uchun ishlaydi). */
object Blocker {
    fun isBlocked(ctx: Context, number: String): Boolean = try {
        BlockedNumberContract.isBlocked(ctx, number)
    } catch (_: Exception) {
        false
    }

    fun block(ctx: Context, number: String): Boolean = try {
        val v = ContentValues().apply { put(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER, number) }
        ctx.contentResolver.insert(BlockedNumberContract.BlockedNumbers.CONTENT_URI, v) != null
    } catch (_: Exception) {
        false
    }

    fun unblock(ctx: Context, number: String): Boolean = try {
        BlockedNumberContract.unblock(ctx, number) > 0
    } catch (_: Exception) {
        false
    }

    fun list(ctx: Context): List<String> {
        val out = ArrayList<String>()
        try {
            ctx.contentResolver.query(
                BlockedNumberContract.BlockedNumbers.CONTENT_URI,
                arrayOf(BlockedNumberContract.BlockedNumbers.COLUMN_ORIGINAL_NUMBER),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0)
                    if (!n.isNullOrBlank()) out += n
                }
            }
        } catch (_: Exception) {
        }
        return out
    }
}
