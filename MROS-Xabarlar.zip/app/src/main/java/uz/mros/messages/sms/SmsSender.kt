package uz.mros.messages.sms

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import android.util.Log
import uz.mros.messages.data.Message
import uz.mros.messages.data.Prefs
import uz.mros.messages.data.SmsRepo
import uz.mros.messages.data.SmsType
import java.util.concurrent.atomic.AtomicInteger

object SmsSender {
    const val ACTION_SENT = "uz.mros.messages.action.SMS_SENT"
    const val ACTION_DELIVERED = "uz.mros.messages.action.SMS_DELIVERED"
    const val EXTRA_URI = "msg_uri"
    const val EXTRA_PART = "part"
    const val EXTRA_TOTAL = "total"

    private val requestCodes = AtomicInteger((System.currentTimeMillis() % 1_000_000L).toInt())

    @Suppress("DEPRECATION")
    fun manager(ctx: Context, subId: Int): SmsManager {
        return if (Build.VERSION.SDK_INT >= 31) {
            val base: SmsManager = ctx.getSystemService(SmsManager::class.java) ?: SmsManager.getDefault()
            if (subId >= 0) base.createForSubscriptionId(subId) else base
        } else {
            if (subId >= 0) SmsManager.getSmsManagerForSubscriptionId(subId) else SmsManager.getDefault()
        }
    }

    /** Foydalanuvchi tanlagan SIM, bo'lmasa tizimniki, bo'lmasa birinchisi. */
    fun effectiveSubId(ctx: Context): Int {
        val sims = SmsRepo.sims(ctx)
        val pref = Prefs.simSubId.value
        if (pref >= 0 && sims.any { it.subId == pref }) return pref
        val def = SmsRepo.defaultSmsSubId()
        if (def >= 0 && (sims.isEmpty() || sims.any { it.subId == def })) return def
        return sims.firstOrNull()?.subId ?: -1
    }

    private fun pending(ctx: Context, action: String, uri: Uri?, part: Int, total: Int): PendingIntent {
        val intent = Intent(ctx, SmsStatusReceiver::class.java)
            .setAction(action)
            .putExtra(EXTRA_URI, uri?.toString())
            .putExtra(EXTRA_PART, part)
            .putExtra(EXTRA_TOTAL, total)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        return PendingIntent.getBroadcast(ctx, requestCodes.incrementAndGet(), intent, flags)
    }

    /** Fon oqimida chaqiring. */
    fun send(ctx: Context, address: String, text: String, subId: Int, threadId: Long, existing: Uri? = null) {
        val app = ctx.applicationContext
        if (text.isEmpty() || address.isBlank()) return
        var uri: Uri? = null
        if (SmsRepo.isDefault(app)) {
            uri = if (existing != null) {
                SmsRepo.updateType(app, existing, SmsType.OUTBOX)
                existing
            } else {
                SmsRepo.insertOutgoing(app, address, text, subId, threadId)
            }
            SmsRepo.notifyChanged()
        }
        try {
            val sm = manager(app, subId)
            val parts = sm.divideMessage(text)
            val wantDelivery = Prefs.delivery.value
            val sent = ArrayList<PendingIntent>()
            val delivered = ArrayList<PendingIntent>()
            for (i in 0 until parts.size) {
                sent.add(pending(app, ACTION_SENT, uri, i, parts.size))
                if (wantDelivery) delivered.add(pending(app, ACTION_DELIVERED, uri, i, parts.size))
            }
            if (parts.size > 1) {
                sm.sendMultipartTextMessage(address, null, parts, sent, if (wantDelivery) delivered else null)
            } else {
                sm.sendTextMessage(address, null, text, sent[0], if (wantDelivery) delivered[0] else null)
            }
        } catch (e: Exception) {
            Log.e("MrosSms", "SMS yuborilmadi", e)
            uri?.let { SmsRepo.updateType(app, it, SmsType.FAILED) }
        }
        SmsRepo.notifyChanged()
    }

    fun resend(ctx: Context, msg: Message, subId: Int) {
        if (msg.isMms || msg.address.isBlank()) return
        send(ctx, msg.address, msg.body, subId, msg.threadId, existing = msg.uri)
    }
}
