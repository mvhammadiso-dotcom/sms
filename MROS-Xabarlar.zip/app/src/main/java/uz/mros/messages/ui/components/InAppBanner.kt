package uz.mros.messages.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Build
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import uz.mros.messages.sms.InAppMessage
import uz.mros.messages.ui.glass.Backdrop
import uz.mros.messages.ui.glass.Glass
import uz.mros.messages.ui.glass.GlassTouch
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos
import uz.mros.messages.util.Fmt

/**
 * Ilova ochiq paytda yangi SMS: ekran tepasidan suv tomchisidek tushadigan shisha banner.
 * Bosish — suhbatni ochadi, yuqoriga surish — yopadi, 5 soniyada o'zi yo'qoladi.
 */
@Composable
fun InAppBanner(
    message: InAppMessage?,
    backdrop: Backdrop?,
    onOpen: (InAppMessage) -> Unit,
    onDismiss: () -> Unit,
) {
    val ios = LocalIos.current
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val enter = remember { Animatable(0f) }
    val drag = remember { Animatable(0f) }
    var shown by remember { mutableStateOf<InAppMessage?>(null) }
    val latestDismiss by rememberUpdatedState(onDismiss)
    val touch = remember { GlassTouch() }

    LaunchedEffect(message?.id) {
        if (message != null) {
            val replacing = shown != null && enter.value > 0.5f
            shown = message
            drag.snapTo(0f)
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            if (replacing) {
                // yangi xabar kelsa — banner "jele" kabi tebranadi
                enter.snapTo(0.86f)
            }
            enter.animateTo(1f, spring(dampingRatio = 0.58f, stiffness = 260f))
            delay(5000)
            enter.animateTo(0f, tween(260))
            shown = null
            latestDismiss()
        } else if (shown != null) {
            enter.animateTo(0f, tween(220))
            shown = null
        }
    }

    val m = shown ?: return
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    Box(
        Modifier
            .fillMaxWidth()
            .padding(top = top + 6.dp, start = 10.dp, end = 10.dp)
            .graphicsLayer {
                val e = enter.value
                val hidden = -(size.height + top.toPx() + 20.dp.toPx())
                translationY = hidden * (1f - e) + drag.value
                // tushayotganda biroz cho'ziladi, joyiga tushganda tomchidek yassilanadi
                val over = (e - 1f)
                scaleX = 0.92f + 0.08f * e - over * 0.25f
                scaleY = 0.92f + 0.08f * e + over * 0.35f
                transformOrigin = TransformOrigin(0.5f, 0f)
                alpha = e.coerceIn(0f, 1f)
            }
            .pointerInput(m.id) {
                detectVerticalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (drag.value < -40.dp.toPx()) {
                                enter.animateTo(0f, tween(180))
                                shown = null
                                latestDismiss()
                            } else {
                                drag.animateTo(0f, spring(dampingRatio = 0.5f, stiffness = 400f))
                            }
                        }
                    },
                    onDragCancel = { scope.launch { drag.animateTo(0f) } },
                    onVerticalDrag = { ch, dy ->
                        ch.consume()
                        scope.launch {
                            // pastga — rezina kabi qarshilik, yuqoriga — erkin
                            val next = drag.value + if (dy > 0f && drag.value >= 0f) dy * 0.25f else dy
                            drag.snapTo(next)
                        }
                    },
                )
            }
    ) {
        Glass(
            backdrop = backdrop,
            shape = RoundedCornerShape(26.dp),
            modifier = Modifier
                .fillMaxWidth()
                .liquidPress(touch, scope, grow = 0.03f) {
                    scope.launch {
                        enter.animateTo(0f, tween(160))
                        shown = null
                        latestDismiss()
                    }
                    onOpen(m)
                },
            tint = ios.menuTint,
            blur = 20.dp,
            shadow = 18.dp,
            touch = touch,
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 12.dp, end = 12.dp, top = 11.dp, bottom = 11.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box {
                    Avatar(m.contactName, m.photoUri, 42.dp)
                    Box(
                        Modifier
                            .align(Alignment.BottomEnd)
                            .size(18.dp)
                    ) {
                        AppIconBadge(18.dp)
                    }
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = m.title,
                            style = IosType.subhead.copy(fontWeight = FontWeight.SemiBold),
                            color = ios.label,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f),
                        )
                        Text("hozir", style = IosType.caption, color = ios.secondary)
                    }
                    Text(
                        text = m.body.replace('\n', ' '),
                        style = IosType.subhead,
                        color = ios.label,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                val code = m.code
                if (code != null) {
                    Spacer(Modifier.width(8.dp))
                    LiquidButton(
                        text = code,
                        color = ios.blue,
                        height = 34.dp,
                        grow = 0.12f,
                    ) {
                        try {
                            val cm = ctx.getSystemService(ClipboardManager::class.java)
                            cm?.setPrimaryClip(ClipData.newPlainText("kod", code))
                            if (Build.VERSION.SDK_INT < 33) Toast.makeText(ctx, "Kod nusxalandi", Toast.LENGTH_SHORT).show()
                        } catch (_: Exception) {
                        }
                        scope.launch {
                            enter.animateTo(0f, tween(180))
                            shown = null
                            latestDismiss()
                        }
                    }
                }
            }
        }
    }
}
