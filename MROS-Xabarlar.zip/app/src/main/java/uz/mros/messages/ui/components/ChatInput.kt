package uz.mros.messages.ui.components

import android.telephony.SmsMessage
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import uz.mros.messages.ui.glass.Backdrop
import uz.mros.messages.ui.glass.Glass
import uz.mros.messages.ui.glass.GlassTouch
import uz.mros.messages.ui.glass.waterSheen
import kotlinx.coroutines.launch
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos

/** iOS 27 xabar maydoni: "+" tugma, shisha kapsula, yuborish strelkasi (bosib turish — effektlar). */
@Composable
fun ChatInput(
    text: String,
    onText: (String) -> Unit,
    backdrop: Backdrop?,
    sendColor: Color,
    simLabel: String?,
    onSim: () -> Unit,
    onPlus: () -> Unit,
    onSend: () -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "SMS",
    focusRequester: FocusRequester? = null,
    onLongSend: (() -> Unit)? = null,
    onPlusBounds: (Rect) -> Unit = {},
    onSendBounds: (Rect) -> Unit = {},
    plusVisible: Boolean = true,
) {
    val ios = LocalIos.current
    val fr = focusRequester ?: remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val fieldInteraction = remember { MutableInteractionSource() }
    val sendTouch = remember { GlassTouch() }
    val fly = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val canSend = text.isNotBlank()
    val sendScale by animateFloatAsState(
        targetValue = if (canSend) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 700f),
        label = "send",
    )
    val counter = remember(text) {
        if (text.length < 120) {
            null
        } else {
            try {
                val r = SmsMessage.calculateLength(text, false)
                "${r[0]} SMS · ${r[2]}"
            } catch (_: Exception) {
                null
            }
        }
    }

    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        GlassIconButton(
            icon = IosIcons.Plus,
            backdrop = backdrop,
            onClick = onPlus,
            size = 42.dp,
            iconSize = 19.dp,
            tint = ios.secondary,
            modifier = Modifier
                .onGloballyPositioned { onPlusBounds(it.boundsInRoot()) }
                .alpha(if (plusVisible) 1f else 0f),
        )
        Spacer(Modifier.width(8.dp))
        Glass(
            backdrop = backdrop,
            shape = RoundedCornerShape(21.dp),
            tint = ios.glassField,
            blur = 8.dp,
            modifier = Modifier
                .weight(1f)
                .heightIn(min = 42.dp)
                .clickable(interactionSource = fieldInteraction, indication = null) {
                    try {
                        fr.requestFocus()
                    } catch (_: Exception) {
                    }
                    keyboard?.show()
                },
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 6.dp, end = 5.dp, top = 5.dp, bottom = 5.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                if (simLabel != null) {
                    Box(
                        Modifier
                            .height(32.dp)
                            .background(ios.fill, RoundedCornerShape(50))
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onSim)
                            .padding(horizontal = 9.dp),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(simLabel, style = IosType.caption.copy(fontWeight = FontWeight.SemiBold), color = ios.secondary)
                    }
                }
                Box(
                    Modifier
                        .weight(1f)
                        .padding(start = 8.dp, end = 6.dp, top = 5.dp, bottom = 5.dp),
                ) {
                    if (text.isEmpty()) {
                        Text(placeholder, style = IosType.body, color = ios.tertiary, maxLines = 1)
                    }
                    BasicTextField(
                        value = text,
                        onValueChange = onText,
                        textStyle = IosType.body.copy(color = ios.label),
                        cursorBrush = SolidColor(ios.blue),
                        maxLines = 6,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(fr),
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    if (counter != null) {
                        Text(counter, style = IosType.caption2, color = ios.tertiary, modifier = Modifier.padding(end = 4.dp, bottom = 4.dp))
                    }
                    if (sendScale > 0.01f) {
                        Box(
                            Modifier
                                .size(32.dp)
                                .graphicsLayer {
                                    scaleX = sendScale
                                    scaleY = sendScale
                                    alpha = sendScale.coerceIn(0f, 1f)
                                }
                                .onGloballyPositioned { onSendBounds(it.boundsInRoot()) }
                                .liquidPress(
                                    sendTouch,
                                    scope,
                                    grow = 0.28f,
                                    onLongClick = if (canSend) onLongSend else null,
                                ) {
                                    if (canSend) {
                                        // strelka yuqoriga uchib ketadi, pastdan qaytib keladi
                                        scope.launch {
                                            fly.snapTo(0f)
                                            fly.animateTo(1f, tween(170))
                                            fly.snapTo(-1f)
                                            fly.animateTo(0f, spring(dampingRatio = 0.55f, stiffness = 420f))
                                        }
                                        onSend()
                                    }
                                }
                                .clip(CircleShape)
                                .waterSheen(CircleShape, ios.dark, tint = sendColor, touch = sendTouch),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(
                                IosIcons.ArrowUp,
                                "Yuborish",
                                tint = Color.White,
                                modifier = Modifier
                                    .size(17.dp)
                                    .graphicsLayer {
                                        val f = fly.value
                                        translationY = -f * 26.dp.toPx()
                                        alpha = 1f - kotlin.math.abs(f)
                                    },
                            )
                        }
                    } else {
                        Spacer(Modifier.size(width = 4.dp, height = 32.dp))
                    }
                }
            }
        }
    }
}
