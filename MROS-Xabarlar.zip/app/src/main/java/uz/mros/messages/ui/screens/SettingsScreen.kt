package uz.mros.messages.ui.screens

import uz.mros.messages.ui.components.LiquidButton
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uz.mros.messages.data.Blocker
import uz.mros.messages.data.Prefs
import uz.mros.messages.data.UpdateState
import uz.mros.messages.data.Updater
import uz.mros.messages.sms.Notifier
import uz.mros.messages.ui.AppViewModel
import uz.mros.messages.ui.components.AlertState
import uz.mros.messages.ui.components.AppIconBadge
import uz.mros.messages.ui.components.GlassIconButton
import uz.mros.messages.ui.components.IosAlert
import uz.mros.messages.ui.components.IosIcons
import uz.mros.messages.ui.components.IosRow
import uz.mros.messages.ui.components.IosSection
import uz.mros.messages.ui.components.IosSwitch
import uz.mros.messages.ui.components.liquidPress
import uz.mros.messages.ui.glass.GlassTouch
import uz.mros.messages.ui.glass.backdropSource
import uz.mros.messages.ui.glass.rememberBackdrop
import uz.mros.messages.ui.nav.Nav
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos
import uz.mros.messages.util.Fmt
import kotlin.math.ceil

private fun openUrl(ctx: Context, url: String) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        Toast.makeText(ctx, url, Toast.LENGTH_LONG).show()
    }
}

@Composable
private fun CheckMark(on: Boolean) {
    val ios = LocalIos.current
    if (on) Icon(IosIcons.Check, null, tint = ios.blue, modifier = Modifier.size(20.dp))
}

@Composable
private fun ColorDot(color: Color) {
    Box(
        Modifier
            .size(26.dp)
            .background(color, CircleShape)
    )
}

/** iOS sozlamalaridagi rangli kvadrat ikonka; [rotation] — aylanadigan ikonka uchun. */
@Composable
private fun IconTile(icon: ImageVector, color: Color, rotation: () -> Float = { 0f }) {
    Box(
        Modifier
            .size(30.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(color),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            icon,
            null,
            tint = Color.White,
            modifier = Modifier
                .size(18.dp)
                .graphicsLayer { rotationZ = rotation() },
        )
    }
}

/** Yangilanishlar qatori: ikonka tekshirish/yuklash paytida aylanadi. */
@Composable
private fun UpdatesRow(state: UpdateState, onClick: () -> Unit) {
    val ios = LocalIos.current
    val busy = state is UpdateState.Checking || state is UpdateState.Downloading
    val rot = remember { Animatable(0f) }
    LaunchedEffect(busy) {
        if (busy) {
            while (true) {
                rot.animateTo(rot.value + 360f, tween(850, easing = LinearEasing))
            }
        } else {
            rot.animateTo(ceil(rot.value / 360f) * 360f, spring(dampingRatio = 0.55f, stiffness = 260f))
        }
    }
    // yangi versiya bo'lsa — ikonka "yuradi"
    val pulse = rememberInfiniteTransition(label = "pulse")
    val beat by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.18f,
        animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
        label = "beat",
    )
    val available = state is UpdateState.Available || state is UpdateState.Ready
    val value = when (state) {
        UpdateState.Idle -> "Tekshirish"
        UpdateState.Checking -> "Tekshirilmoqda…"
        UpdateState.UpToDate -> "Eng so'nggi ✓"
        is UpdateState.Available -> "Yangi: ${state.release.tag.removePrefix("v")}"
        is UpdateState.Downloading -> "${(state.progress * 100).toInt()}%"
        is UpdateState.Ready -> "O'rnatish"
        is UpdateState.Failed -> "Qayta urinish"
    }
    val valueColor = when (state) {
        is UpdateState.Available, is UpdateState.Ready -> ios.blue
        UpdateState.UpToDate -> ios.green
        is UpdateState.Failed -> ios.red
        else -> Color.Unspecified
    }
    IosRow(
        title = "Yangilanishlar",
        value = value,
        valueColor = valueColor,
        leading = {
            Box(Modifier.graphicsLayer {
                val sc = if (available) beat else 1f
                scaleX = sc
                scaleY = sc
            }) {
                IconTile(IosIcons.Refresh, ios.green) { rot.value }
            }
        },
        showChevron = !busy,
        onClick = onClick,
        divider = state !is UpdateState.Downloading,
    )
    if (state is UpdateState.Downloading) {
        val prog by animateFloatAsState(state.progress, tween(250), label = "dl")
        Box(
            Modifier
                .padding(start = 60.dp, end = 16.dp, bottom = 12.dp)
                .fillMaxWidth()
                .height(5.dp)
                .clip(RoundedCornerShape(50))
                .background(ios.fill)
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(prog.coerceIn(0.02f, 1f))
                    .clip(RoundedCornerShape(50))
                    .background(ios.green)
            )
        }
    }
}

/** Ilova haqida kartochka: suzib turuvchi ikonka, versiya, yaratuvchi. */
@Composable
private fun InfoCard(ctx: Context) {
    val ios = LocalIos.current
    val density = LocalDensity.current
    val float = rememberInfiniteTransition(label = "float")
    val dy by float.animateFloat(
        initialValue = -3f,
        targetValue = 3f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse),
        label = "dy",
    )
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 22.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(Modifier.graphicsLayer { translationY = with(density) { dy.dp.toPx() } }) {
            AppIconBadge(76.dp)
        }
        Spacer(Modifier.height(14.dp))
        Text(Updater.APP_NAME, style = IosType.title2, color = ios.label)
        Spacer(Modifier.height(6.dp))
        Text("Version: ${Updater.currentVersion}", style = IosType.subhead, color = ios.secondary)
        Spacer(Modifier.height(2.dp))
        Text("Creator: ${Updater.CREATOR}", style = IosType.subhead, color = ios.secondary)
        Spacer(Modifier.height(16.dp))
        LiquidButton(
            text = "Creator",
            color = Color(0xFF2AA3E8),
            icon = IosIcons.Plane,
            height = 44.dp,
            grow = 0.1f,
        ) { openUrl(ctx, Updater.CREATOR_URL) }
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, nav: Nav, onRequestDefault: () -> Unit) {
    val ios = LocalIos.current
    val ctx = LocalContext.current
    val app = ctx.applicationContext
    val scope = rememberCoroutineScope()
    val backdrop = rememberBackdrop()
    val listState = rememberLazyListState()
    val theme by Prefs.theme.collectAsState()
    val green by Prefs.bubbleGreen.collectAsState()
    val delivery by Prefs.delivery.collectAsState()
    val glass by Prefs.glass.collectAsState()
    val autoFx by Prefs.autoEffects.collectAsState()
    val sim by Prefs.simSubId.collectAsState()
    val upd by Updater.state.collectAsState()
    val notifPreview by Prefs.notifPreview.collectAsState()
    var alert by remember { mutableStateOf<AlertState?>(null) }
    var blockTick by remember { mutableIntStateOf(0) }
    val blockedList by produceState(emptyList<String>(), blockTick) {
        value = withContext(Dispatchers.IO) { Blocker.list(app) }
    }
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val collapsed by remember { derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 60 } }
    val titleAlpha by animateFloatAsState(if (collapsed) 1f else 0f, label = "t")

    val onUpdateClick: () -> Unit = {
        when (val s = upd) {
            is UpdateState.Available -> Updater.download(app, s.release)
            is UpdateState.Ready -> {
                if (!Updater.install(app, s.file)) {
                    Toast.makeText(ctx, "“Noma'lum ilovalarni o'rnatish”ga ruxsat bering va qayta bosing", Toast.LENGTH_LONG).show()
                }
            }
            UpdateState.Checking, is UpdateState.Downloading -> {}
            else -> Updater.check()
        }
    }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .backdropSource(backdrop)
                .background(ios.groupedBg),
            contentPadding = PaddingValues(top = statusTop + 58.dp, bottom = navBottom + 40.dp),
        ) {
            item(key = "title") {
                Text(
                    "Sozlamalar",
                    style = IosType.largeTitle,
                    color = ios.label,
                    modifier = Modifier.padding(start = 20.dp, top = 2.dp),
                )
            }
            item(key = "sms") {
                IosSection("SMS") {
                    IosRow(
                        title = "Asosiy SMS ilova",
                        value = if (vm.isDefault) "Ha" else "Yo'q",
                        valueColor = if (vm.isDefault) ios.green else ios.red,
                        icon = IosIcons.BubbleFill,
                        iconBg = ios.green,
                        showChevron = !vm.isDefault,
                        onClick = if (vm.isDefault) null else onRequestDefault,
                    )
                    IosRow(
                        title = "Yetkazilganlik hisoboti",
                        icon = IosIcons.CheckCircle,
                        iconBg = ios.blue,
                        trailing = { IosSwitch(delivery) { Prefs.setDelivery(it) } },
                        divider = false,
                    )
                }
            }
            item(key = "notif") {
                IosSection(
                    "Bildirishnomalar",
                    footer = "Ilova ochiq bo'lsa — xabar tepadan shisha banner bo'lib tushadi. " +
                        "Matn yashirilsa, bildirishnomada faqat “Yangi xabar” yoziladi.",
                ) {
                    IosRow(
                        title = "Xabar matnini ko'rsatish",
                        icon = IosIcons.Bubble,
                        iconBg = ios.blue,
                        trailing = { IosSwitch(notifPreview) { Prefs.setNotifPreview(it) } },
                    )
                    IosRow(
                        title = "Ovoz va titrash",
                        icon = IosIcons.Bell,
                        iconBg = ios.red,
                        showChevron = true,
                        onClick = { Notifier.openChannelSettings(app) },
                    )
                    IosRow(
                        title = "Sinab ko'rish",
                        icon = IosIcons.Sparkles,
                        iconBg = ios.orange,
                        showChevron = true,
                        divider = false,
                        onClick = {
                            scope.launch(Dispatchers.IO) {
                                Notifier.showIncoming(app, -1L, "MROS SMS", "Salom! Bu sinov xabari 👋 Tasdiqlash kodi: 2468")
                            }
                        },
                    )
                }
            }
            if (vm.sims.size > 1) {
                item(key = "sim") {
                    IosSection("Yuborish uchun SIM karta") {
                        IosRow(
                            title = "Tizim bo'yicha",
                            icon = IosIcons.Sim,
                            iconBg = ios.gray,
                            trailing = { CheckMark(sim == -1) },
                            onClick = { Prefs.setSim(-1) },
                        )
                        vm.sims.forEachIndexed { i, s ->
                            IosRow(
                                title = "SIM ${s.slot + 1} · ${s.label}",
                                icon = IosIcons.Sim,
                                iconBg = if (i == 0) ios.indigo else ios.orange,
                                trailing = { CheckMark(sim == s.subId) },
                                onClick = { Prefs.setSim(s.subId) },
                                divider = i < vm.sims.lastIndex,
                            )
                        }
                    }
                }
            }
            item(key = "theme") {
                IosSection("Mavzu") {
                    listOf("Tizim bo'yicha", "Yorug'", "Qorong'i").forEachIndexed { i, t ->
                        IosRow(
                            title = t,
                            trailing = { CheckMark(theme == i) },
                            onClick = { Prefs.setTheme(i) },
                            divider = i < 2,
                        )
                    }
                }
            }
            item(key = "bubble") {
                IosSection("Xabar pufagi rangi") {
                    IosRow(
                        title = "Ko'k",
                        leading = { ColorDot(ios.blue) },
                        trailing = { CheckMark(!green) },
                        onClick = { Prefs.setBubbleGreen(false) },
                    )
                    IosRow(
                        title = "Yashil",
                        leading = { ColorDot(ios.green) },
                        trailing = { CheckMark(green) },
                        onClick = { Prefs.setBubbleGreen(true) },
                        divider = false,
                    )
                }
            }
            item(key = "glass") {
                IosSection(
                    "Effektlar",
                    footer = "Ekran effektlari: yuborish tugmasini bosib turing yoki “Tabriklayman”, “Tug'ilgan kuning bilan” kabi so'zlar yozing. " +
                        "Liquid Glass Android 13+ da to'liq ishlaydi; telefon qizisa o'chirib qo'ying.",
                ) {
                    IosRow(
                        title = "Liquid Glass",
                        icon = IosIcons.Drop,
                        iconBg = ios.blue,
                        trailing = { IosSwitch(glass) { Prefs.setGlass(it) } },
                    )
                    IosRow(
                        title = "Ekran effektlari (avto)",
                        icon = IosIcons.Sparkles,
                        iconBg = ios.purple,
                        trailing = { IosSwitch(autoFx) { Prefs.setAutoEffects(it) } },
                        divider = false,
                    )
                }
            }
            item(key = "blocked") {
                IosSection(
                    "Bloklangan raqamlar",
                    footer = if (blockedList.isEmpty()) "Bloklash uchun: chat tepasidagi ism ustiga bosing → Bloklash." else "Blokdan chiqarish uchun raqamni bosing.",
                ) {
                    if (blockedList.isEmpty()) {
                        IosRow(title = "Hech kim bloklanmagan", icon = IosIcons.NoSign, iconBg = ios.gray, divider = false)
                    } else {
                        blockedList.forEachIndexed { i, n ->
                            IosRow(
                                title = Fmt.prettyPhone(n),
                                icon = IosIcons.NoSign,
                                iconBg = ios.red,
                                divider = i < blockedList.lastIndex,
                                onClick = {
                                    alert = AlertState(
                                        title = "Blokdan chiqarilsinmi?",
                                        message = Fmt.prettyPhone(n),
                                        confirm = "Chiqarish",
                                        destructive = false,
                                    ) {
                                        scope.launch {
                                            withContext(Dispatchers.IO) { Blocker.unblock(app, n) }
                                            blockTick++
                                        }
                                    }
                                },
                            )
                        }
                    }
                }
            }
            // ---- eng pastda: Yangilanishlar, Telegram, Info
            item(key = "updates") {
                val footer = when (val s = upd) {
                    is UpdateState.Available -> s.release.notes.ifBlank { "Yangi versiya tayyor. Yuklab olish uchun bosing." }
                    is UpdateState.Failed -> s.message
                    else -> null
                }
                IosSection("Yangilanishlar", footer = footer) {
                    UpdatesRow(upd, onUpdateClick)
                    IosRow(
                        title = "Yangi nima bor",
                        leading = { IconTile(IosIcons.Sparkles, ios.orange) },
                        showChevron = true,
                        onClick = { vm.whatsNewVisible = true },
                    )
                    IosRow(
                        title = "Telegram kanal",
                        value = "@mrosapp",
                        leading = { IconTile(IosIcons.Plane, Color(0xFF2AA3E8)) },
                        showChevron = true,
                        onClick = { openUrl(ctx, Updater.CHANNEL_URL) },
                        divider = false,
                    )
                }
            }
            item(key = "info") {
                IosSection("Info") {
                    InfoCard(ctx)
                }
            }
        }

        Box(
            Modifier
                .fillMaxWidth()
                .height(statusTop + 60.dp)
                .background(
                    Brush.verticalGradient(
                        0f to ios.groupedBg,
                        0.55f to ios.groupedBg.copy(alpha = 0.82f),
                        1f to ios.groupedBg.copy(alpha = 0f),
                    )
                )
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = statusTop + 6.dp, start = 16.dp, end = 16.dp)
                .height(48.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GlassIconButton(IosIcons.ChevronLeft, backdrop, onClick = { nav.pop() }, iconSize = 19.dp)
            Text(
                "Sozlamalar",
                style = IosType.headline.copy(fontWeight = FontWeight.SemiBold),
                color = ios.label,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .weight(1f)
                    .alpha(titleAlpha),
            )
            Spacer(Modifier.size(44.dp))
        }

        IosAlert(alert, backdrop) { alert = null }
    }
}
