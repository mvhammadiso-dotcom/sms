package uz.mros.messages.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import uz.mros.messages.data.Prefs
import uz.mros.messages.ui.AppViewModel
import uz.mros.messages.ui.components.GlassIconButton
import uz.mros.messages.ui.components.IosIcons
import uz.mros.messages.ui.components.IosRow
import uz.mros.messages.ui.components.IosSection
import uz.mros.messages.ui.components.IosSwitch
import uz.mros.messages.ui.glass.backdropSource
import uz.mros.messages.ui.glass.rememberBackdrop
import uz.mros.messages.ui.nav.Nav
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos

@Composable
private fun CheckMark(on: Boolean) {
    val ios = LocalIos.current
    if (on) Icon(IosIcons.Check, null, tint = ios.blue, modifier = Modifier.size(20.dp))
}

@Composable
private fun ColorDot(color: Color) {
    Box(
        Modifier
            .size(26.dp)
            .background(color, CircleShape)
    )
}

@Composable
fun SettingsScreen(vm: AppViewModel, nav: Nav, onRequestDefault: () -> Unit) {
    val ios = LocalIos.current
    val backdrop = rememberBackdrop()
    val listState = rememberLazyListState()
    val theme by Prefs.theme.collectAsState()
    val green by Prefs.bubbleGreen.collectAsState()
    val delivery by Prefs.delivery.collectAsState()
    val glass by Prefs.glass.collectAsState()
    val sim by Prefs.simSubId.collectAsState()
    val statusTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val collapsed by remember { derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 60 } }
    val titleAlpha by animateFloatAsState(if (collapsed) 1f else 0f, label = "t")

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .backdropSource(backdrop)
                .background(ios.groupedBg),
            contentPadding = PaddingValues(top = statusTop + 58.dp, bottom = navBottom + 40.dp),
        ) {
            item(key = "title") {
                Text(
                    "Sozlamalar",
                    style = IosType.largeTitle,
                    color = ios.label,
                    modifier = Modifier.padding(start = 20.dp, top = 2.dp),
                )
            }
            item(key = "sms") {
                IosSection("SMS") {
                    IosRow(
                        title = "Asosiy SMS ilova",
                        value = if (vm.isDefault) "Ha" else "Yo'q",
                        icon = IosIcons.BubbleFill,
                        iconBg = ios.green,
                        showChevron = !vm.isDefault,
                        onClick = if (vm.isDefault) null else onRequestDefault,
                    )
                    IosRow(
                        title = "Yetkazilganlik hisoboti",
                        icon = IosIcons.CheckCircle,
                        iconBg = ios.blue,
                        trailing = { IosSwitch(delivery) { Prefs.setDelivery(it) } },
                        divider = false,
                    )
                }
            }
            if (vm.sims.size > 1) {
                item(key = "sim") {
                    IosSection("Yuborish uchun SIM karta") {
                        IosRow(
                            title = "Tizim bo'yicha",
                            icon = IosIcons.Sim,
                            iconBg = ios.gray,
                            trailing = { CheckMark(sim == -1) },
                            onClick = { Prefs.setSim(-1) },
                        )
                        vm.sims.forEachIndexed { i, s ->
                            IosRow(
                                title = "SIM ${s.slot + 1} · ${s.label}",
                                icon = IosIcons.Sim,
                                iconBg = if (i == 0) ios.indigo else ios.orange,
                                trailing = { CheckMark(sim == s.subId) },
                                onClick = { Prefs.setSim(s.subId) },
                                divider = i < vm.sims.lastIndex,
                            )
                        }
                    }
                }
            }
            item(key = "theme") {
                IosSection("Mavzu") {
                    listOf("Tizim bo'yicha", "Yorug'", "Qorong'i").forEachIndexed { i, t ->
                        IosRow(
                            title = t,
                            trailing = { CheckMark(theme == i) },
                            onClick = { Prefs.setTheme(i) },
                            divider = i < 2,
                        )
                    }
                }
            }
            item(key = "bubble") {
                IosSection("Xabar pufagi rangi") {
                    IosRow(
                        title = "Ko'k",
                        leading = { ColorDot(ios.blue) },
                        trailing = { CheckMark(!green) },
                        onClick = { Prefs.setBubbleGreen(false) },
                    )
                    IosRow(
                        title = "Yashil",
                        leading = { ColorDot(ios.green) },
                        trailing = { CheckMark(green) },
                        onClick = { Prefs.setBubbleGreen(true) },
                        divider = false,
                    )
                }
            }
            item(key = "glass") {
                IosSection(
                    "Effektlar",
                    footer = "Android 12+ da haqiqiy xiralik (blur), Android 13+ da esa shisha chetlarida yorug'lik sinishi ishlaydi. Telefon qizisa yoki sekinlashsa o'chirib qo'ying.",
                ) {
                    IosRow(
                        title = "Liquid Glass",
                        icon = IosIcons.Drop,
                        iconBg = ios.indigo,
                        trailing = { IosSwitch(glass) { Prefs.setGlass(it) } },
                        divider = false,
                    )
                }
            }
            item(key = "about") {
                IosSection(
                    "Ilova haqida",
                    footer = "MROS Xabarlar — iOS 27 uslubidagi SMS ilova. MMS hozircha qo'llab-quvvatlanmaydi.",
                ) {
                    IosRow(title = "Versiya", value = "1.0")
                    IosRow(title = "Reaksiyalar", value = "faqat shu telefonda", divider = false)
                }
            }
        }

        Box(
            Modifier
                .fillMaxWidth()
                .height(statusTop + 60.dp)
                .background(
                    Brush.verticalGradient(
                        0f to ios.groupedBg,
                        0.55f to ios.groupedBg.copy(alpha = 0.82f),
                        1f to ios.groupedBg.copy(alpha = 0f),
                    )
                )
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = statusTop + 6.dp, start = 16.dp, end = 16.dp)
                .height(48.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GlassIconButton(IosIcons.ChevronLeft, backdrop, onClick = { nav.pop() }, iconSize = 19.dp)
            Text(
                "Sozlamalar",
                style = IosType.headline,
                color = ios.label,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .weight(1f)
                    .alpha(titleAlpha),
            )
            Spacer(Modifier.size(44.dp))
        }
    }
}
