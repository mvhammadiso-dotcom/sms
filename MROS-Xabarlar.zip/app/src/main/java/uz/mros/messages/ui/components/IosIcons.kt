package uz.mros.messages.ui.components

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

private fun stroke(name: String, width: Float, block: PathBuilder.() -> Unit): ImageVector =
    ImageVector.Builder(
        name = name,
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
    ).path(
        stroke = SolidColor(Color.Black),
        strokeLineWidth = width,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
    ) {
        block(this)
    }.build()

private fun fill(name: String, block: PathBuilder.() -> Unit): ImageVector =
    ImageVector.Builder(
        name = name,
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
    ).path(fill = SolidColor(Color.Black)) {
        block(this)
    }.build()

private fun PathBuilder.circle(cx: Float, cy: Float, r: Float) {
    moveTo(cx - r, cy)
    arcToRelative(r, r, 0f, true, true, 2 * r, 0f)
    arcToRelative(r, r, 0f, true, true, -2 * r, 0f)
    close()
}

/** SF Symbols uslubidagi oddiy ikonkalar. */
object IosIcons {
    val ChevronLeft = stroke("chevron.left", 2.6f) {
        moveTo(15f, 4.5f); lineTo(7.5f, 12f); lineTo(15f, 19.5f)
    }

    val ChevronRight = stroke("chevron.right", 2.4f) {
        moveTo(9f, 5f); lineTo(16f, 12f); lineTo(9f, 19f)
    }

    val ChevronDown = stroke("chevron.down", 2.4f) {
        moveTo(5f, 9f); lineTo(12f, 16f); lineTo(19f, 9f)
    }

    val Compose = stroke("square.and.pencil", 1.9f) {
        moveTo(11.5f, 4f); lineTo(6.5f, 4f)
        curveTo(5.1f, 4f, 4f, 5.1f, 4f, 6.5f)
        lineTo(4f, 17.5f)
        curveTo(4f, 18.9f, 5.1f, 20f, 6.5f, 20f)
        lineTo(17.5f, 20f)
        curveTo(18.9f, 20f, 20f, 18.9f, 20f, 17.5f)
        lineTo(20f, 12.5f)
        moveTo(18.2f, 3.3f)
        curveTo(18.9f, 2.6f, 20.0f, 2.6f, 20.7f, 3.3f)
        curveTo(21.4f, 4.0f, 21.4f, 5.1f, 20.7f, 5.8f)
        lineTo(12.5f, 14f)
        lineTo(9.3f, 14.7f)
        lineTo(10f, 11.5f)
        close()
    }

    val Search = stroke("magnifyingglass", 2.2f) {
        moveTo(17f, 10.5f)
        arcTo(6.5f, 6.5f, 0f, false, true, 4f, 10.5f)
        arcTo(6.5f, 6.5f, 0f, false, true, 17f, 10.5f)
        close()
        moveTo(15.3f, 15.3f); lineTo(20.5f, 20.5f)
    }

    val ArrowUp = stroke("arrow.up", 2.8f) {
        moveTo(12f, 19f); lineTo(12f, 5.5f)
        moveTo(6f, 11f); lineTo(12f, 5f); lineTo(18f, 11f)
    }

    val Plus = stroke("plus", 2.3f) {
        moveTo(12f, 5f); lineTo(12f, 19f)
        moveTo(5f, 12f); lineTo(19f, 12f)
    }

    val Xmark = stroke("xmark", 2.3f) {
        moveTo(6.5f, 6.5f); lineTo(17.5f, 17.5f)
        moveTo(17.5f, 6.5f); lineTo(6.5f, 17.5f)
    }

    val Check = stroke("checkmark", 2.5f) {
        moveTo(5f, 12.5f); lineTo(10f, 17.5f); lineTo(19f, 7f)
    }

    val Filter = stroke("line.3.horizontal.decrease", 2.2f) {
        moveTo(4f, 7f); lineTo(20f, 7f)
        moveTo(7f, 12f); lineTo(17f, 12f)
        moveTo(10f, 17f); lineTo(14f, 17f)
    }

    val Ellipsis = fill("ellipsis") {
        circle(5.5f, 12f, 1.9f)
        circle(12f, 12f, 1.9f)
        circle(18.5f, 12f, 1.9f)
    }

    val Phone = fill("phone.fill") {
        moveTo(22f, 16.92f)
        verticalLineToRelative(3f)
        arcToRelative(2f, 2f, 0f, false, true, -2.18f, 2f)
        arcToRelative(19.79f, 19.79f, 0f, false, true, -8.63f, -3.07f)
        arcToRelative(19.5f, 19.5f, 0f, false, true, -6f, -6f)
        arcToRelative(19.79f, 19.79f, 0f, false, true, -3.07f, -8.67f)
        arcTo(2f, 2f, 0f, false, true, 4.11f, 2f)
        horizontalLineToRelative(3f)
        arcToRelative(2f, 2f, 0f, false, true, 2f, 1.72f)
        arcToRelative(12.84f, 12.84f, 0f, false, false, 0.7f, 2.81f)
        arcToRelative(2f, 2f, 0f, false, true, -0.45f, 2.11f)
        lineTo(8.09f, 9.91f)
        arcToRelative(16f, 16f, 0f, false, false, 6f, 6f)
        lineToRelative(1.27f, -1.27f)
        arcToRelative(2f, 2f, 0f, false, true, 2.11f, -0.45f)
        arcToRelative(12.84f, 12.84f, 0f, false, false, 2.81f, 0.7f)
        arcTo(2f, 2f, 0f, false, true, 22f, 16.92f)
        close()
    }

    val PersonFill = fill("person.fill") {
        circle(12f, 8.2f, 4.2f)
        moveTo(4f, 20.5f)
        curveTo(4f, 16.4f, 7.6f, 14f, 12f, 14f)
        curveTo(16.4f, 14f, 20f, 16.4f, 20f, 20.5f)
        close()
    }

    val Trash = stroke("trash", 1.9f) {
        moveTo(4f, 7f); lineTo(20f, 7f)
        moveTo(9.5f, 7f); lineTo(9.5f, 4.5f); lineTo(14.5f, 4.5f); lineTo(14.5f, 7f)
        moveTo(6f, 7f); lineTo(7f, 20f); lineTo(17f, 20f); lineTo(18f, 7f)
        moveTo(10f, 11f); lineTo(10f, 16.5f)
        moveTo(14f, 11f); lineTo(14f, 16.5f)
    }

    val Pin = stroke("pin", 1.9f) {
        moveTo(14f, 3f); lineTo(21f, 10f)
        moveTo(15.5f, 4.5f); lineTo(11f, 9f); lineTo(7.5f, 9f); lineTo(15f, 16.5f); lineTo(15f, 13f); lineTo(19.5f, 8.5f)
        moveTo(11.2f, 12.8f); lineTo(4.5f, 19.5f)
    }

    val Dot = fill("circle.fill") {
        circle(12f, 12f, 6f)
    }

    val CheckCircle = stroke("checkmark.circle", 1.9f) {
        circle(12f, 12f, 8.5f)
        moveTo(8f, 12.3f); lineTo(11f, 15.2f); lineTo(16.2f, 9.2f)
    }

    val Copy = stroke("doc.on.doc", 1.8f) {
        moveTo(9f, 9f); lineTo(19f, 9f); lineTo(19f, 20f); lineTo(9f, 20f); close()
        moveTo(15f, 9f); lineTo(15f, 5f); lineTo(5f, 5f); lineTo(5f, 16f); lineTo(9f, 16f)
    }

    val Retry = stroke("arrow.clockwise", 2f) {
        moveTo(19f, 12f)
        arcTo(7f, 7f, 0f, true, true, 16.9f, 7f)
        moveTo(17.2f, 3.5f); lineTo(17.2f, 7.3f); lineTo(13.4f, 7.3f)
    }

    /** gearshape.fill — 8 tishli g'ildirak, o'rtasi teshik */
    val Gear: ImageVector = ImageVector.Builder(
        name = "gearshape.fill",
        defaultWidth = 24.dp,
        defaultHeight = 24.dp,
        viewportWidth = 24f,
        viewportHeight = 24f,
    ).path(fill = SolidColor(Color.Black), pathFillType = PathFillType.EvenOdd) {
        val ro = 10f
        val ri = 7.6f
        for (k in 0 until 8) {
            val base = k * 45.0
            val a1 = Math.toRadians(base - 17.0)
            val a2 = Math.toRadians(base - 9.5)
            val a3 = Math.toRadians(base + 9.5)
            val a4 = Math.toRadians(base + 17.0)
            val x1 = 12f + ri * cos(a1).toFloat()
            val y1 = 12f + ri * sin(a1).toFloat()
            if (k == 0) moveTo(x1, y1) else lineTo(x1, y1)
            lineTo(12f + ro * cos(a2).toFloat(), 12f + ro * sin(a2).toFloat())
            lineTo(12f + ro * cos(a3).toFloat(), 12f + ro * sin(a3).toFloat())
            lineTo(12f + ri * cos(a4).toFloat(), 12f + ri * sin(a4).toFloat())
        }
        close()
        circle(12f, 12f, 3.3f)
    }.build()

    /** arrow.triangle.2.circlepath — yangilanish */
    val Refresh = stroke("arrow.triangle.2.circlepath", 2f) {
        moveTo(19.24f, 10.06f)
        arcTo(7.5f, 7.5f, 0f, false, false, 4.95f, 9.43f)
        moveTo(7.72f, 7.83f); lineTo(4.95f, 9.43f); lineTo(3.86f, 6.42f)
        moveTo(4.76f, 13.94f)
        arcTo(7.5f, 7.5f, 0f, false, false, 19.05f, 14.57f)
        moveTo(16.28f, 16.17f); lineTo(19.05f, 14.57f); lineTo(20.14f, 17.58f)
    }

    /** paperplane.fill — umumiy "yuborish" samolyoti */
    val Plane = fill("paperplane.fill") {
        moveTo(21.5f, 2.5f)
        lineTo(2.5f, 10.4f)
        lineTo(9.3f, 13.2f)
        lineTo(18.2f, 5.8f)
        lineTo(10.8f, 14.7f)
        lineTo(13.6f, 21.5f)
        close()
    }

    val BellSlash = stroke("bell.slash", 1.9f) {
        moveTo(5.5f, 16.5f); lineTo(18.5f, 16.5f)
        moveTo(7f, 16.5f); lineTo(7f, 10.5f)
        curveTo(7f, 7.5f, 9.2f, 5.2f, 12f, 5.2f)
        curveTo(14.8f, 5.2f, 17f, 7.5f, 17f, 10.5f)
        lineTo(17f, 16.5f)
        moveTo(10.2f, 19.5f)
        curveTo(10.6f, 20.3f, 11.3f, 20.7f, 12f, 20.7f)
        curveTo(12.7f, 20.7f, 13.4f, 20.3f, 13.8f, 19.5f)
        moveTo(4f, 4f); lineTo(20f, 20f)
    }

    val NoSign = stroke("nosign", 2f) {
        circle(12f, 12f, 8.5f)
        moveTo(6f, 6f); lineTo(18f, 18f)
    }

    val Sparkles = fill("sparkles") {
        moveTo(10f, 2.5f)
        curveTo(10.7f, 7.4f, 11.8f, 8.5f, 16.5f, 9.2f)
        curveTo(11.8f, 9.9f, 10.7f, 11f, 10f, 15.9f)
        curveTo(9.3f, 11f, 8.2f, 9.9f, 3.5f, 9.2f)
        curveTo(8.2f, 8.5f, 9.3f, 7.4f, 10f, 2.5f)
        close()
        moveTo(17.5f, 13f)
        curveTo(17.8f, 15.3f, 18.4f, 15.9f, 20.8f, 16.25f)
        curveTo(18.4f, 16.6f, 17.8f, 17.2f, 17.5f, 19.5f)
        curveTo(17.2f, 17.2f, 16.6f, 16.6f, 14.2f, 16.25f)
        curveTo(16.6f, 15.9f, 17.2f, 15.3f, 17.5f, 13f)
        close()
    }

    val Bubble = stroke("message", 1.9f) {
        moveTo(12f, 4f)
        curveTo(16.97f, 4f, 21f, 7.36f, 21f, 11.5f)
        curveTo(21f, 15.64f, 16.97f, 19f, 12f, 19f)
        curveTo(11.1f, 19f, 10.2f, 18.9f, 9.4f, 18.7f)
        curveTo(8.2f, 19.8f, 6.4f, 20.6f, 4.3f, 20.8f)
        curveTo(5.1f, 19.9f, 5.7f, 18.8f, 5.9f, 17.6f)
        curveTo(4.1f, 16.2f, 3f, 14f, 3f, 11.5f)
        curveTo(3f, 7.36f, 7.03f, 4f, 12f, 4f)
        close()
    }

    val BubbleFill = fill("message.fill") {
        moveTo(12f, 4f)
        curveTo(16.97f, 4f, 21f, 7.36f, 21f, 11.5f)
        curveTo(21f, 15.64f, 16.97f, 19f, 12f, 19f)
        curveTo(11.1f, 19f, 10.2f, 18.9f, 9.4f, 18.7f)
        curveTo(8.2f, 19.8f, 6.4f, 20.6f, 4.3f, 20.8f)
        curveTo(5.1f, 19.9f, 5.7f, 18.8f, 5.9f, 17.6f)
        curveTo(4.1f, 16.2f, 3f, 14f, 3f, 11.5f)
        curveTo(3f, 7.36f, 7.03f, 4f, 12f, 4f)
        close()
    }

    val Bell = stroke("bell", 1.9f) {
        moveTo(5.5f, 16.5f); lineTo(18.5f, 16.5f)
        moveTo(7f, 16.5f); lineTo(7f, 10.5f)
        curveTo(7f, 7.5f, 9.2f, 5.2f, 12f, 5.2f)
        curveTo(14.8f, 5.2f, 17f, 7.5f, 17f, 10.5f)
        lineTo(17f, 16.5f)
        moveTo(10.2f, 19.5f)
        curveTo(10.6f, 20.3f, 11.3f, 20.7f, 12f, 20.7f)
        curveTo(12.7f, 20.7f, 13.4f, 20.3f, 13.8f, 19.5f)
        moveTo(12f, 3.3f); lineTo(12f, 5.2f)
    }

    val Drop = fill("drop.fill") {
        moveTo(12f, 3.2f)
        curveTo(12f, 3.2f, 5.8f, 10f, 5.8f, 14.2f)
        curveTo(5.8f, 17.6f, 8.6f, 20.5f, 12f, 20.5f)
        curveTo(15.4f, 20.5f, 18.2f, 17.6f, 18.2f, 14.2f)
        curveTo(18.2f, 10f, 12f, 3.2f, 12f, 3.2f)
        close()
    }

    val Sim = stroke("simcard", 1.9f) {
        moveTo(7f, 3.5f); lineTo(14.5f, 3.5f); lineTo(18.5f, 7.5f); lineTo(18.5f, 20.5f); lineTo(7f, 20.5f); close()
        moveTo(9.5f, 11f); lineTo(16f, 11f); lineTo(16f, 17.5f); lineTo(9.5f, 17.5f); close()
    }

    val Info = stroke("info.circle", 1.9f) {
        circle(12f, 12f, 9f)
        moveTo(12f, 11f); lineTo(12f, 16.5f)
        moveTo(12f, 7.6f); lineTo(12f, 7.8f)
    }

    val Smile = stroke("face.smiling", 1.9f) {
        circle(12f, 12f, 9f)
        moveTo(8.5f, 14f)
        curveTo(9.3f, 15.3f, 10.6f, 16f, 12f, 16f)
        curveTo(13.4f, 16f, 14.7f, 15.3f, 15.5f, 14f)
        moveTo(9f, 9.5f); lineTo(9f, 10f)
        moveTo(15f, 9.5f); lineTo(15f, 10f)
    }
}
