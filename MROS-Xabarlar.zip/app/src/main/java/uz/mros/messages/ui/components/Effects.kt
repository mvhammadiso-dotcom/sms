package uz.mros.messages.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** iMessage kabi ekran effektlari. */
enum class ScreenEffect(val title: String, val emoji: String, val duration: Float) {
    CONFETTI("Konfetti", "🎉", 3.8f),
    BALLOONS("Sharlar", "🎈", 4.8f),
    HEARTS("Yuraklar", "❤️", 3.6f),
    FIREWORKS("Mushaklar", "🎆", 3.9f),
    SNOW("Qor", "❄️", 5.2f),
}

/** Har bir ishga tushirish alohida (bir xil effekt ketma-ket ham o'ynaydi). */
data class EffectRun(val effect: ScreenEffect, val id: Long = System.nanoTime())

object EffectTriggers {
    private val balloons = listOf(
        "tug'ilgan kun", "tugilgan kun", "tug`ilgan kun", "tug‘ilgan kun", "tavallud",
        "happy birthday", "с днем рождения", "с днём рождения", "день рождения",
    )
    private val confetti = listOf("tabriklayman", "tabriklaymiz", "muborak", "congrat", "поздравляю", "поздравляем", "qutlayman", "qutlug'")
    private val fireworks = listOf("yangi yil", "happy new year", "с новым годом", "новым годом")
    private val hearts = listOf(
        "seni sevaman", "sizni sevaman", "sevaman seni", "yaxshi ko'raman", "yaxshi koraman",
        "i love you", "love you", "люблю тебя", "я тебя люблю",
    )
    private val snow = listOf("qor yog'", "qor yog", "снег идет", "снег идёт", "it's snowing")

    /** Matnda kalit so'z bo'lsa — mos effekt. */
    fun detect(text: String): ScreenEffect? {
        val t = text.lowercase()
        return when {
            fireworks.any { it in t } -> ScreenEffect.FIREWORKS
            balloons.any { it in t } -> ScreenEffect.BALLOONS
            hearts.any { it in t } -> ScreenEffect.HEARTS
            confetti.any { it in t } -> ScreenEffect.CONFETTI
            snow.any { it in t } -> ScreenEffect.SNOW
            else -> null
        }
    }
}

private class Particle(
    val x: Float,
    val y: Float,
    val vx: Float,
    val vy: Float,
    val size: Float,
    val rot: Float,
    val vr: Float,
    val phase: Float,
    val color: Color,
    val delay: Float,
)

private val confettiColors = listOf(
    Color(0xFFFF3B30), Color(0xFFFF9500), Color(0xFFFFCC00), Color(0xFF34C759),
    Color(0xFF00C7BE), Color(0xFF007AFF), Color(0xFF5856D6), Color(0xFFAF52DE), Color(0xFFFF2D55),
)
private val balloonColors = listOf(
    Color(0xFFFF3B30), Color(0xFFFF9500), Color(0xFFFFCC00), Color(0xFF34C759),
    Color(0xFF007AFF), Color(0xFFAF52DE), Color(0xFFFF2D55), Color(0xFF5AC8FA),
)
private val heartColors = listOf(Color(0xFFFF2D55), Color(0xFFFF3B30), Color(0xFFFF6482), Color(0xFFE8175D), Color(0xFFFF8FAB))

/** Markazi (0,0), o'lchami ~1 bo'lgan yurak. */
private val HeartPath: Path = Path().apply {
    moveTo(0f, 0.38f)
    cubicTo(-1.1f, -0.32f, -0.48f, -1.08f, 0f, -0.45f)
    cubicTo(0.48f, -1.08f, 1.1f, -0.32f, 0f, 0.38f)
    close()
}

private fun makeParticles(e: ScreenEffect, rnd: Random): List<Particle> {
    fun r() = rnd.nextFloat()
    return when (e) {
        ScreenEffect.CONFETTI -> List(170) {
            Particle(
                x = r(), y = -0.05f - r() * 0.6f,
                vx = (r() - 0.5f) * 0.12f, vy = 0.30f + r() * 0.26f,
                size = 0.6f + r() * 0.7f, rot = r() * 360f, vr = (r() - 0.5f) * 760f,
                phase = r() * 6.28f, color = confettiColors[rnd.nextInt(confettiColors.size)], delay = 0f,
            )
        }
        ScreenEffect.BALLOONS -> List(16) {
            Particle(
                x = 0.08f + r() * 0.84f, y = 1.12f + r() * 0.55f,
                vx = 0f, vy = -(0.24f + r() * 0.12f),
                size = 0.8f + r() * 0.45f, rot = 0f, vr = 0f,
                phase = r() * 6.28f, color = balloonColors[rnd.nextInt(balloonColors.size)], delay = 0f,
            )
        }
        ScreenEffect.HEARTS -> List(46) {
            Particle(
                x = 0.15f + r() * 0.7f, y = 1.06f + r() * 0.35f,
                vx = (r() - 0.5f) * 0.05f, vy = -(0.26f + r() * 0.22f),
                size = 0.5f + r() * 0.9f, rot = (r() - 0.5f) * 30f, vr = 0f,
                phase = r() * 6.28f, color = heartColors[rnd.nextInt(heartColors.size)], delay = r() * 0.8f,
            )
        }
        ScreenEffect.FIREWORKS -> {
            val out = ArrayList<Particle>()
            val starts = floatArrayOf(0.05f, 0.5f, 0.95f, 1.4f, 1.9f)
            for (b in starts.indices) {
                val cx = 0.15f + r() * 0.7f
                val cy = 0.14f + r() * 0.4f
                val base = confettiColors[rnd.nextInt(confettiColors.size)]
                val delay = starts[b] + r() * 0.15f
                repeat(72) {
                    val ang = r() * 6.2832f
                    val sp = 0.16f + r() * 0.17f
                    out += Particle(
                        x = cx, y = cy, vx = cos(ang) * sp, vy = sin(ang) * sp,
                        size = 0.7f + r() * 0.6f, rot = 0f, vr = 0f, phase = r(),
                        color = if (r() < 0.2f) Color.White else base, delay = delay,
                    )
                }
            }
            out
        }
        ScreenEffect.SNOW -> List(150) {
            Particle(
                x = r(), y = -0.05f - r() * 1.1f,
                vx = 0f, vy = 0.09f + r() * 0.11f,
                size = 0.5f + r() * 1f, rot = 0f, vr = 0f,
                phase = r() * 6.28f, color = Color.White, delay = 0f,
            )
        }
    }
}

private fun DrawScope.drawConfetti(ps: List<Particle>, t: Float, fade: Float) {
    val unit = 9f * density
    val sway = 14f * density
    for (p in ps) {
        val px = (p.x + p.vx * t) * size.width + sin(t * 3.2f + p.phase) * sway
        val py = (p.y + p.vy * t) * size.height
        if (py < -40f || py > size.height + 40f) continue
        val w = unit * p.size * (0.25f + 0.75f * abs(cos(t * 5f + p.phase)))
        val h = unit * p.size * 0.5f
        rotate(degrees = p.rot + p.vr * t, pivot = Offset(px, py)) {
            drawRect(p.color.copy(alpha = fade), topLeft = Offset(px - w / 2f, py - h / 2f), size = Size(w, h))
        }
    }
}

private fun DrawScope.drawBalloons(ps: List<Particle>, t: Float, fade: Float) {
    val base = 30f * density
    val stringPath = Path()
    for (p in ps) {
        val r = base * p.size
        val px = p.x * size.width + sin(t * 1.4f + p.phase) * 16f * density
        val py = (p.y + p.vy * t) * size.height
        if (py < -r * 4f) continue
        val c = p.color.copy(alpha = 0.92f * fade)
        // ip
        stringPath.reset()
        stringPath.moveTo(px, py + r)
        val sw = sin(t * 2f + p.phase) * 10f * density
        stringPath.cubicTo(px + sw, py + r * 1.7f, px - sw * 0.5f, py + r * 2.5f, px, py + r * 3.2f)
        drawPath(stringPath, Color(0xFF8E8E93).copy(alpha = 0.7f * fade), style = Stroke(width = 1.2f * density))
        // shar
        drawOval(c, topLeft = Offset(px - r * 0.86f, py - r), size = Size(r * 1.72f, r * 2f))
        // tugun
        val knot = Path().apply {
            moveTo(px, py + r * 0.96f)
            lineTo(px - r * 0.12f, py + r * 1.14f)
            lineTo(px + r * 0.12f, py + r * 1.14f)
            close()
        }
        drawPath(knot, c)
        // yaltirash
        drawOval(
            Color.White.copy(alpha = 0.42f * fade),
            topLeft = Offset(px - r * 0.52f, py - r * 0.7f),
            size = Size(r * 0.42f, r * 0.62f),
        )
    }
}

private fun DrawScope.drawHearts(ps: List<Particle>, t: Float, fade: Float) {
    val base = 22f * density
    for (p in ps) {
        val lt = t - p.delay
        if (lt <= 0f) continue
        val px = (p.x + p.vx * lt) * size.width + sin(lt * 2.2f + p.phase) * 12f * density
        val py = (p.y + p.vy * lt) * size.height
        if (py < -60f) continue
        val grow = min(lt * 2.5f, 1f)
        val s = base * p.size * (0.5f + 0.5f * grow) * (1f + 0.08f * sin(lt * 9f + p.phase))
        val a = fade * (if (py < size.height * 0.25f) (py / (size.height * 0.25f)).coerceIn(0f, 1f) else 1f)
        withTransform({
            translate(px, py)
            rotate(p.rot, pivot = Offset.Zero)
            scale(s, s, pivot = Offset.Zero)
        }) {
            drawPath(HeartPath, p.color.copy(alpha = 0.95f * a))
        }
    }
}

private fun DrawScope.drawFireworks(ps: List<Particle>, t: Float, fade: Float) {
    // iOS kabi ekran biroz qorayadi
    val dim = min(t / 0.35f, 1f) * fade
    drawRect(Color.Black.copy(alpha = 0.45f * dim))
    val m = min(size.width, size.height)
    val g = 0.11f
    val life = 1.5f
    val dot = 2.4f * density
    for (p in ps) {
        val lt = t - p.delay
        if (lt <= 0f || lt > life) continue
        val a = (1f - lt / life) * fade
        for (k in 0..3) {
            val tt = (lt - k * 0.035f).coerceAtLeast(0f)
            val drag = 1f - 0.35f * tt
            val px = p.x * size.width + p.vx * tt * drag * m
            val py = p.y * size.height + p.vy * tt * drag * m + 0.5f * g * tt * tt * m
            drawCircle(p.color.copy(alpha = a * (1f - k * 0.25f)), radius = dot * p.size * (1f - k * 0.18f), center = Offset(px, py))
        }
    }
}

private fun DrawScope.drawSnow(ps: List<Particle>, t: Float, fade: Float, dark: Boolean) {
    val c = if (dark) Color.White else Color(0xFFAFC4DC)
    val base = 3.2f * density
    for (p in ps) {
        val px = p.x * size.width + sin(t * 1.1f + p.phase) * 18f * density
        val py = (p.y + p.vy * t) * size.height
        if (py < -10f || py > size.height + 10f) continue
        drawCircle(c.copy(alpha = 0.9f * fade), radius = base * p.size, center = Offset(px, py))
    }
}

/** To'liq ekran effekti. Bosishlarni to'smaydi. */
@Composable
fun EffectOverlay(run: EffectRun?, dark: Boolean, onDone: () -> Unit) {
    if (run == null) return
    val haptic = LocalHapticFeedback.current
    val particles = remember(run) { makeParticles(run.effect, Random(run.id)) }
    var t by remember(run) { mutableFloatStateOf(0f) }
    val latestDone by rememberUpdatedState(onDone)
    LaunchedEffect(run) {
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        val start = withFrameNanos { it }
        while (true) {
            val now = withFrameNanos { it }
            t = (now - start) / 1_000_000_000f
            if (t >= run.effect.duration) break
        }
        latestDone()
    }
    Canvas(Modifier.fillMaxSize()) {
        val time = t
        val fade = ((run.effect.duration - time) / 0.7f).coerceIn(0f, 1f)
        when (run.effect) {
            ScreenEffect.CONFETTI -> drawConfetti(particles, time, fade)
            ScreenEffect.BALLOONS -> drawBalloons(particles, time, fade)
            ScreenEffect.HEARTS -> drawHearts(particles, time, fade)
            ScreenEffect.FIREWORKS -> drawFireworks(particles, time, fade)
            ScreenEffect.SNOW -> drawSnow(particles, time, fade, dark)
        }
    }
}
