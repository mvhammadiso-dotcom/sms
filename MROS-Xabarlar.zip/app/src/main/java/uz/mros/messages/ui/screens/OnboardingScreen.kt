package uz.mros.messages.ui.screens

import uz.mros.messages.ui.components.LiquidButton
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import uz.mros.messages.ui.components.AppIconBadge
import uz.mros.messages.ui.components.IosIcons
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos

@Composable
private fun Feature(icon: ImageVector, color: Color, title: String, text: String) {
    val ios = LocalIos.current
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 11.dp),
        verticalAlignment = Alignment.Top,
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(34.dp))
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = IosType.headline, color = ios.label)
            Spacer(Modifier.height(2.dp))
            Text(text, style = IosType.subhead, color = ios.secondary)
        }
    }
}

@Composable
fun OnboardingScreen(onContinue: () -> Unit, onOpenSettings: () -> Unit) {
    val ios = LocalIos.current
    Box(
        Modifier
            .fillMaxSize()
            .background(ios.bg)
            .systemBarsPadding()
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 30.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(52.dp))
            AppIconBadge(92.dp)
            Spacer(Modifier.height(22.dp))
            Text("MROS SMS", style = IosType.largeTitle, color = ios.label, textAlign = TextAlign.Center)
            Spacer(Modifier.height(6.dp))
            Text("iOS 27 uslubidagi SMS ilova", style = IosType.body, color = ios.secondary, textAlign = TextAlign.Center)
            Spacer(Modifier.height(34.dp))
            Feature(IosIcons.Drop, ios.blue, "Liquid Glass dizayn", "Shaffof shisha panellar, xiralik va chetlarda yorug'lik sinishi.")
            Feature(IosIcons.Bell, ios.red, "Bildirishnomadan javob", "Xabarga bildirishnomaning o'zidan javob yozing.")
            Feature(IosIcons.Copy, ios.green, "Kodlarni nusxalash", "SMS tasdiqlash kodlarini bir bosishda nusxalang.")
            Feature(IosIcons.PersonFill, ios.orange, "Kontaktlar", "Ismlar va rasmlar telefon kontaktlaridan olinadi.")
            Spacer(Modifier.height(190.dp))
        }
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(ios.bg)
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                "Davom etish uchun Xabarlar'ni asosiy SMS ilova qilib belgilang va ruxsatlarni bering.",
                style = IosType.footnote,
                color = ios.secondary,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(14.dp))
            LiquidButton(
                text = "Davom etish",
                color = ios.blue,
                height = 54.dp,
                modifier = Modifier.fillMaxWidth(),
                onClick = onContinue,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Ilova sozlamalarini ochish",
                style = IosType.subhead,
                color = ios.blue,
                modifier = Modifier
                    .clickable(onClick = onOpenSettings)
                    .padding(10.dp),
            )
        }
    }
}
