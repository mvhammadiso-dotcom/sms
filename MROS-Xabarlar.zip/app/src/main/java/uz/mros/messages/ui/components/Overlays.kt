package uz.mros.messages.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import uz.mros.messages.ui.glass.Backdrop
import uz.mros.messages.ui.glass.Glass
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos
import kotlin.math.max
import kotlin.math.roundToInt

data class MenuItem(
    val title: String,
    val icon: ImageVector? = null,
    val destructive: Boolean = false,
    val checked: Boolean? = null,
    val onClick: () -> Unit,
)

/** [anchor] — ekran (root) koordinatalarida. */
data class MenuState(val anchor: Rect, val items: List<MenuItem>, val alignEnd: Boolean = false)

data class AlertState(
    val title: String,
    val message: String? = null,
    val confirm: String,
    val destructive: Boolean = true,
    val onConfirm: () -> Unit,
)

private class Holder<T>(var value: T)

@Composable
fun MenuRow(item: MenuItem, reserveCheck: Boolean, onClick: () -> Unit) {
    val ios = LocalIos.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val color = if (item.destructive) ios.red else ios.label
    Row(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .background(if (pressed) ios.fill else Color.Transparent)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (reserveCheck) {
            Box(Modifier.width(26.dp)) {
                if (item.checked == true) {
                    Icon(IosIcons.Check, null, tint = ios.label, modifier = Modifier.size(16.dp))
                }
            }
        }
        Text(item.title, style = IosType.body, color = color, maxLines = 1, modifier = Modifier.weight(1f))
        val icon = item.icon
        if (icon != null) {
            Spacer(Modifier.width(10.dp))
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
fun GlassMenuPanel(items: List<MenuItem>, backdrop: Backdrop?, modifier: Modifier, onItem: (MenuItem) -> Unit) {
    val ios = LocalIos.current
    val reserve = items.any { it.checked != null }
    Glass(backdrop, RoundedCornerShape(22.dp), modifier, tint = ios.menuTint, blur = 22.dp, shadow = 16.dp) {
        Column(Modifier.fillMaxWidth()) {
            items.forEachIndexed { i, item ->
                MenuRow(item, reserve) { onItem(item) }
                if (i < items.lastIndex) Hairline()
            }
        }
    }
}

/** iOS kontekst menyusi — ekran ustida, xiralashgan shisha panel. */
@Composable
fun MenuOverlay(state: MenuState?, backdrop: Backdrop?, onDismiss: () -> Unit) {
    val ios = LocalIos.current
    val holder = remember { Holder<MenuState?>(null) }
    if (state != null) holder.value = state
    val progress by animateFloatAsState(
        targetValue = if (state != null) 1f else 0f,
        animationSpec = tween(if (state != null) 220 else 150),
        label = "menu",
    )
    val s = holder.value ?: return
    if (state == null && progress <= 0.01f) return

    val density = LocalDensity.current
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val topSafe = with(density) { (topInset + 8.dp).toPx() }
    val bottomSafe = with(density) { (bottomInset + 8.dp).toPx() }
    var origin by remember { mutableStateOf(Offset.Zero) }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { origin = it.positionInRoot() }
    ) {
        val maxW = constraints.maxWidth.toFloat()
        val maxH = constraints.maxHeight.toFloat()
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = progress }
                .background(Color.Black.copy(alpha = if (ios.dark) 0.4f else 0.16f))
                .pointerInput(Unit) { detectTapGestures { onDismiss() } }
        )
        val a = s.anchor.translate(-origin.x, -origin.y)
        val itemH = with(density) { 48.dp.toPx() }
        val panelW = with(density) { 250.dp.toPx() }
        val panelH = itemH * s.items.size
        val margin = with(density) { 10.dp.toPx() }
        val side = with(density) { 14.dp.toPx() }
        val below = a.bottom + margin + panelH < maxH - bottomSafe
        val rawY = if (below) a.bottom + margin else a.top - margin - panelH
        val y = rawY.coerceIn(topSafe, max(topSafe, maxH - bottomSafe - panelH))
        val rawX = if (s.alignEnd) a.right - panelW else a.left
        val x = rawX.coerceIn(side, max(side, maxW - side - panelW))
        GlassMenuPanel(
            items = s.items,
            backdrop = backdrop,
            modifier = Modifier
                .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
                .width(250.dp)
                .graphicsLayer {
                    alpha = progress
                    val sc = 0.8f + 0.2f * progress
                    scaleX = sc
                    scaleY = sc
                    transformOrigin = TransformOrigin(if (s.alignEnd) 1f else 0f, if (below) 0f else 1f)
                },
        ) { item ->
            onDismiss()
            item.onClick()
        }
    }
}

/** iOS 26/27 uslubidagi ogohlantirish oynasi. */
@Composable
fun IosAlert(state: AlertState?, backdrop: Backdrop?, onDismiss: () -> Unit) {
    val ios = LocalIos.current
    val holder = remember { Holder<AlertState?>(null) }
    if (state != null) holder.value = state
    val progress by animateFloatAsState(
        targetValue = if (state != null) 1f else 0f,
        animationSpec = tween(if (state != null) 220 else 150),
        label = "alert",
    )
    val s = holder.value ?: return
    if (state == null && progress <= 0.01f) return

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = progress }
                .background(Color.Black.copy(alpha = if (ios.dark) 0.45f else 0.22f))
                .pointerInput(Unit) { detectTapGestures { onDismiss() } }
        )
        Glass(
            backdrop = backdrop,
            shape = RoundedCornerShape(32.dp),
            modifier = Modifier
                .width(300.dp)
                .graphicsLayer {
                    alpha = progress
                    val sc = 1.12f - 0.12f * progress
                    scaleX = sc
                    scaleY = sc
                },
            tint = ios.menuTint,
            blur = 24.dp,
            shadow = 20.dp,
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 18.dp, end = 18.dp, top = 22.dp, bottom = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(s.title, style = IosType.headline, color = ios.label, textAlign = TextAlign.Center)
                val msg = s.message
                if (msg != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(msg, style = IosType.footnote, color = ios.label, textAlign = TextAlign.Center)
                }
                Spacer(Modifier.height(18.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    AlertButton("Bekor qilish", ios.fill, ios.label, Modifier.weight(1f)) { onDismiss() }
                    AlertButton(s.confirm, if (s.destructive) ios.red else ios.blue, Color.White, Modifier.weight(1f)) {
                        onDismiss()
                        s.onConfirm()
                    }
                }
            }
        }
    }
}

@Composable
private fun AlertButton(text: String, bg: Color, fg: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(48.dp)
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = IosType.headline, color = fg, maxLines = 1)
    }
}
