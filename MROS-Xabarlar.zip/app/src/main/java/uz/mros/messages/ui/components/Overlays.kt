package uz.mros.messages.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredWidth
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import uz.mros.messages.ui.glass.Backdrop
import uz.mros.messages.ui.glass.Glass
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

data class MenuItem(
    val title: String,
    val icon: ImageVector? = null,
    val destructive: Boolean = false,
    val checked: Boolean? = null,
    val onClick: () -> Unit,
)

/**
 * [anchor] — menyu chiqadigan tugma (root koordinatalarida). Menyu shu tugmadan "suv kabi"
 * cho'zilib ochiladi. [source] — tugma nomi (ochiq paytda tugmani yashirish uchun).
 */
data class MenuState(
    val anchor: Rect,
    val items: List<MenuItem>,
    val alignEnd: Boolean = false,
    val source: String? = null,
    val title: String? = null,
    val centered: Boolean = false,
    val widthDp: Int = 250,
)

data class AlertState(
    val title: String,
    val message: String? = null,
    val confirm: String,
    val destructive: Boolean = true,
    val cancel: String = "Bekor qilish",
    val onConfirm: () -> Unit,
)

private class Holder<T>(var value: T)

@Composable
fun MenuRow(item: MenuItem, reserveCheck: Boolean, onClick: () -> Unit) {
    val ios = LocalIos.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val color = if (item.destructive) ios.red else ios.label
    Row(
        Modifier
            .fillMaxWidth()
            .height(48.dp)
            .background(if (pressed) ios.fill else Color.Transparent)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (reserveCheck) {
            Box(Modifier.width(26.dp)) {
                if (item.checked == true) {
                    Icon(IosIcons.Check, null, tint = ios.label, modifier = Modifier.size(16.dp))
                }
            }
        }
        Text(item.title, style = IosType.body, color = color, maxLines = 1, modifier = Modifier.weight(1f))
        val icon = item.icon
        if (icon != null) {
            Spacer(Modifier.width(10.dp))
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
fun GlassMenuPanel(items: List<MenuItem>, backdrop: Backdrop?, modifier: Modifier, onItem: (MenuItem) -> Unit) {
    val ios = LocalIos.current
    val reserve = items.any { it.checked != null }
    Glass(backdrop, RoundedCornerShape(22.dp), modifier, tint = ios.menuTint, blur = 22.dp, shadow = 16.dp) {
        Column(Modifier.fillMaxWidth()) {
            items.forEachIndexed { i, item ->
                MenuRow(item, reserve) { onItem(item) }
                if (i < items.lastIndex) Hairline()
            }
        }
    }
}

private fun lerpF(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/**
 * iOS 26/27 kontekst menyusi: tugmadan "suyuq" morf bo'lib chiqadi —
 * o'lchami, joyi va burchaklari tugmadan panelgacha prujinali animatsiya bilan o'zgaradi,
 * ichidagi qatorlar esa ketma-ket paydo bo'ladi.
 */
@Composable
fun MenuOverlay(state: MenuState?, backdrop: Backdrop?, onDismiss: () -> Unit) {
    val ios = LocalIos.current
    val holder = remember { Holder<MenuState?>(null) }
    if (state != null) holder.value = state
    val open = state != null
    val p by animateFloatAsState(
        targetValue = if (open) 1f else 0f,
        animationSpec = if (open) spring(dampingRatio = 0.66f, stiffness = 360f) else spring(dampingRatio = 1f, stiffness = 700f),
        label = "menuMorph",
    )
    val s = holder.value ?: return
    if (!open && p <= 0.01f) return

    val density = LocalDensity.current
    val topInset = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val topSafe = with(density) { (topInset + 8.dp).toPx() }
    val bottomSafe = with(density) { (bottomInset + 8.dp).toPx() }
    var origin by remember { mutableStateOf(Offset.Zero) }

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { origin = it.positionInRoot() }
    ) {
        val maxW = constraints.maxWidth.toFloat()
        val maxH = constraints.maxHeight.toFloat()
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = p.coerceIn(0f, 1f) }
                .background(Color.Black.copy(alpha = if (ios.dark) 0.4f else 0.16f))
                .pointerInput(Unit) { detectTapGestures { onDismiss() } }
        )
        val rawA = s.anchor.translate(-origin.x, -origin.y)
        val itemH = with(density) { 48.dp.toPx() }
        val titleH = if (s.title != null) with(density) { 38.dp.toPx() } else 0f
        val panelW = with(density) { s.widthDp.dp.toPx() }
        val hair = with(density) { 0.5.dp.toPx() }
        val panelH = itemH * s.items.size + titleH + hair * (max(s.items.size - 1, 0) + (if (s.title != null) 1 else 0))
        val margin = with(density) { 10.dp.toPx() }
        val side = with(density) { 14.dp.toPx() }
        val a = if (rawA.width > 1f && rawA.height > 1f) rawA else Rect(maxW / 2f - 22f, maxH / 2f - 22f, maxW / 2f + 22f, maxH / 2f + 22f)
        val below = a.bottom + margin + panelH < maxH - bottomSafe
        val ty = (if (below) a.bottom + margin else a.top - margin - panelH)
            .coerceIn(topSafe, max(topSafe, maxH - bottomSafe - panelH))
        val tx = (
            when {
                s.centered -> a.center.x - panelW / 2f
                s.alignEnd -> a.right - panelW
                else -> a.left
            }
            ).coerceIn(side, max(side, maxW - side - panelW))

        // morf: tugma -> panel
        val x = lerpF(a.left, tx, p)
        val y = lerpF(a.top, ty, p)
        val w = lerpF(a.width, panelW, p).coerceAtLeast(2f)
        val h = lerpF(a.height, panelH, p).coerceAtLeast(2f)
        val startCorner = min(a.width, a.height) / 2f
        val endCorner = with(density) { 22.dp.toPx() }
        val corner = lerpF(startCorner, endCorner, p.coerceIn(0f, 1f))
        val contentAlpha = ((p - 0.35f) / 0.65f).coerceIn(0f, 1f)
        val align = when {
            s.centered && below -> Alignment.TopCenter
            s.centered -> Alignment.BottomCenter
            s.alignEnd && below -> Alignment.TopEnd
            s.alignEnd -> Alignment.BottomEnd
            below -> Alignment.TopStart
            else -> Alignment.BottomStart
        }
        val reserve = s.items.any { it.checked != null }

        Glass(
            backdrop = backdrop,
            shape = RoundedCornerShape(with(density) { corner.toDp() }),
            modifier = Modifier
                .offset { IntOffset(x.roundToInt(), y.roundToInt()) }
                .size(with(density) { w.toDp() }, with(density) { h.toDp() }),
            tint = ios.menuTint,
            blur = 22.dp,
            shadow = 16.dp,
        ) {
            Column(
                Modifier
                    .wrapContentSize(align = align, unbounded = true)
                    .requiredWidth(s.widthDp.dp)
                    .graphicsLayer { alpha = contentAlpha }
            ) {
                val t = s.title
                if (t != null) {
                    Text(
                        text = t,
                        style = IosType.footnote,
                        color = ios.secondary,
                        maxLines = 1,
                        modifier = Modifier
                            .height(38.dp)
                            .padding(horizontal = 16.dp, vertical = 11.dp),
                    )
                    Hairline()
                }
                s.items.forEachIndexed { i, item ->
                    MenuRow(item, reserve) {
                        onDismiss()
                        item.onClick()
                    }
                    if (i < s.items.lastIndex) Hairline()
                }
            }
        }
    }
}

/** iOS 26/27 uslubidagi ogohlantirish oynasi. */
@Composable
fun IosAlert(state: AlertState?, backdrop: Backdrop?, onDismiss: () -> Unit) {
    val ios = LocalIos.current
    val holder = remember { Holder<AlertState?>(null) }
    if (state != null) holder.value = state
    val progress by animateFloatAsState(
        targetValue = if (state != null) 1f else 0f,
        animationSpec = if (state != null) spring(dampingRatio = 0.62f, stiffness = 380f) else tween(150),
        label = "alert",
    )
    val s = holder.value ?: return
    if (state == null && progress <= 0.01f) return

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = progress.coerceIn(0f, 1f) }
                .background(Color.Black.copy(alpha = if (ios.dark) 0.45f else 0.22f))
                .pointerInput(Unit) { detectTapGestures { onDismiss() } }
        )
        Glass(
            backdrop = backdrop,
            shape = RoundedCornerShape(32.dp),
            modifier = Modifier
                .width(300.dp)
                .graphicsLayer {
                    alpha = progress.coerceIn(0f, 1f)
                    // suv tomchisi kabi: avval kichik, keyin cho'zilib joyiga tushadi
                    val sc = 0.82f + 0.18f * progress
                    scaleX = sc * (1f + 0.04f * (1f - progress))
                    scaleY = sc
                },
            tint = ios.menuTint,
            blur = 24.dp,
            shadow = 20.dp,
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 18.dp, end = 18.dp, top = 22.dp, bottom = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(s.title, style = IosType.headline, color = ios.label, textAlign = TextAlign.Center)
                val msg = s.message
                if (msg != null) {
                    Spacer(Modifier.height(6.dp))
                    Text(msg, style = IosType.footnote, color = ios.label, textAlign = TextAlign.Center)
                }
                Spacer(Modifier.height(18.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    LiquidButton(
                        text = s.cancel,
                        color = if (ios.dark) Color(0xFF3A3A3C) else Color(0xFFE5E5EA),
                        textColor = ios.label,
                        height = 48.dp,
                        modifier = Modifier.weight(1f),
                        onClick = onDismiss,
                    )
                    LiquidButton(
                        text = s.confirm,
                        color = if (s.destructive) ios.red else ios.blue,
                        height = 48.dp,
                        modifier = Modifier.weight(1f),
                    ) {
                        onDismiss()
                        s.onConfirm()
                    }
                }
            }
        }
    }
}
