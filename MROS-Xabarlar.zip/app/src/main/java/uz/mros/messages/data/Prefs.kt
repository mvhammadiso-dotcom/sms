package uz.mros.messages.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Ilova sozlamalari (SharedPreferences + StateFlow). */
object Prefs {
    private var sp: SharedPreferences? = null

    private val _pinned = MutableStateFlow<Set<Long>>(emptySet())
    val pinned: StateFlow<Set<Long>> = _pinned

    private val _bubbleGreen = MutableStateFlow(false)
    val bubbleGreen: StateFlow<Boolean> = _bubbleGreen

    /** 0 = tizim, 1 = yorug', 2 = qorong'i */
    private val _theme = MutableStateFlow(0)
    val theme: StateFlow<Int> = _theme

    private val _delivery = MutableStateFlow(true)
    val delivery: StateFlow<Boolean> = _delivery

    private val _glass = MutableStateFlow(true)
    val glass: StateFlow<Boolean> = _glass

    /** -1 = tizim bo'yicha */
    private val _simSubId = MutableStateFlow(-1)
    val simSubId: StateFlow<Int> = _simSubId

    /** xabar kaliti -> emoji (tapback, faqat shu telefonda saqlanadi) */
    private val _reactions = MutableStateFlow<Map<String, String>>(emptyMap())
    val reactions: StateFlow<Map<String, String>> = _reactions

    fun init(context: Context) {
        if (sp != null) return
        val p = context.applicationContext.getSharedPreferences("mros_messages", Context.MODE_PRIVATE)
        sp = p
        _pinned.value = (p.getStringSet("pinned", null) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()
        _bubbleGreen.value = p.getBoolean("bubble_green", false)
        _theme.value = p.getInt("theme", 0)
        _delivery.value = p.getBoolean("delivery", true)
        _glass.value = p.getBoolean("glass", true)
        _simSubId.value = p.getInt("sim", -1)
        val r = HashMap<String, String>()
        for (e in p.getStringSet("reactions", null) ?: emptySet()) {
            val i = e.indexOf('|')
            if (i > 0) r[e.substring(0, i)] = e.substring(i + 1)
        }
        _reactions.value = r
    }

    fun isPinned(id: Long): Boolean = id in _pinned.value

    fun togglePin(id: Long) {
        val s = _pinned.value.toMutableSet()
        if (!s.add(id)) s.remove(id)
        _pinned.value = s
        sp?.edit()?.putStringSet("pinned", s.map { it.toString() }.toSet())?.apply()
    }

    fun unpin(id: Long) {
        if (isPinned(id)) togglePin(id)
    }

    fun setBubbleGreen(v: Boolean) {
        _bubbleGreen.value = v
        sp?.edit()?.putBoolean("bubble_green", v)?.apply()
    }

    fun setTheme(v: Int) {
        _theme.value = v
        sp?.edit()?.putInt("theme", v)?.apply()
    }

    fun setDelivery(v: Boolean) {
        _delivery.value = v
        sp?.edit()?.putBoolean("delivery", v)?.apply()
    }

    fun setGlass(v: Boolean) {
        _glass.value = v
        sp?.edit()?.putBoolean("glass", v)?.apply()
    }

    fun setSim(v: Int) {
        _simSubId.value = v
        sp?.edit()?.putInt("sim", v)?.apply()
    }

    fun setReaction(key: String, emoji: String?) {
        val m = _reactions.value.toMutableMap()
        if (emoji == null || m[key] == emoji) m.remove(key) else m[key] = emoji
        _reactions.value = m
        sp?.edit()?.putStringSet("reactions", m.map { "${it.key}|${it.value}" }.toSet())?.apply()
    }
}
