package uz.mros.messages.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.mros.messages.data.Photos
import uz.mros.messages.ui.glass.Backdrop
import uz.mros.messages.ui.glass.Glass
import uz.mros.messages.ui.glass.GlassTouch
import androidx.compose.ui.composed
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import uz.mros.messages.ui.glass.waterSheen
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos
import uz.mros.messages.util.Fmt
import kotlin.math.abs

/** Pastdagi ekranlarga bosish o'tib ketmasligi uchun. */
fun Modifier.blockTouches(): Modifier = this.pointerInput(Unit) {
    awaitPointerEventScope {
        while (true) {
            awaitPointerEvent()
        }
    }
}

/**
 * "Suyuq" bosish: shisha suv tomchisidek kengayadi, barmoq tomonga cho'ziladi,
 * bosilgan joydan to'lqin tarqaladi, qo'yib yuborganda jele kabi tebranib joyiga qaytadi.
 * [onLongClick] berilsa — bosib turilganda chaqiriladi (titrash bilan).
 */
fun Modifier.liquidPress(
    touch: GlassTouch,
    scope: CoroutineScope,
    grow: Float = 0.22f,
    onLongClick: (() -> Unit)? = null,
    onClick: () -> Unit,
): Modifier = composed {
    val click by rememberUpdatedState(onClick)
    val longClick by rememberUpdatedState(onLongClick)
    val hasLong = onLongClick != null
    val haptic = LocalHapticFeedback.current
    this
        .graphicsLayer {
            val a = touch.amount.value
            val p = touch.pos
            var nx = 0f
            var ny = 0f
            if (p.isSpecified && size.width > 0f && size.height > 0f) {
                nx = ((p.x - size.width / 2f) / (size.width / 2f)).coerceIn(-1f, 1f)
                ny = ((p.y - size.height / 2f) / (size.height / 2f)).coerceIn(-1f, 1f)
                val k = 0.11f * a.coerceAtLeast(0f)
                translationX = (p.x - size.width / 2f) * k
                translationY = (p.y - size.height / 2f) * k
            }
            // suv tomchisi: kengayganda barmoq tomonga cho'ziladi, qarama-qarshi o'qda biroz siqiladi
            val sc = 1f + grow * a
            scaleX = sc + 0.08f * a * abs(nx) - 0.03f * a * abs(ny)
            scaleY = sc + 0.08f * a * abs(ny) - 0.03f * a * abs(nx)
        }
        .pointerInput(touch, hasLong) {
            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false)
                touch.pos = down.position
                scope.launch { touch.press(true) }
                scope.launch { touch.splash(down.position) }
                val slop = 24.dp.toPx()
                val timeout = if (hasLong) viewConfiguration.longPressTimeoutMillis else Long.MAX_VALUE / 4
                // true = bosildi, false = bekor qilindi, null = bosib turildi
                val tapped = withTimeoutOrNull(timeout) {
                    var result = false
                    var go = true
                    while (go) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id }
                        if (ch == null || ch.isConsumed) {
                            go = false
                        } else {
                            touch.pos = ch.position
                            if (!ch.pressed) {
                                val inside = ch.position.x > -slop && ch.position.y > -slop &&
                                    ch.position.x < size.width + slop && ch.position.y < size.height + slop
                                if (inside) {
                                    ch.consume()
                                    result = true
                                }
                                go = false
                            }
                        }
                    }
                    result
                }
                if (tapped == null) {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    scope.launch { touch.splash(touch.pos) }
                    longClick?.invoke()
                    // barmoq ko'tarilguncha kutamiz
                    var go = true
                    while (go) {
                        val ev = awaitPointerEvent()
                        val ch = ev.changes.firstOrNull { it.id == down.id }
                        if (ch == null || !ch.pressed) go = false else ch.consume()
                    }
                }
                scope.launch { touch.press(false) }
                if (tapped == true) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    click()
                }
            }
        }
}

/** Rangli suyuq tugma (Davom etish, O'chirish, Creator...) — suv tomchisi kabi yaltiraydi. */
@Composable
fun LiquidButton(
    text: String,
    color: Color,
    modifier: Modifier = Modifier,
    textColor: Color = Color.White,
    height: Dp = 50.dp,
    icon: ImageVector? = null,
    grow: Float = 0.06f,
    onClick: () -> Unit,
) {
    val ios = LocalIos.current
    val touch = remember { GlassTouch() }
    val scope = rememberCoroutineScope()
    val shape = RoundedCornerShape(50)
    Box(
        modifier
            .height(height)
            .semantics { role = Role.Button }
            .liquidPress(touch, scope, grow = grow, onClick = onClick)
            .shadow(
                elevation = 8.dp,
                shape = shape,
                clip = false,
                ambientColor = color.copy(alpha = 0.4f),
                spotColor = color.copy(alpha = 0.55f),
            )
            .clip(shape)
            .waterSheen(shape, ios.dark, tint = color, touch = touch),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            Modifier.padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (icon != null) {
                Icon(icon, null, tint = textColor, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
            }
            Text(text, style = IosType.headline, color = textColor, maxLines = 1)
        }
    }
}

/** Suyuq shisha doira tugma (iOS 26/27). */
@Composable
fun GlassIconButton(
    icon: ImageVector,
    backdrop: Backdrop?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 20.dp,
    tint: Color = Color.Unspecified,
    contentDescription: String? = null,
) {
    val ios = LocalIos.current
    val touch = remember { GlassTouch() }
    val scope = rememberCoroutineScope()
    val latestClick by rememberUpdatedState(onClick)
    Glass(
        backdrop = backdrop,
        shape = CircleShape,
        touch = touch,
        modifier = modifier
            .size(size)
            .semantics { role = Role.Button }
            .liquidPress(touch, scope) { latestClick() },
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (tint == Color.Unspecified) ios.label else tint,
            modifier = Modifier
                .size(iconSize)
                .align(Alignment.Center),
        )
    }
}

/** Matnli suyuq shisha kapsula tugma. */
@Composable
fun GlassPill(
    text: String,
    backdrop: Backdrop?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    bold: Boolean = false,
) {
    val ios = LocalIos.current
    val touch = remember { GlassTouch() }
    val scope = rememberCoroutineScope()
    val latestClick by rememberUpdatedState(onClick)
    Glass(
        backdrop = backdrop,
        shape = RoundedCornerShape(50),
        touch = touch,
        modifier = modifier
            .heightIn(min = 44.dp)
            .semantics { role = Role.Button }
            .liquidPress(touch, scope, grow = 0.08f) { latestClick() },
    ) {
        Text(
            text = text,
            style = if (bold) IosType.headline else IosType.body,
            color = if (color == Color.Unspecified) ios.label else color,
            maxLines = 1,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 18.dp, vertical = 11.dp),
        )
    }
}

/** iOS 26/27 kaliti: bosganda tugmacha suv tomchisidek cho'zilib shishaga aylanadi. */
@Composable
fun IosSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val ios = LocalIos.current
    val haptic = LocalHapticFeedback.current
    val t by animateFloatAsState(if (checked) 1f else 0f, spring(dampingRatio = 0.62f, stiffness = 420f), label = "switch")
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val p by animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = if (pressed) spring(dampingRatio = 0.6f, stiffness = 600f) else spring(dampingRatio = 0.35f, stiffness = 300f),
        label = "knob",
    )
    val knobW = 27.dp + 12.dp * p
    val travel = 51.dp - 4.dp - knobW
    Box(
        Modifier
            .size(width = 51.dp, height = 31.dp)
            .clip(CircleShape)
            .background(lerp(ios.switchOff, ios.green, t))
            .clickable(interactionSource = interaction, indication = null) {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onChange(!checked)
            }
            .padding(2.dp)
    ) {
        Box(
            Modifier
                .offset(x = travel * t)
                .size(width = knobW, height = 27.dp)
                .graphicsLayer {
                    val sc = 1f + 0.18f * p
                    scaleX = sc
                    scaleY = sc
                }
                .shadow(2.5.dp + 3.dp * p, CircleShape)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 1f - 0.55f * p))
                .waterSheen(CircleShape, dark = false)
        )
    }
}

@Composable
fun Hairline(modifier: Modifier = Modifier) {
    val ios = LocalIos.current
    Box(
        modifier
            .fillMaxWidth()
            .height(0.5.dp)
            .background(ios.separator)
    )
}

@Composable
fun IosSection(
    header: String?,
    footer: String? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val ios = LocalIos.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        if (header != null) {
            Text(
                text = header.uppercase(),
                style = IosType.footnote,
                color = ios.secondary,
                modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 7.dp),
            )
        } else {
            Spacer(Modifier.height(24.dp))
        }
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(ios.cell),
            content = content,
        )
        if (footer != null) {
            Text(
                text = footer,
                style = IosType.footnote,
                color = ios.secondary,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 7.dp),
            )
        }
    }
}

@Composable
fun IosRow(
    title: String,
    value: String? = null,
    valueColor: Color = Color.Unspecified,
    icon: ImageVector? = null,
    iconBg: Color = Color.Unspecified,
    leading: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    showChevron: Boolean = false,
    titleColor: Color = Color.Unspecified,
    divider: Boolean = true,
    onClick: (() -> Unit)? = null,
) {
    val ios = LocalIos.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val hasLeading = icon != null || leading != null
    Column(
        Modifier
            .fillMaxWidth()
            .background(if (pressed && onClick != null) ios.pressed else Color.Transparent)
            .then(
                if (onClick != null) {
                    Modifier.clickable(interactionSource = interaction, indication = null, onClick = onClick)
                } else {
                    Modifier
                }
            )
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 52.dp)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (icon != null) {
                Box(
                    Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (iconBg == Color.Unspecified) ios.blue else iconBg),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.width(14.dp))
            } else if (leading != null) {
                leading()
                Spacer(Modifier.width(14.dp))
            }
            Text(
                text = title,
                style = IosType.body,
                color = if (titleColor == Color.Unspecified) ios.label else titleColor,
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 14.dp),
            )
            if (value != null) {
                Text(value, style = IosType.body, color = if (valueColor == Color.Unspecified) ios.secondary else valueColor, maxLines = 1)
                Spacer(Modifier.width(6.dp))
            }
            if (trailing != null) trailing()
            if (showChevron) {
                Icon(IosIcons.ChevronRight, null, tint = ios.tertiary, modifier = Modifier.size(14.dp))
            }
        }
        if (divider) {
            Hairline(Modifier.padding(start = if (hasLeading) 60.dp else 16.dp))
        }
    }
}

/** Kontakt rasmi yoki bosh harflari (iOS kulrang gradient). */
@Composable
fun Avatar(name: String?, photoUri: String?, size: Dp, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx() }
    val bitmap by produceState<ImageBitmap?>(null, photoUri) {
        value = if (photoUri != null) Photos.load(ctx, photoUri, px) else null
    }
    val initials = remember(name) { Fmt.initials(name) }
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(Color(0xFFA9AEBB), Color(0xFF858A95)))),
        contentAlignment = Alignment.Center,
    ) {
        val b = bitmap
        if (b != null) {
            Image(bitmap = b, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else if (initials != null) {
            Text(
                text = initials,
                color = Color.White,
                fontSize = (size.value * 0.4f).sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Clip,
            )
        } else {
            Icon(
                imageVector = IosIcons.PersonFill,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier
                    .size(size * 0.62f)
                    .offset(y = size * 0.1f),
            )
        }
    }
}

@Composable
fun AppIconBadge(size: Dp) {
    Box(
        Modifier
            .size(size)
            .shadow(10.dp, RoundedCornerShape(size * 0.25f))
            .clip(RoundedCornerShape(size * 0.25f))
            .background(Brush.verticalGradient(listOf(Color(0xFF6BE38A), Color(0xFF1DB954)))),
        contentAlignment = Alignment.Center,
    ) {
        Icon(IosIcons.BubbleFill, null, tint = Color.White, modifier = Modifier.size(size * 0.62f))
        Row(
            Modifier.offset(y = -(size * 0.02f)),
            horizontalArrangement = Arrangement.spacedBy(size * 0.05f),
        ) {
            repeat(3) {
                Box(
                    Modifier
                        .size(size * 0.075f)
                        .background(Color(0xFF22C05A), CircleShape)
                )
            }
        }
    }
}
