package uz.mros.messages.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import uz.mros.messages.data.Photos
import uz.mros.messages.ui.glass.Backdrop
import uz.mros.messages.ui.glass.Glass
import uz.mros.messages.ui.glass.GlassTouch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import uz.mros.messages.ui.theme.IosType
import uz.mros.messages.ui.theme.LocalIos
import uz.mros.messages.util.Fmt
import kotlin.math.abs

/** Pastdagi ekranlarga bosish o'tib ketmasligi uchun. */
fun Modifier.blockTouches(): Modifier = this.pointerInput(Unit) {
    awaitPointerEventScope {
        while (true) {
            awaitPointerEvent()
        }
    }
}

/**
 * "Suyuq" bosish: shisha suv tomchisidek kengayadi, barmoq tomonga cho'ziladi,
 * bosilgan joydan to'lqin tarqaladi, qo'yib yuborganda jele kabi tebranib joyiga qaytadi.
 */
fun Modifier.liquidPress(
    touch: GlassTouch,
    scope: CoroutineScope,
    grow: Float = 0.22f,
    onClick: () -> Unit,
): Modifier = this
    .graphicsLayer {
        val a = touch.amount.value
        val p = touch.pos
        var nx = 0f
        var ny = 0f
        if (p.isSpecified && size.width > 0f && size.height > 0f) {
            nx = ((p.x - size.width / 2f) / (size.width / 2f)).coerceIn(-1f, 1f)
            ny = ((p.y - size.height / 2f) / (size.height / 2f)).coerceIn(-1f, 1f)
            val k = 0.11f * a.coerceAtLeast(0f)
            translationX = (p.x - size.width / 2f) * k
            translationY = (p.y - size.height / 2f) * k
        }
        val sc = 1f + grow * a
        scaleX = sc + 0.07f * a * abs(nx)
        scaleY = sc + 0.07f * a * abs(ny)
    }
    .pointerInput(touch) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false)
            touch.pos = down.position
            scope.launch { touch.press(true) }
            scope.launch { touch.splash(down.position) }
            while (true) {
                val ev = awaitPointerEvent()
                val ch = ev.changes.firstOrNull { it.id == down.id } ?: break
                if (ch.isConsumed) break
                touch.pos = ch.position
                if (!ch.pressed) {
                    val slop = 24.dp.toPx()
                    val inside = ch.position.x > -slop && ch.position.y > -slop &&
                        ch.position.x < size.width + slop && ch.position.y < size.height + slop
                    if (inside) {
                        ch.consume()
                        onClick()
                    }
                    break
                }
            }
            scope.launch { touch.press(false) }
        }
    }

/** Suyuq shisha doira tugma (iOS 26/27). */
@Composable
fun GlassIconButton(
    icon: ImageVector,
    backdrop: Backdrop?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    iconSize: Dp = 20.dp,
    tint: Color = Color.Unspecified,
    contentDescription: String? = null,
) {
    val ios = LocalIos.current
    val touch = remember { GlassTouch() }
    val scope = rememberCoroutineScope()
    val latestClick by rememberUpdatedState(onClick)
    Glass(
        backdrop = backdrop,
        shape = CircleShape,
        touch = touch,
        modifier = modifier
            .size(size)
            .semantics { role = Role.Button }
            .liquidPress(touch, scope) { latestClick() },
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = if (tint == Color.Unspecified) ios.label else tint,
            modifier = Modifier
                .size(iconSize)
                .align(Alignment.Center),
        )
    }
}

/** Matnli suyuq shisha kapsula tugma. */
@Composable
fun GlassPill(
    text: String,
    backdrop: Backdrop?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    bold: Boolean = false,
) {
    val ios = LocalIos.current
    val touch = remember { GlassTouch() }
    val scope = rememberCoroutineScope()
    val latestClick by rememberUpdatedState(onClick)
    Glass(
        backdrop = backdrop,
        shape = RoundedCornerShape(50),
        touch = touch,
        modifier = modifier
            .heightIn(min = 44.dp)
            .semantics { role = Role.Button }
            .liquidPress(touch, scope, grow = 0.08f) { latestClick() },
    ) {
        Text(
            text = text,
            style = if (bold) IosType.headline else IosType.body,
            color = if (color == Color.Unspecified) ios.label else color,
            maxLines = 1,
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 18.dp, vertical = 11.dp),
        )
    }
}

@Composable
fun IosSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val ios = LocalIos.current
    val t by animateFloatAsState(if (checked) 1f else 0f, spring(dampingRatio = 0.72f, stiffness = 520f), label = "switch")
    val interaction = remember { MutableInteractionSource() }
    Box(
        Modifier
            .size(width = 51.dp, height = 31.dp)
            .clip(CircleShape)
            .background(lerp(ios.switchOff, ios.green, t))
            .clickable(interactionSource = interaction, indication = null) { onChange(!checked) }
            .padding(2.dp)
    ) {
        Box(
            Modifier
                .offset(x = 20.dp * t)
                .size(27.dp)
                .shadow(2.5.dp, CircleShape)
                .background(Color.White, CircleShape)
        )
    }
}

@Composable
fun Hairline(modifier: Modifier = Modifier) {
    val ios = LocalIos.current
    Box(
        modifier
            .fillMaxWidth()
            .height(0.5.dp)
            .background(ios.separator)
    )
}

@Composable
fun IosSection(
    header: String?,
    footer: String? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val ios = LocalIos.current
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        if (header != null) {
            Text(
                text = header.uppercase(),
                style = IosType.footnote,
                color = ios.secondary,
                modifier = Modifier.padding(start = 16.dp, top = 24.dp, bottom = 7.dp),
            )
        } else {
            Spacer(Modifier.height(24.dp))
        }
        Column(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(ios.cell),
            content = content,
        )
        if (footer != null) {
            Text(
                text = footer,
                style = IosType.footnote,
                color = ios.secondary,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 7.dp),
            )
        }
    }
}

@Composable
fun IosRow(
    title: String,
    value: String? = null,
    valueColor: Color = Color.Unspecified,
    icon: ImageVector? = null,
    iconBg: Color = Color.Unspecified,
    leading: (@Composable () -> Unit)? = null,
    trailing: (@Composable () -> Unit)? = null,
    showChevron: Boolean = false,
    titleColor: Color = Color.Unspecified,
    divider: Boolean = true,
    onClick: (() -> Unit)? = null,
) {
    val ios = LocalIos.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val hasLeading = icon != null || leading != null
    Column(
        Modifier
            .fillMaxWidth()
            .background(if (pressed && onClick != null) ios.pressed else Color.Transparent)
            .then(
                if (onClick != null) {
                    Modifier.clickable(interactionSource = interaction, indication = null, onClick = onClick)
                } else {
                    Modifier
                }
            )
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 52.dp)
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (icon != null) {
                Box(
                    Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (iconBg == Color.Unspecified) ios.blue else iconBg),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.width(14.dp))
            } else if (leading != null) {
                leading()
                Spacer(Modifier.width(14.dp))
            }
            Text(
                text = title,
                style = IosType.body,
                color = if (titleColor == Color.Unspecified) ios.label else titleColor,
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 14.dp),
            )
            if (value != null) {
                Text(value, style = IosType.body, color = if (valueColor == Color.Unspecified) ios.secondary else valueColor, maxLines = 1)
                Spacer(Modifier.width(6.dp))
            }
            if (trailing != null) trailing()
            if (showChevron) {
                Icon(IosIcons.ChevronRight, null, tint = ios.tertiary, modifier = Modifier.size(14.dp))
            }
        }
        if (divider) {
            Hairline(Modifier.padding(start = if (hasLeading) 60.dp else 16.dp))
        }
    }
}

/** Kontakt rasmi yoki bosh harflari (iOS kulrang gradient). */
@Composable
fun Avatar(name: String?, photoUri: String?, size: Dp, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val px = with(LocalDensity.current) { size.roundToPx() }
    val bitmap by produceState<ImageBitmap?>(null, photoUri) {
        value = if (photoUri != null) Photos.load(ctx, photoUri, px) else null
    }
    val initials = remember(name) { Fmt.initials(name) }
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.verticalGradient(listOf(Color(0xFFA9AEBB), Color(0xFF858A95)))),
        contentAlignment = Alignment.Center,
    ) {
        val b = bitmap
        if (b != null) {
            Image(bitmap = b, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else if (initials != null) {
            Text(
                text = initials,
                color = Color.White,
                fontSize = (size.value * 0.4f).sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Clip,
            )
        } else {
            Icon(
                imageVector = IosIcons.PersonFill,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier
                    .size(size * 0.62f)
                    .offset(y = size * 0.1f),
            )
        }
    }
}

@Composable
fun AppIconBadge(size: Dp) {
    Box(
        Modifier
            .size(size)
            .shadow(10.dp, RoundedCornerShape(size * 0.25f))
            .clip(RoundedCornerShape(size * 0.25f))
            .background(Brush.verticalGradient(listOf(Color(0xFF6BE38A), Color(0xFF1DB954)))),
        contentAlignment = Alignment.Center,
    ) {
        Icon(IosIcons.BubbleFill, null, tint = Color.White, modifier = Modifier.size(size * 0.62f))
        Row(
            Modifier.offset(y = -(size * 0.02f)),
            horizontalArrangement = Arrangement.spacedBy(size * 0.05f),
        ) {
            repeat(3) {
                Box(
                    Modifier
                        .size(size * 0.075f)
                        .background(Color(0xFF22C05A), CircleShape)
                )
            }
        }
    }
}
