plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

// GitHub Actions beradi: -PbuildNumber=<run_number> -PupdateRepo=<owner/repo>
val buildNumber: Int = (project.findProperty("buildNumber") as String?)?.toIntOrNull() ?: 1
val updateRepo: String = (project.findProperty("updateRepo") as String?) ?: ""

android {
    namespace = "uz.mros.messages"
    compileSdk = 35

    defaultConfig {
        applicationId = "uz.mros.messages"
        minSdk = 26
        targetSdk = 35
        versionCode = buildNumber
        versionName = "1.0.$buildNumber"
        buildConfigField("String", "UPDATE_REPO", "\"$updateRepo\"")
    }

    // Bir xil kalit bilan imzolanadi — yangi versiya eskisining ustiga o'rnatiladi.
    signingConfigs {
        create("mros") {
            storeFile = rootProject.file("keystore/mros.jks")
            storePassword = "mrosmessages"
            keyAlias = "mros"
            keyPassword = "mrosmessages"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("mros")
        }
        debug {
            signingConfig = signingConfigs.getByName("mros")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.compose.material3:material3")
}
